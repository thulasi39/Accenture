# copy code to the test environments and the production staging area
# parameter $1 = environment (hzndev, hznsys, hznqc, hznuat, hznprd

if [ "$1" == "hznprd" ] # production build
then
  # create prod_push directories
  if [ ! -d prod_push ]
  then
    mkdir prod_push
  fi
  if [ ! -d prod_push/bin ]
  then
    mkdir -p prod_push/bin
  fi
  if [ ! -d prod_push/ctl ]
  then
    mkdir -p prod_push/ctl
  fi
  if [ ! -d prod_push/StoredProcedures ]
  then
    mkdir prod_push/StoredProcedures
  fi

  # copy the code
  fileCount=`ls Common/Scripts | wc -l`;
  if [ $fileCount -gt 0 ]
  then
    scp -r Common/Scripts/* prod_push/bin
  fi
  
  fileCount=`ls Common/ctl | wc -l`;
  if [ $fileCount -gt 0 ]
  then
    scp -r Common/ctl/* prod_push/ctl
  fi
  
  fileCount=`ls Common/StoredProcedures | wc -l`;
  if [ $fileCount -gt 0 ]
  then
    scp -r Common/StoredProcedures/* prod_push/StoredProcedures
  fi
else                    # test build
  fileCount=`ls Common/Scripts | wc -l`;
  if [ $fileCount -gt 0 ]
  then
    scp -r Common/Scripts/* $1@zldv7905:/opt/app/users/$1/bin
  fi
  
  fileCount=`ls Common/ctl | wc -l`;
  if [ $fileCount -gt 0 ]
  then
    scp -r Common/ctl/* $1@zldv7905:/opt/app/users/$1/ctl
  fi
  
  fileCount=`ls Common/StoredProcedures | wc -l`;
  if [ $fileCount -gt 0 ]
  then
    scp -r Common/StoredProcedures/* $1@zldv7905:/opt/app/users/$1/StoredProcedures
  fi
fi
