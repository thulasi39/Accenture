# create push directories
if [ ! -d push ]
then
  mkdir push
fi
if [ ! -d push/bin ]
then
  mkdir push/bin
fi
if [ ! -d push/ctl ]
then
  mkdir -p push/ctl
fi
if [ ! -d push/StoredProcedures ]
then
  mkdir push/StoredProcedures
fi

# copy the bin and libs directories
if [ "$(ls -A push/bin)" ]
then
  rm push/bin/*
fi
cp Common/bin/* push/bin

# copy ctl files
if [ "$(ls -A push/ctl)" ]
then
  rm push/ctl/*
fi
cp Common/ctl/*.ctl push/ctl

# copy stored procedures
if [ "$(ls -A push/StoredProcedures)" ]
then
  rm push/StoredProcedures/*
fi
cp Common/StoredProcedures/* push/StoredProcedures
