#!/usr/bin/perl

###############################################################################
# Process : pickSvnInfo.pl                                                    #
#-----------------------------------------------------------------------------#
# Purpose : Get log information into summary files                            #
# Usage   : pickSvnInfo.pl -f SvnReleaseNotes [-M]                            #
#-----------------------------------------------------------------------------#
#***********************************************************
#	Example of svn log info
#***********************************************************
#------------------------------------------------------------------------
#r1940 | dw3466 | 2011-05-26 07:29:32 -0500 (Thu, 26 May 2011) | 1 line
#
#AOTS ????? script added to set the close date and submit date in the agents_cycles table for a given month year if it is not already set.  It should be run autmatically at the end of each month.  In the agents_cycles table, it will set the close_date and the submit_date to the last day of the next month.
#------------------------------------------------------------------------
#***********************************************************
#Svn: 1940  usr:  dw3466   dt: 2011-05-26 07:29:32 Text: AOTS ????? script added to set the close date and
#***********************************************************
use Getopt::Std;
use Env qw(WORKHOME);

# declare subroutine
sub trim($);

$USAGE = "USAGE: $0 -f <input file name> -o <output file name> [-M]\n";
$USAGE = $USAGE . "\tGet summary log information into files.\n\n";
$USAGE = $USAGE . "\t-f <input file name>: Name of release notes input file\n";
$USAGE = $USAGE . "\t-o <output file name>: Name of output file\n";
$USAGE = $USAGE . "\t-M: Minimum output, log message only\n\n";

getopts('f:o:M');
die $USAGE if(($opt_f eq "") or ($opt_o eq ""));

open RELEASENOTES, "<$opt_f";
open OUTFILE, ">$opt_o";

$Ignore = "NO";

while(<RELEASENOTES>){
  chomp;
  
  # skip information lines
  if((index($_, "Previous build", 0) == 0) or
     (index($_, "Server Changes", 0) == 0) or
     (index($_, "GUI Changes", 0) == 0) or
     (index($_, "MyComp Summarization Changes", 0) == 0) or
     (index($_, "cmd:", 0) == 0)){
    next;
  }
  
  # skip dash lines and empty lines and reset ignore flag
  if((index($_, "---", 0) == 0 ) or ($_ eq "")){
    $Ignore = "NO";
    next;
  }
  
  # Remove verbose (-v) information
  if(index($_, "Changed paths:", 0) == 0){
    $Ignore = "YES";
    next;
  }
  
  # skip extra path and comment lines
  if($Ignore eq "YES"){
    next;
  }
  
  if(/^r[0-9]/){
    ($Rev, $Author, $DateTime) = split /\|/, $_, 3;
    $RNum = substr(trim($Rev), 1);
    $Author = trim($Author);
    $DateTime = trim($DateTime);
    @DateTimeArray = split / /, $DateTime;
    next;
  }
  
  # process comments
  $first60 = substr($_, 0, 60);
  if($opt_M == 1){
    print OUTFILE "$first60\n";
  }
  else{
    print OUTFILE "Svn Revision: $RNum  Author: $Author  Date: $DateTimeArray[0]  Time: $DateTimeArray[1]  Text: $first60\n"
  }
}

close RELEASENOTES;
close OUTFILE;

sub trim($){
  my $string = shift;
  $string =~ s/^\s+//;
  $string =~ s/\s+$//;
  return $string;
}
