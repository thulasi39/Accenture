# get the latest changes into the release notes file

# get the current version number
svn info $1 | grep 'Last Changed Rev' | cut -f4 -d' ' -s > CurrentBuildVersion
read CURRENT_BUILD_VERSION < CurrentBuildVersion
rm CurrentBuildVersion

# get the version number of the previous build
if [ -e LastBuildVersion ]
then
  read LAST_BUILD_VERSION < LastBuildVersion
else
  LAST_BUILD_VERSION=CURRENT_BUILD_VERSION
fi

# update LastBuildVersion file with the current version number
echo $CURRENT_BUILD_VERSION > LastBuildVersion

# if the previous and current version numbers are different then get the log messages for the changes from SVN
if [ $LAST_BUILD_VERSION -lt $CURRENT_BUILD_VERSION ];
then
  LAST_BUILD_VERSION=`expr $LAST_BUILD_VERSION + 1`
  svn log -v --revision $LAST_BUILD_VERSION:$CURRENT_BUILD_VERSION $1 >> $2_Release_Notes.txt # add to file
  svn log -v --revision $LAST_BUILD_VERSION:$CURRENT_BUILD_VERSION $1 >> SvnReleaseNotes.txt # add to file for pull website
  svn log -v --revision $LAST_BUILD_VERSION:$CURRENT_BUILD_VERSION $1 > CurrentChanges.txt # replace file
else
  echo "No changes since the last build" > CurrentChanges.txt # create empty file to avoid confusion
fi
