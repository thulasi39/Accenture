#!/usr/bin/perl

###############################################################################
# Process : hbldrepos                                                         #
#-----------------------------------------------------------------------------#
# Purpose : Perform Horizon Repository build                                  #
# Usage   : hbldrepos -p [project]                                            #
#-----------------------------------------------------------------------------#
use Getopt::Std;
use Env qw(WORKHOME);

$SVNCMD="svn";
$MAKE="make";
$QUICKMAKE="quickmake";
$IP_URL="scm.it.att.com:12726";

$USAGE = "USAGE: $0  -p <project> [-b] [-y <year>] [-M] [-f]\n";
$USAGE = $USAGE . "\tBuild command to start with a clean HComm directory and build the server\n\n";
$USAGE = $USAGE . "\t-p <project>: Name of project (trunk/branch/tag) to build (required parameter)\n";
$USAGE = $USAGE . "\t-M: use 'make' instead of 'quickmake' (optional parameter)\n";
$USAGE = $USAGE . "\t-f: Indicates a 'final' production build and causes the PROD symbolic link to be changed (optional parameter)\n";
$USAGE = $USAGE . "\t-b and -y are mutually exclusive.  Only one of them can be specified at a time\n";
$USAGE = $USAGE . "\t-b: use the 'branches' path of SVN (optional parameter)\n";
$USAGE = $USAGE . "\t-y: use the 'tags' path of SVN and include the 4 digit year in the path, for example -y 2013 (optional parameter)\n\n";

getopts('p:by:Mf');

# $opt_p must specify trunk, a branch or a tag and $opt_b and $opt_y are mutually exclusive
die $USAGE if(($opt_p eq "") or (($opt_b == 1) and ($opt_y ne "")));

$SVNPATH = "";
$LOGPARAM = "";
if($opt_b == 1){
  $SVNPATH = "branches/";
  $LOGPARAM = "-b";
}
if($opt_y ne ""){
  $SVNPATH = "tags/$opt_y/";
  $LOGPARAM = "-y $opt_y";
}

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime;
if($sec < 10){
  $sec = "0" . $sec;
}
if($min < 10){
  $min = "0" . $min;
}
if($hour < 10){
  $hour = "0" . $hour;
}
if($mday < 10){
  $mday = "0" . $mday;
}
$mon++;
if($mon < 10){
  $mon = "0" . $mon;
}
$year = $year - 100 + 2000;

$BASEDIR = "$WORKHOME/builds";
$WDIR = "$BASEDIR/$opt_p.$year$mon$mday.$hour:$min:$sec";

$WDIRC="$WDIR/Common";
$WDIRCb="$WDIRC/bin";
$WDIRS="$WDIRC/Scripts";
$WDIRCTL="$WDIRC/ctl";
$WDIRP="$WDIRC/StoredProcedures";
$WDIRE="$WDIRC/Encrypt";
$WDIRPush="$WDIR/push";
$LastBuild="$BASEDIR/Last_$opt_p";

mkdir $WDIR or die "BUILD failed: Could not make $WDIR\n";
mkdir $WDIRPush or die "BUILD failed: Could not make $WDIRPush\n";
mkdir "$WDIRPush/bin" or die "BUILD failed: Could not make $WDIRPush/bin\n";
mkdir "$WDIRPush/ctl" or die "BUILD failed: Could not make $WDIRPush/ctl\n";
mkdir "$WDIRPush/StoredProcedures" or die "BUILD failed: Could not make $WDIRPush/StoredProcedures\n";

chdir $WDIR or die "BUILD failed: Count not change to directory $WDIR\n";

open ERRFILE, ">$0.err";
open OUTFILE, ">$0.out";
close STDOUT;
close STDERR;
open STDOUT, ">&OUTFILE";
open STDERR, ">&ERRFILE";
open SCMLOG, ">>$WORKHOME/SCM/HznScmRecord";    # always append

$date = scalar localtime;
print "Build STARTED at $date\n";

print OUTFILE "Running SVN to get lastest code into $WDIR\n";

print OUTFILE "$SVNCMD export --force --username horizon --password MikoCat1 svn://$IP_URL/HznRepository/$SVNPATH$opt_p ${WDIR}\n";
system("$SVNCMD export --force --username horizon --password MikoCat1 svn://$IP_URL/HznRepository/$SVNPATH$opt_p .") == 0
  or die "BUILD failed: SVN could not put latest code into $WDIR\n";

chdir $WDIRC or die "BUILD failed: Could not change to directory $WDIRC\n";

print "Starting from Directory: $WDIRC\n";
$date = scalar localtime;
print "\nCommon Make ALL STARTED at $date\n";

if(system("$MAKE") != 0){
  print "Doing a 2nd make as the first was incomplete\n";
  system("$MAKE") == 0
    or die "BUILD failed: make command error\n";
}
$date = scalar localtime;
print "\nCommon Make ALL FINISHED at $date\n\n";

# Get revision numbers
chdir $WDIR;
system("svn info svn://$IP_URL/HznRepository/$SVNPATH$opt_p | grep 'Last Changed Rev' | cut -f4 -d' ' -s > RevFile");
open RevFile, "<RevFile";
chomp($HznReposLastChanged = <RevFile>);
close RevFile;
system("svn info svn://$IP_URL/HznRepository/$SVNPATH$opt_p | grep '^Revision:' | cut -f2 -d' ' -s  > RevFile");
open RevFile, "<RevFile";
chomp($ReposRev = <RevFile>);
close RevFile;
print "Revision # for the repository is $ReposRev\n\n";
unlink "RevFile";

open HZNSCMBUILD, ">$WDIRCb/HznScmBuild";
$date = scalar localtime;
print HZNSCMBUILD "$date -------------------------------Building-------------------------------\n";
print HZNSCMBUILD "$date        Project:                    $opt_p\n";
print HZNSCMBUILD "$date        Build date and time:        $mon/$mday/$year at $hour:$min:$sec\n";
print HZNSCMBUILD "$date        Build Directory:            $WDIR\n";
print HZNSCMBUILD "$date        SVN Repository Revision:    $ReposRev\n";
print HZNSCMBUILD "$date        HznRepository Revision:     $HznReposLastChanged\n";

$date = scalar localtime;
print SCMLOG "-------------------------------------------------------\n";
print SCMLOG "$date` $0 HznRepository      $opt_p $HznReposLastChanged	Dir:$WDIR\n";

# Creating symbolic links to the current build
# This link points to the most recent build for this project (-p)
unlink "$WORKHOME/$opt_p";
symlink($WDIR, "$WORKHOME/$opt_p");

# This link points to the current (most recent) build and is used by mvhzn_push.sh
unlink "$WORKHOME/CURR_BUILD";
symlink($WDIR, "$WORKHOME/CURR_BUILD");

# This link is used by production support and indicates which build is being pushed to production
# It only changes if a production build (-f) is indicated
if($opt_f == 1){
  unlink "$WORKHOME/PROD";
  symlink($WDIR, "$WORKHOME/PROD");
}

# Release notes from SVN
if (open LASTFILE, "<$LastBuild") {
  chomp($last_revision = <LASTFILE>);
  close LASTFILE;
}
else {
  print "File $LastBuild does not exist, creating it\n\n";
  open LASTFILE, ">$LastBuild";
  print LASTFILE "$HznReposLastChanged\n";
  close LASTFILE;
  $last_revision = $HznReposLastChanged;
}

print "Last revision is $last_revision\n";
system("$WORKHOME/getSvnLog.pl -p $opt_p -l $last_revision -r $ReposRev $LOGPARAM");
system("$WORKHOME/pickSvnInfo.pl -f SvnReleaseNotes -o $WDIRC/$opt_p" . "_HznReposScmMinfo -M");   # Short version
system("$WORKHOME/pickSvnInfo.pl -f SvnReleaseNotes -o $WDIRC/$opt_p" . "_HznReposScmInfo");       # Long version
open LASTFILE, ">$LastBuild";
print LASTFILE "$ReposRev\n";
close LASTFILE;

print "BUILD OUTPUT IS IN $WDIR/$0.out\n";
print "BUILD ERROR LOG IS IN $WDIR/$0.err\n";

# Copy code to the push directories
print "\nCopying code to the push directories\n";
chdir $WORKHOME;
system("$WORKHOME/mvhzn_push.sh");

$date = scalar localtime;
print "\nBuild FINISHED at $date\n";

close STDOUT;
close STDERR;
close OUTFILE;
close ERRFILE;
close SCMLOG;
close HZNSCMBUILD;

chdir $WORKHOME;

