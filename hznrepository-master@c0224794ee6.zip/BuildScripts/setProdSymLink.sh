#!/bin/bash

if [ -e /opt/app/users/hznbld/PROD ]
then
  rm /opt/app/users/hznbld/PROD
fi
ln -s $PWD /opt/app/users/hznbld/PROD
