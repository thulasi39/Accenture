#!/bin/ksh

SOURCE_DIRR=CURR_BUILD/Common
echo $SOURCE_DIRR
BIN_OUTPUT_DIRR=CURR_BUILD/push/bin
CTL_OUTPUT_DIRR=CURR_BUILD/push/ctl
SP_OUTPUT_DIRR=CURR_BUILD/push/StoredProcedures

echo "deleting files from output directory $BIN_OUTPUT_DIRR"
rm -f $BIN_OUTPUT_DIRR/*

echo "deleting files from output directory $CTL_OUTPUT_DIRR"
rm -f $CTL_OUTPUT_DIRR/*

#echo "deleting files from output directory $SP_OUTPUT_DIRR"
#rm -f $SP_OUTPUT_DIRR/*

echo "copying bin directory"
cp -f $SOURCE_DIRR/bin/*  $BIN_OUTPUT_DIRR

echo "copying ctl files"
cp -f $SOURCE_DIRR/ctl/*.ctl $CTL_OUTPUT_DIRR

echo "copying stored procedures"
cp -f $SOURCE_DIRR/StoredProcedures/* $SP_OUTPUT_DIRR
chmod 777 $SP_OUTPUT_DIRR/*

echo " All Done!"


