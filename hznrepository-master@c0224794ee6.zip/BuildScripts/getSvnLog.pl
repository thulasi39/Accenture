#!/usr/bin/perl

##--------------------------------------------------------
##  Get differences of two builds from the SVN log command
##--------------------------------------------------------
use Getopt::Std;
use Env qw(WORKHOME);

$USAGE = "USAGE: $0 -p <PROJ> -l <Last Build Revision> -r <Repository Revision> <-b> <-y 9999>\n";
$USAGE = $USAGE . "\tShow the log messages from the given revision through to HEAD using the SVN log command.\n\n";
$USAGE = $USAGE . "\t-p <PROJ>: source safe project name\n\n";
$USAGE = $USAGE . "\t-l <Last Build Revision>: revision # to start with\n\n";
$USAGE = $USAGE . "\t-r <Repository Revision>: current repository revision\n\n";
$USAGE = $USAGE . "\t-b and -y are mutually exclusive.  Only one of them can be specified at a time\n";
$USAGE = $USAGE . "\t-b: use the 'branches' path of SVN (optional parameter)\n";
$USAGE = $USAGE . "\t-y: use the 'tags' path of SVN and include the 4 digit year in the path, for example -y 2013 (optional parameter)\n\n";

getopts('p:l:r:by:');

open SAVEOUT, ">&STDOUT";   # redirecting STDOUT because of buffering issues
open STDOUT, ">SvnReleaseNotes" or die "Can't redirect stdout to SvnReleaseNotes\n";

die $USAGE if(($opt_p eq "") or ($opt_l eq "") or ($opt_r eq "") or (($opt_b == 1) and ($opt_y ne "")));

$SVNPATH = "";
if($opt_b == 1){
  $SVNPATH = "branches/";
}
if($opt_y ne ""){
  $SVNPATH = "tags/$opt_y/";
}

print "Previous build for $opt_p was for revision $opt_l\n\n";
$opt_l++;

print "Current repository revision is $opt_r\n\n";

print "HznRepository Changes\n\n";
print "cmd: svn log -v --revision $opt_l:HEAD svn://scm.it.att.com:12726/HznRepository/$SVNPATH$opt_p\n\n";
system("svn log -v --revision $opt_l:HEAD svn://scm.it.att.com:12726/HznRepository/$SVNPATH$opt_p");

close STDOUT;
open STDOUT, ">&SAVEOUT";
