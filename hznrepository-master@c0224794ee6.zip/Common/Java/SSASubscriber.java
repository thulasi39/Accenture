/*
 *                        AT&T - PROPRIETARY
 *          THIS FILE CONTAINS PROPRIETARY INFORMATION OF
 *        AT&T AND IS NOT TO BE DISCLOSED OR USED EXCEPT IN
 *             ACCORDANCE WITH APPLICABLE AGREEMENTS.
 *
 *          Copyright (c) 2013 AT&T Knowledge Ventures
 *              Unpublished and Not for Publication
 *                     All Rights Reserved
 */

 /*
  * $Id$
  */
package com.att.datarouter.pubsub.ssasubscribe;

import org.eclipse.jetty.servlet.*;
import org.eclipse.jetty.util.ssl.*;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.server.nio.*;
import org.eclipse.jetty.server.ssl.*;

/**
 *	Example stand alone subscriber
 */
public class SSASubscriber {
	private static final int Port = Integer.parseInt(System.getenv("SUBPORT"));
	private static final String KeyStoreType = "jks";
	private static final String KeyStoreFile = "subscriber.jks";
	private static final String KeyStorePassword = "changeit";
	private static final String KeyPassword = "changeit";
	private static final String ContextPath = "/";
	private static final String URLPattern = "/*";

	public static void main(String[] args) throws Exception {
		Server server = new Server();
		SslSelectChannelConnector https = new SslSelectChannelConnector();
		https.setPort(Port);
		https.setMaxIdleTime(30000);
		https.setRequestHeaderSize(8192);
		SslContextFactory cf = https.getSslContextFactory();
		/**Skip SSLv3 Fixes*/
		cf.addExcludeProtocols("SSLv3");
		/**End of SSLv3 Fixes*/	
		cf.setKeyStoreType(KeyStoreType);
		cf.setKeyStorePath(KeyStoreFile);
		cf.setKeyStorePassword(KeyStorePassword);
		cf.setKeyManagerPassword(KeyPassword);
		server.setConnectors(new Connector[] { https });
		ServletContextHandler ctxt = new ServletContextHandler(0);
		ctxt.setContextPath(ContextPath);
		server.setHandler(ctxt);
		ctxt.addServlet(new ServletHolder(new SubscriberServlet()), URLPattern);
		server.start();
	}
}
