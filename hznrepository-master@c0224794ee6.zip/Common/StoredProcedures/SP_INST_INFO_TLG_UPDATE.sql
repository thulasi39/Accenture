CREATE OR REPLACE PROCEDURE SP_INST_INFO_TLG_UPDATE
(
	p_year IN integer,
	p_month IN integer,
	p_errormessage out varchar2
)
IS
BEGIN
	DECLARE
		l_mod_user	varchar2(25);
		NbrOfRecRead number;
		NbrOfRecUpdated number;
		NoCatchUp number;
		l_start_time         DATE;
		l_first_dom			 DATE;
		l_last_dom	DATE;
		c_ip_identifier     VARCHAR2(10); 
		c_device_price	NUMBER(15,2); 
		c_device_down_payment	NUMBER(15,2); 
		c_imei     VARCHAR2(20); 
		c_device_id     NUMBER;
		c_device_status	VARCHAR2(50);
                c_item_id       VARCHAR2(15);
	--*	=============================
		CURSOR tlg_cur IS
		SELECT t.bill_mkt_code, t.ip_identifier, t.device_price, t.device_down_payment,
		t.imei, t.p_imei, t.device_id, t.device_status, t.mod_user,  t.mod_date, 
		t.com_trx_seq_no, t.p_seller_id, t.action_date
		FROM tlg_daily_trans t, Apple_Agents a
		WHERE t.month = p_month and t.year = p_year 
			and t.p_seller_id = a.code				
			and t.contract_type = 'NEXT'
			and t.is_accepted = 'Y' and t.is_valid = 'Y'
			and t.com_trx_seq_no is not null
	        FOR UPDATE OF  
				t.ip_identifier, 
				t.device_price, 
				t.device_down_payment, 
				t.imei, 
				t.p_imei, 
				t.device_id, 
				t.device_status,
                                t.item_id;

--*	=============================================================
	BEGIN
		--*************************************
		--*		Checks Section
		--*************************************
		l_start_time := SYSDATE;
		l_mod_user := 'SP_INST_INF_TLG_UPD';
		NbrOfRecRead := 0;
		NbrOfRecUpdated := 0;
		NoCatchUp := 0;

		l_first_dom := to_date('' || p_month || '/01/' || p_year|| '', 'mm/dd/yyyy');
		l_last_dom := last_day(l_first_dom);
	--*	=============================
		if ( p_month not between 1 and 12 )
		then
			dbms_output.put_line('Not a valid month:[' || p_month||']. Allowed values are 1-12.');
			return ;
		end if;
		if ( p_year not between 2011 and 2050 )
		then
			dbms_output.put_line('Not a valid year:[' || p_year||']. Allowed range is 2011-2050.');
			return;
		end if;
		--*--------------------------------------------------------------------------------------------
		--*************************************
		--*     Update the Apple Agent table from AGT. 
		--*************************************
		
		dbms_output.put_line('---Before FN_GET_APPLE_AGENTS---'|| to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss') );
      		NbrOfRecRead := FN_GET_APPLE_AGENTS (p_year, p_month);
		dbms_output.put_line('---After FN_GET_APPLE_AGENTS---'|| to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss') || ' Nbr of Apple Agts:'|| NbrOfRecRead);

		NbrOfRecRead := 0;
		
		--*--------------------------------------------------------------------------------------------
		--*************************************
		--*     Reset NOT needed as these are updates 
		--*		from TLG as final values for Apple.
		--*************************************
		
		--*************************************
		--*		Loop Section
		--*************************************
		FOR tlg_rec IN tlg_cur
		LOOP
		NbrOfRecRead := NbrOfRecRead +1;
--*		dbms_output.put_line('---Before RecFound---'|| to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss') ||
--*			' - Now p_seller_id:' || tlg_rec.p_seller_id||' ---NbrOfRecRead: '|| NbrOfRecRead ||
--*			' ------------.');
		--*------------------------------------------------------------------
		--* Find a matching transaction(s) in tlg_inst_info_catchup 
		--*------------------------------------------------------------------
		BEGIN  
			SELECT * INTO c_ip_identifier, c_device_price, c_device_down_payment, c_imei,
			c_device_id, c_device_status, c_item_id
			FROM ( 
				SELECT c.ip_identifier, c.device_price, c.device_down_payment, c.imei,
				c.device_id, c.device_status, c.item_id
				FROM tlg_inst_info_catchup c
				WHERE c.month = p_month and c.year = p_year 
				and c.com_trx_seq_no = tlg_rec.com_trx_seq_no
				and c.bill_mkt_code = tlg_rec.bill_mkt_code)
			WHERE ROWNUM = 1;
			EXCEPTION
			WHEN NO_DATA_FOUND THEN
				NoCatchUp := NoCatchUp +1;
				continue;

		END;
--*		dbms_output.put_line('---RecFound---'|| to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss') ||
--*			' - Now p_seller_id:' || tlg_rec.p_seller_id||' - Now NoCatchUp:' || NoCatchUp ||'------------.');

		--*-------------------------------------------------------------------------
		--* Find device_id using the item_id from the tlg_inst_info_catchup table. 
		--*-------------------------------------------------------------------------

		BEGIN  
                        c_device_status := tlg_rec.device_status;

                        SELECT cpc.prod_id
                        INTO c_device_id 
                        FROM cpc_product_catlg cpc
                        WHERE cpc.attrib_name = 'itemID'
                          AND cpc.prod_type = 'Oracle SKU'
                          AND cpc.attrib_value = c_item_id 
                          AND tlg_rec.action_date between 
                              cpc.eff_date and cpc.exp_date
                          AND rownum = 1;
    			EXCEPTION
    			WHEN NO_DATA_FOUND THEN
    				c_device_id := 0;
                                IF c_device_status is NULL or 
                                   c_device_status <> 'IMEI PREVIOUSLY ACTIVATED' THEN  
                                   c_device_status := 'IMEI NOT ELIGIBLE SMARTPHONE';
                                END IF;
		END;

--*-----------------------------------------------------------------------------
--* 	Update info in tlg_daily_trans table!
--*-----------------------------------------------------------------------------
		UPDATE tlg_daily_trans 
		SET 
			ip_identifier = c_ip_identifier,
			device_price = c_device_price,
			device_down_payment = c_device_down_payment,
			imei = c_imei,
			p_imei = c_imei,
			device_id = c_device_id,
			p_device_id = c_device_id,
			device_status = c_device_status,
                        item_id = c_item_id,
			mod_user = l_mod_user,
			mod_date = sysdate
			WHERE CURRENT OF tlg_cur;

		NbrOfRecUpdated := NbrOfRecUpdated +1;
--*		dbms_output.put_line('---After Update---'|| to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss') ||
--*			' - Now p_seller_id:' || tlg_rec.p_seller_id||'------------.');
   
	END LOOP;

	COMMIT;

	dbms_output.put_line ('SP_INST_INFO_TLG_UPDATE for ' || p_month ||'/'||p_year||' !');
	dbms_output.put_line('Totals - Qualified: '|| NbrOfRecRead || ' Updated: '|| NbrOfRecUpdated || 
	' - Not In tlg_inst_info_catchup tbl: '|| NoCatchUp );

	dbms_output.put_line ('Start time (SP_INST_INFO_TLG_UPDATE): ' || 
			to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
	dbms_output.put_line ('End time (SP_INST_INFO_TLG_UPDATE): ' || 
			to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss'));
	END;

END SP_INST_INFO_TLG_UPDATE;
/
