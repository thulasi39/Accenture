CREATE OR REPLACE PROCEDURE SP_WASH_TRANS
(
  p_month    IN INTEGER,
  p_day    IN INTEGER,
  p_year    IN INTEGER,
  p_errormessage	OUT VARCHAR2

)
IS
BEGIN
DECLARE
  v_ddl varchar2(32000);

    type inTBL1 is table of HZN_WASH_GENERIC_RP%rowtype;
    outTBL1 inTBL1;
    type inTBL2 is table of HZN_WASH_MINIMUM_ODD%rowtype;
    outTBL2 inTBL2;
    type inTBL3 is table of HZN_WASH_PAIR_P2PP2X%rowtype;
    outTBL3 inTBL3;
    type inTBL4 is table of HZN_WASH_C16C17%rowtype;
    outTBL4 inTBL4;
    type inTBL5 is table of HZN_WASH_MIN_C16C17%rowtype;
    outTBL5 inTBL5;
    type inTBL6 is table of HZN_WASH_NACC17%rowtype;
    outTBL6 inTBL6;
    type inTBL7 is table of HZN_WASH_MIN_NACC17%rowtype;
    outTBL7 inTBL7;
    type inTBL8 is table of HZN_WASH_C16CAN%rowtype;
    outTBL8 inTBL8;
    type inTBL9 is table of HZN_WASH_MIN_C16CAN%rowtype;
    outTBL9 inTBL9;
              


   p_array_size number:=3000;
   l_start_time	DATE;
   l_finish_time	DATE;
   l_minute_taken	NUMBER (8, 2);


-- p_month is month
-- p_day is day
-- p_year is year



   CURSOR tlg_cur_wash_gen_rp IS
    select  action_date , isd_mobile, product_type, count(*) cnt, mod(count(*),2) oddeven
from tlg_daily_trans TDT
where month=p_month and year=p_year and action_type IN ('NAC','RCL','CAN') and upper(PRODUCT_TYPE)='GENERIC RATE PLAN'
group by action_date, isd_mobile, product_type having count(*) > 1;


   CURSOR tlg_cur_wash_min_odd IS
select a.tlg_daily_trans_key, a.timestamp, a.action_date , a.isd_mobile from tlg_daily_trans a
where
a.tlg_daily_trans_key in (
        select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_generic_rp c
        where b.month=p_month and b.year=p_year and b.isd_mobile=a.isd_mobile and b.action_date=a.action_date and
                b.isd_mobile=c.isd_mobile and b.action_date=c.action_date and oddeven=1)
and upper(a.product_type)='GENERIC RATE PLAN' and month=p_month and year=p_year and a.timestamp is not null;

   CURSOR tlg_cur_wash_p2pp2x IS
SELECT tlg1.tlg_daily_trans_key key1, tlg2.tlg_daily_trans_key key2, tlg1.day, tlg1.month, tlg1.isd_mobile, tlg1.product_code,
tlg1.action_type,tlg1.action_date, tlg1.sys_isd, tlg1.sys_dcd, tlg1.seller_id,
tlg2.isd_mobile mob2, tlg2.product_code pc2, tlg2.action_type at2, tlg2.sys_isd isd2, tlg2.sys_dcd dcd2, tlg2.seller_id si2
FROM tlg_daily_trans TLG1, tlg_daily_trans TLG2 WHERE
     tlg1.MONTH=p_month AND tlg1.YEAR=p_year
    and tlg1.year=tlg2.year and tlg1.month=tlg2.month and
    tlg1.isd_mobile=tlg2.isd_mobile and tlg1.seller_id=tlg2.seller_id
    and tlg2.action_type='P2X' and tlg1.action_type='P2P' and tlg1.sys_isd = tlg2.sys_isd and tlg1.action_date=tlg2.action_date
    and tlg1.product_type='generic rate plan' and tlg2.product_type='generic rate plan'
and tlg1.isd_mobile in (
select isd_mobile from tlg_daily_trans WHERE MONTH=p_month AND YEAR=p_year and action_type in ('P2X','P2P')
HAVING COUNT(*) > 1 GROUP BY ISD_MOBILE
) order by tlg1.isd_mobile;

   CURSOR tlg_cur_wash_c16c17 IS
select current_mobile,action_date , product_code_isd, seller_id, product_id, count(*) cnt, mod(count(*),2) oddeven
from tlg_daily_trans a where month=p_month and year=p_year
and action_type IN ('C16','C17') and
a.current_mobile||a.action_date||a.product_code_isd||a.seller_id||a.product_id IN (select b.current_mobile||b.action_date||b.product_code_isd||b.seller_id||b.product_id from tlg_daily_trans b where b.month=p_month and b.year=p_year and b.action_type='C16' and upper(b.product_type)='GENERIC FEATURE' and (b.event_reason IS NULL OR b.event_reason NOT IN ('CDBRE','CBRE','CUPG','PAYOFF','PAYUP'))) and
a.current_mobile||a.action_date||a.product_code_isd||a.seller_id||a.product_id IN (select b.current_mobile||b.action_date||b.product_code_isd||b.seller_id||b.product_id from tlg_daily_trans b where b.month=p_month and b.year=p_year and b.action_type='C17' and upper(b.product_type)='GENERIC FEATURE' and (b.event_reason IS NULL OR b.event_reason NOT IN ('CDBRE','CBRE','CUPG','PAYOFF','PAYUP')))
group by current_mobile, action_date, product_code_isd, seller_id, product_id having count(*) > 1;

CURSOR tlg_cur_wash_min_c16c17 IS
select a.tlg_daily_trans_key, a.timestamp, a.action_date , a.current_mobile,a.product_code_isd,a.seller_id,a.product_id from tlg_daily_trans a
where
a.tlg_daily_trans_key IN (
        select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_c16c17 c
        where b.month=p_month and b.year=p_year and b.current_mobile=a.current_mobile and b.action_date=a.action_date and
                b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and
                b.current_mobile=c.current_mobile and b.action_date=c.action_date and
                b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=1)
and upper(a.product_type)='GENERIC FEATURE' and month=p_month and year=p_year and a.timestamp is not null;

CURSOR tlg_cur_wash_nacc17 IS
select current_mobile,action_date , product_code_isd, seller_id, product_id, count(*) cnt, mod(count(*),2) oddeven
from tlg_daily_trans a where month=p_month and year=p_year
and action_type IN ('NAC','C17') and
a.current_mobile||a.action_date||a.product_code_isd||a.seller_id||a.product_id IN (select b.current_mobile||b.action_date||b.product_code_isd||b.seller_id||b.product_id from tlg_daily_trans b where b.month=p_month and b.year=p_year and b.action_type='NAC' and upper(b.product_type)='GENERIC FEATURE' and (b.event_reason IS NULL OR b.event_reason NOT IN ('CDBRE','CBRE','CUPG','PAYOFF','PAYUP'))) and
a.current_mobile||a.action_date||a.product_code_isd||a.seller_id||a.product_id IN (select b.current_mobile||b.action_date||b.product_code_isd||b.seller_id||b.product_id from tlg_daily_trans b where b.month=p_month and b.year=p_year and b.action_type='C17' and upper(b.product_type)='GENERIC FEATURE' and (b.event_reason IS NULL OR b.event_reason NOT IN ('CDBRE','CBRE','CUPG','PAYOFF','PAYUP')))
group by current_mobile, action_date, product_code_isd, seller_id, product_id having count(*) > 1;

CURSOR tlg_cur_wash_min_nacc17 IS
select a.tlg_daily_trans_key, a.timestamp, a.action_date , a.current_mobile,a.product_code_isd,a.seller_id,a.product_id from tlg_daily_trans a
where 
a.tlg_daily_trans_key IN (
        select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_nacc17 c
        where b.month=p_month and b.year=p_year and b.current_mobile=a.current_mobile and b.action_date=a.action_date and
                b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and
                b.current_mobile=c.current_mobile and b.action_date=c.action_date and
                b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=1)
and upper(a.product_type)='GENERIC FEATURE' and month=p_month and year=p_year and a.timestamp is not null;

CURSOR tlg_cur_wash_c16can IS
select current_mobile,action_date , product_code_isd, seller_id, product_id, count(*) cnt, mod(count(*),2) oddeven
from tlg_daily_trans a where month=p_month and year=p_year
and action_type IN ('C16','CAN') and
a.current_mobile||a.action_date||a.product_code_isd||a.seller_id||a.product_id IN (select b.current_mobile||b.action_date||b.product_code_isd||b.seller_id||b.product_id from tlg_daily_trans b where b.month=p_month and b.year=p_year and b.action_type='C16' and upper(b.product_type)='GENERIC FEATURE' and (b.event_reason IS NULL OR b.event_reason NOT IN ('CDBRE','CBRE','CUPG','PAYOFF','PAYUP'))) and
a.current_mobile||a.action_date||a.product_code_isd||a.seller_id||a.product_id IN (select b.current_mobile||b.action_date||b.product_code_isd||b.seller_id||b.product_id from tlg_daily_trans b where b.month=p_month and b.year=p_year and b.action_type='CAN' and upper(b.product_type)='GENERIC FEATURE' and (b.event_reason IS NULL OR b.event_reason NOT IN ('CDBRE','CBRE','CUPG','PAYOFF','PAYUP')))
group by current_mobile, action_date, product_code_isd, seller_id, product_id having count(*) > 1;

CURSOR tlg_cur_wash_min_c16can IS
select a.tlg_daily_trans_key, a.timestamp, a.action_date , a.current_mobile,a.product_code_isd,a.seller_id,a.product_id from tlg_daily_trans a
where 
a.tlg_daily_trans_key IN (
        select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_c16can c
        where b.month=p_month and b.year=p_year and b.current_mobile=a.current_mobile and b.action_date=a.action_date and
                b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and
                b.current_mobile=c.current_mobile and b.action_date=c.action_date and
                b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=1)
and upper(a.product_type)='GENERIC FEATURE' and month=p_month and year=p_year and a.timestamp is not null;


-------------------------------------------------------------
-- Get Total count for same isd_mobile, same day,
-- product_type=generic rate plan.
-------------------------------------------------------------

BEGIN

l_start_time := SYSDATE;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_GENERIC_RP(Wash RP Even) Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_GENERIC_RP';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_gen_rp;
  loop
  fetch tlg_cur_wash_gen_rp bulk collect into outTBL1 limit p_array_size;
      forall i in 1..outTBL1.count
          insert into HZN_WASH_GENERIC_RP values outTBL1(i);
        commit;
  exit when tlg_cur_wash_gen_rp%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_gen_rp;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_GENERIC_RP compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash RP Even' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where action_type IN ('||chr(39)||'NAC'||chr(39)||','||chr(39)||'RCL'||chr(39)||','||chr(39)||'CAN'||chr(39)||') and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_generic_rp c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.isd_mobile=a.isd_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.isd_mobile=c.isd_mobile and b.action_date=c.action_date and oddeven=0) ' ;
v_ddl := v_ddl || 'and upper(product_type)='||chr(39)||'GENERIC RATE PLAN'||chr(39)|| ' and month='||p_month|| ' ';
v_ddl := v_ddl || 'and year='||p_year||' and is_washed=' ||chr(39)||'N'||chr(39)||' ' ;

--DBMS_OUTPUT.PUT_LINE('was_generic_rp >>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_GENERIC_RP(Wash RP Even) Completed >>>>> ');

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MINIMUM_ODD(Wash RP Odd) Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_MINIMUM_ODD';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_min_odd;
  loop
  fetch tlg_cur_wash_min_odd bulk collect into outTBL2 limit p_array_size;
      forall i in 1..outTBL2.count
          insert into HZN_WASH_MINIMUM_ODD values outTBL2(i);
        commit;
  exit when tlg_cur_wash_min_odd%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_min_odd;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_MINIMUM_ODD compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash RP Odd' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where a.action_type IN ('||chr(39)||'NAC'||chr(39)||','||chr(39)||'RCL'||chr(39)||','||chr(39)||'CAN'||chr(39)||') and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_minimum_odd c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.isd_mobile=a.isd_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.isd_mobile=c.isd_mobile and b.action_date=c.action_date )';
v_ddl := v_ddl || 'and a.timestamp not in ( select min(c.timestamp) from tlg_daily_trans b, hzn_wash_minimum_odd c ' ;
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.isd_mobile=a.isd_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.isd_mobile=c.isd_mobile and b.action_date=c.action_date )';
v_ddl := v_ddl || 'and upper(a.product_type)='||chr(39)||'GENERIC RATE PLAN'||chr(39)||' and month='||p_month|| ' and year='||p_year|| ' ';
v_ddl := v_ddl || 'and is_washed='||chr(39)||'N'||chr(39)|| ' ';

--DBMS_OUTPUT.PUT_LINE('wash_min_odd >>>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MINIMUM_ODD(Wash RP Odd) Completed >>>>> ');
DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_PAIR_P2PP2X(Wash RP P2P/P2X) Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_PAIR_P2PP2X';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_p2pp2x;
  loop
  fetch tlg_cur_wash_p2pp2x bulk collect into outTBL3 limit p_array_size;
      forall i in 1..outTBL3.count
          insert into HZN_WASH_PAIR_P2PP2X values outTBL3(i);
        commit;
  exit when tlg_cur_wash_p2pp2x%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_p2pp2x;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_PAIR_P2PP2X compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash RP P2P/P2X' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where  a.tlg_daily_trans_key in (select key1 from hzn_wash_pair_p2pp2x) ';
v_ddl := v_ddl || 'and is_washed='||chr(39)||'N'||chr(39)|| ' ';

--DBMS_OUTPUT.PUT_LINE('wash_pair_p2pp2x-key1 >>>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash RP P2P/P2X' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where  a.tlg_daily_trans_key in (select key2 from hzn_wash_pair_p2pp2x) ';
v_ddl := v_ddl || 'and is_washed='||chr(39)||'N'||chr(39)|| ' ';

--DBMS_OUTPUT.PUT_LINE('wash_pair_p2pp2x-key2 >>>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_PAIR_P2PP2X(Wash RP P2P/P2X) Completed >>>>> ');
DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_C16C17(Wash C16/C17 Even) Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_C16C17';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_c16c17;
  loop
  fetch tlg_cur_wash_c16c17 bulk collect into outTBL4 limit p_array_size;
      forall i in 1..outTBL4.count
          insert into HZN_WASH_C16C17 values outTBL4(i);
        commit;
  exit when tlg_cur_wash_c16c17%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_c16c17;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_C16C17 compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash C16/C17 Even' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where a.month=' || p_month||' and a.year=' ||p_year || ' and  a.action_type IN ('||chr(39)||'C16'||chr(39)||','||chr(39)||'C17'||chr(39)||') and ';
v_ddl := v_ddl || 'upper(a.product_type)='||chr(39)||'GENERIC FEATURE'||chr(39)|| ' and (a.event_reason IS NULL OR ';
v_ddl := v_ddl || 'a.event_reason NOT IN (' ||chr(39)||'CDBRE'||chr(39)|| ','||chr(39)||'CBRE'||chr(39)|| ',' ||chr(39)||'CUPG'||chr(39)||','||chr(39)||'PAYOFF'||chr(39)||','||chr(39)||'PAYUP'||chr(39)||')) and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_c16c17 c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.current_mobile=a.current_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and ';
v_ddl := v_ddl || 'b.current_mobile=c.current_mobile and b.action_date=c.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=0)';
v_ddl := v_ddl || ' and is_washed=' ||chr(39)||'N'||chr(39)||' ' ;

--DBMS_OUTPUT.PUT_LINE('was_c16c17 >>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_C16C17(Wash C16/C17 Even) Completed >>>>> ');
DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MIN_C16C17(Wash C16/C17 Odd) Started >>>>> ');


v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_MIN_C16C17';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_min_c16c17;
  loop
  fetch tlg_cur_wash_min_c16c17 bulk collect into outTBL5 limit p_array_size;
      forall i in 1..outTBL5.count
          insert into HZN_WASH_MIN_C16C17 values outTBL5(i);
        commit;
  exit when tlg_cur_wash_min_c16c17%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_min_c16c17;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_MIN_C16C17 compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash C16/C17 Odd' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where a.month=' || p_month||' and a.year=' ||p_year || ' and  a.action_type IN ('||chr(39)||'C16'||chr(39)||','||chr(39)||'C17'||chr(39)||') and ';
v_ddl := v_ddl || 'upper(a.product_type)='||chr(39)||'GENERIC FEATURE'||chr(39)|| ' and (a.event_reason IS NULL OR ';
v_ddl := v_ddl || 'a.event_reason NOT IN (' ||chr(39)||'CDBRE'||chr(39)|| ','||chr(39)||'CBRE'||chr(39)|| ',' ||chr(39)||'CUPG'||chr(39)||','||chr(39)||'PAYOFF'||chr(39)||','||chr(39)||'PAYUP'||chr(39)||')) and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_c16c17 c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.current_mobile=a.current_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and ';
v_ddl := v_ddl || 'b.current_mobile=c.current_mobile and b.action_date=c.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=1)';
v_ddl := v_ddl || ' and is_washed=' ||chr(39)||'N'||chr(39)||' and a.timestamp not in ' ;
v_ddl := v_ddl || '(select min(v.timestamp) from hzn_wash_min_c16c17 v where ';
v_ddl := v_ddl || 'v.current_mobile=a.current_mobile and v.action_date=a.action_date and ';
v_ddl := v_ddl || 'v.product_code_isd=a.product_code_isd and v.seller_id=a.seller_id and v.product_id=a.product_id)';


--DBMS_OUTPUT.PUT_LINE('was_min_c16c17 >>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MIN_C16C17(Wash C16/C17 Odd) Completed >>>>> ');

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_NACC17(Wash NAC/C17 Even) Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_NACC17';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_nacc17;
  loop
  fetch tlg_cur_wash_nacc17 bulk collect into outTBL6 limit p_array_size;
      forall i in 1..outTBL6.count
          insert into HZN_WASH_NACC17 values outTBL6(i);
        commit;
  exit when tlg_cur_wash_nacc17%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_nacc17;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_NACC17 compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash NAC/C17 Even' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where a.month=' || p_month||' and a.year=' ||p_year || ' and  a.action_type IN ('||chr(39)||'NAC'||chr(39)||','||chr(39)||'C17'||chr(39)||') and ';
v_ddl := v_ddl || 'upper(a.product_type)='||chr(39)||'GENERIC FEATURE'||chr(39)|| ' and (a.event_reason IS NULL OR ';
v_ddl := v_ddl || 'a.event_reason NOT IN (' ||chr(39)||'CDBRE'||chr(39)|| ','||chr(39)||'CBRE'||chr(39)|| ',' ||chr(39)||'CUPG'||chr(39)||','||chr(39)||'PAYOFF'||chr(39)||','||chr(39)||'PAYUP'||chr(39)||')) and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_nacc17 c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.current_mobile=a.current_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and ';
v_ddl := v_ddl || 'b.current_mobile=c.current_mobile and b.action_date=c.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=0)';
v_ddl := v_ddl || ' and is_washed=' ||chr(39)||'N'||chr(39)||'  ' ;


--DBMS_OUTPUT.PUT_LINE('wash_nacc17 >>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_NACC17(Wash NAC/C17 Even) Completed >>>>> ');
DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MIN_NACC17(Wash NAC/C17 Odd) Started >>>>> ');


v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_MIN_NACC17';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_min_nacc17;
  loop
  fetch tlg_cur_wash_min_nacc17 bulk collect into outTBL7 limit p_array_size;
      forall i in 1..outTBL7.count
          insert into HZN_WASH_MIN_NACC17 values outTBL7(i);
        commit;
  exit when tlg_cur_wash_min_nacc17%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_min_nacc17;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_MIN_NACC17 compute statistics';

EXECUTE IMMEDIATE v_ddl;



v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash NAC/C17 Odd' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where a.month=' || p_month||' and a.year=' ||p_year || ' and  a.action_type IN ('||chr(39)||'NAC'||chr(39)||','||chr(39)||'C17'||chr(39)||') and ';
v_ddl := v_ddl || 'upper(a.product_type)='||chr(39)||'GENERIC FEATURE'||chr(39)|| ' and (a.event_reason IS NULL OR ';
v_ddl := v_ddl || 'a.event_reason NOT IN (' ||chr(39)||'CDBRE'||chr(39)|| ','||chr(39)||'CBRE'||chr(39)|| ',' ||chr(39)||'CUPG'||chr(39)||','||chr(39)||'PAYOFF'||chr(39)||','||chr(39)||'PAYUP'||chr(39)||')) and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_nacc17 c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.current_mobile=a.current_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and ';
v_ddl := v_ddl || 'b.current_mobile=c.current_mobile and b.action_date=c.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=1)';
v_ddl := v_ddl || ' and is_washed=' ||chr(39)||'N'||chr(39)||' and a.timestamp not in ' ;
v_ddl := v_ddl || '(select min(v.timestamp) from hzn_wash_min_nacc17 v where ';
v_ddl := v_ddl || 'v.current_mobile=a.current_mobile and v.action_date=a.action_date and ';
v_ddl := v_ddl || 'v.product_code_isd=a.product_code_isd and v.seller_id=a.seller_id and v.product_id=a.product_id)';

--DBMS_OUTPUT.PUT_LINE('wash_min_nacc17 >>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MIN_NACC17(Wash NAC/C17 Odd) Completed >>>>> ');
DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_C16CAN(Wash C16/CAN Even) Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_C16CAN';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_c16can;
  loop
  fetch tlg_cur_wash_c16can bulk collect into outTBL8 limit p_array_size;
      forall i in 1..outTBL8.count
          insert into HZN_WASH_C16CAN values outTBL8(i);
        commit;
  exit when tlg_cur_wash_c16can%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_c16can;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_C16CAN compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash C16/CAN Even' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where a.month=' || p_month||' and a.year=' ||p_year || ' and  a.action_type IN ('||chr(39)||'C16'||chr(39)||','||chr(39)||'CAN'||chr(39)||') and ';
v_ddl := v_ddl || 'upper(a.product_type)='||chr(39)||'GENERIC FEATURE'||chr(39)|| ' and (a.event_reason IS NULL OR ';
v_ddl := v_ddl || 'a.event_reason NOT IN (' ||chr(39)||'CDBRE'||chr(39)|| ','||chr(39)||'CBRE'||chr(39)|| ',' ||chr(39)||'CUPG'||chr(39)||','||chr(39)||'PAYOFF'||chr(39)||','||chr(39)||'PAYUP'||chr(39)||')) and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_c16can c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.current_mobile=a.current_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and ';
v_ddl := v_ddl || 'b.current_mobile=c.current_mobile and b.action_date=c.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=0)';
v_ddl := v_ddl || ' and is_washed=' ||chr(39)||'N'||chr(39)||'  ' ;

--DBMS_OUTPUT.PUT_LINE('wash_c16can >>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_C16CAN(Wash C16/CAN Even) Completed >>>>> ');
DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MIN_C16CAN(Wash C16/CAN Odd) Started >>>>> ');


v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_WASH_MIN_C16CAN';

EXECUTE IMMEDIATE v_ddl;


open tlg_cur_wash_min_c16can;
  loop
  fetch tlg_cur_wash_min_c16can bulk collect into outTBL9 limit p_array_size;
      forall i in 1..outTBL9.count
          insert into HZN_WASH_MIN_C16CAN values outTBL9(i);
        commit;
  exit when tlg_cur_wash_min_c16can%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_wash_min_c16can;


v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_WASH_MIN_C16CAN compute statistics';

EXECUTE IMMEDIATE v_ddl;


v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set is_washed='||chr(39)||'Y'||chr(39)|| ' ';
v_ddl := v_ddl || ' , mod_user='  ||chr(39)||'Wash C16/CAN Odd' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate where a.month=' || p_month||' and a.year=' ||p_year || ' and  a.action_type IN ('||chr(39)||'C16'||chr(39)||','||chr(39)||'CAN'||chr(39)||') and ';
v_ddl := v_ddl || 'upper(a.product_type)='||chr(39)||'GENERIC FEATURE'||chr(39)|| ' and (a.event_reason IS NULL OR ';
v_ddl := v_ddl || 'a.event_reason NOT IN (' ||chr(39)||'CDBRE'||chr(39)|| ','||chr(39)||'CBRE'||chr(39)|| ',' ||chr(39)||'CUPG'||chr(39)||','||chr(39)||'PAYOFF'||chr(39)||','||chr(39)||'PAYUP'||chr(39)||')) and ';
v_ddl := v_ddl || 'a.tlg_daily_trans_key in (';
v_ddl := v_ddl || 'select b.tlg_daily_trans_key from tlg_daily_trans b, hzn_wash_c16can c ';
v_ddl := v_ddl || 'where b.month='||p_month|| ' and b.year='||p_year|| ' ' || 'and b.current_mobile=a.current_mobile and b.action_date=a.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=a.product_code_isd and b.seller_id=a.seller_id and b.product_id=a.product_id and ';
v_ddl := v_ddl || 'b.current_mobile=c.current_mobile and b.action_date=c.action_date and ';
v_ddl := v_ddl || 'b.product_code_isd=c.product_code_isd and b.seller_id=c.seller_id and b.product_id=c.product_id and oddeven=1)';
v_ddl := v_ddl || ' and is_washed=' ||chr(39)||'N'||chr(39)||' and a.timestamp not in ' ;
v_ddl := v_ddl || '(select min(v.timestamp) from hzn_wash_min_c16can v where ';
v_ddl := v_ddl || 'v.current_mobile=a.current_mobile and v.action_date=a.action_date and ';
v_ddl := v_ddl || 'v.product_code_isd=a.product_code_isd and v.seller_id=a.seller_id and v.product_id=a.product_id)';

--DBMS_OUTPUT.PUT_LINE('wash_min_c16can >>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('Process for HZN_WASH_MIN_C16CAN(Wash C16/CAN Odd) Completed >>>>> ');

	l_finish_time := sysdate;

	dbms_output.put_line('SP_WASH_TRANS: processing completed for month: '|| p_month  || ' year: ' || p_year);
	l_minute_taken :=  (l_finish_time - l_start_time) *24*60 ;
	l_minute_taken :=  to_number(l_minute_taken , '9999.99') ;
	dbms_output.put_line('SP_WASH_TRANS: Total time taken  =  '|| l_minute_taken ||' Minutes' );


END;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_errormessage := 'WARNING!!! Processing Unsuccessful: ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' );
    DBMS_OUTPUT.put_line(p_errormessage);
    DBMS_OUTPUT.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
    RAISE_APPLICATION_ERROR( -30019, p_errormessage || ' SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM );


END SP_WASH_TRANS;
/
