CREATE OR REPLACE PROCEDURE SP_POS_TLG_UPDATE
(
	p_year IN integer,
	p_month IN integer,
	p_day IN integer,
	p_errormessage out varchar2
)
IS
BEGIN
	DECLARE
		l_device_status	varchar2(50);
		l_mod_user	varchar2(20);
		NbrOfRecRead number;
		NbrOfRecUpdated number;
		NbrOfRecNotInCpc number;
		NotInPOS number;
		NAsku number;
		NotInPOSPrepaid number;
		pd_pos_trans_detail_key NUMBER(28);
		pd_sku	varchar2(20);
		pd_imei	varchar2(20);
		pd_equipment_type	varchar2(20);
		ph_order_date	date;
		cpc_prod_id	NUMBER(28);
		pd_prepaid_sku	varchar2(20);
		pd_sale_price NUMBER(9,2);
		prepaid_pos_trans_detail_key NUMBER(28);
		YesNo varchar2(1);
		l_errmsg   VARCHAR2 (100);
		l_start_time         DATE;
		l_finish_time        DATE;
		l_minute_taken       NUMBER (8, 2);
		l_first_dom			 DATE;
		l_first_nxt_month			 DATE;
		action_month    NUMBER;
		action_year     NUMBER;
		firstFound varchar2(1);
		secondFound varchar2(2);
	--*	============================================================================
		CURSOR tlg_cur IS
		SELECT tlg_daily_trans_key, bill_mkt_code, current_mobile, ban,
		non_mod_seller_id, contract_term, contract_type, action_date, action_type,
		product_code, prev_product_code, imei, event_reason, p_device_id,
		device_id, p_imei,  p_df_indicator, product_family, mod_user,  mod_date
		FROM tlg_daily_trans t
		WHERE month = p_month and year = p_year and day = p_day
			and action_type in ('C16', 'NAC', 'P2P')
			and is_accepted = 'Y' and is_valid = 'Y'
	        FOR UPDATE OF    
				t.p_df_indicator, t.p_device_id,
				t.p_imei,t.p_sku, t.p_prepaid_sku,
				p_prepaid_price, t.pos_trans_detail_key,
				t.mod_user, t.mod_date;

--*	============================================================================
	BEGIN
		--*************************************
		--*		Checks Section
		--*************************************
		l_start_time := SYSDATE;
		l_mod_user := 'SP_POS_TLG_UPDATE';
		NbrOfRecRead := 0;
		NbrOfRecUpdated := 0;
		NbrOfRecNotInCpc := 0;
		NotInPOS := 0;
		NotInPOSPrepaid := 0;
		NAsku := 0;

                dbms_output.put_line('SP_POS_TLG_UPDATE v1.2');

		if ( p_month not between 1 and 12 )
		then
			dbms_output.put_line('Not a valid month:[' || p_month||']. Allowed values are 1-12.');
			return ;
		end if;
		if ( p_year not between 2011 and 2050 )
		then
			dbms_output.put_line('Not a valid year:[' || p_year||']. Allowed range is 2011-2050.');
			return;
		end if;
		
		
		--*************************************
		--*		ReSet  values
		--*************************************
		UPDATE tlg_daily_trans t
		SET
			t.p_df_indicator = t.df_indicator, 
			t.p_device_id = t.device_id,
			t.s_device_id = t.device_id,
			t.p_imei = t.imei,
			t.s_imei = t.imei,
			t.p_sku = NULL,
			t.s_sku = NULL,
			t.p_prepaid_price = NULL,
			t.p_prepaid_sku = NULL,
			t.pos_trans_detail_key = NULL,
			t.mod_user = 'rSP_POS_TLG_UPDATE',
			t.mod_date = sysdate
			WHERE month = p_month and year = p_year and day = p_day
				and action_type in ('C16', 'NAC', 'P2P')
				and is_accepted = 'Y' and is_valid = 'Y'
				and pos_trans_detail_key is not null;
		commit;
		--*************************************
		--*		Loop Section
		--*************************************
			FOR tlg_rec IN tlg_cur
			LOOP
			YesNo := NULL; 
			pd_pos_trans_detail_key := 0;
			prepaid_pos_trans_detail_key := 0;
			NbrOfRecRead := NbrOfRecRead +1;
			action_month := extract(month from tlg_rec.action_date);
			action_year := extract(year from tlg_rec.action_date);

			l_first_dom := to_date('' || action_month || '/01/' || action_year|| '', 'mm/dd/yyyy');
			l_first_nxt_month := last_day(l_first_dom) + 1 ;

			firstFound := 'Y';
			secondFound := 'N';
			pd_prepaid_sku := NULL;
			pd_sale_price := NULL;
			pd_sku := NULL;
			pd_imei := NULL;
			cpc_prod_id := 0;
			--*------------------------------------------------------------------
			--*Find a matching transaction(s) in pos - pick the last one!
			--*------------------------------------------------------------------
			BEGIN  
				SELECT * INTO pd_pos_trans_detail_key, pd_sku, pd_imei,
				pd_equipment_type, ph_order_date 
				FROM (
					SELECT pd.pos_trans_detail_key, trim(pd.sku), pd.imei,
					pd.equipment_type, ph.order_date 
					FROM pos_trans_header ph, pos_trans_detail pd
					WHERE order_timestamp between l_first_dom and l_first_nxt_month
					and extract(year from pd.order_timestamp) = 
							extract(year from tlg_rec.action_date)
					and extract(month from pd.order_timestamp) = 
							extract(month from tlg_rec.action_date)
					and extract(day from pd.order_timestamp) = 
							extract(day from tlg_rec.action_date)
					and ph.order_id = pd.order_id
					and ph.ban = pd.ban
					and pd.record_type = 'WIRELESS'
					and tlg_rec.current_mobile = pd.mobile
					and tlg_rec.ban = pd.ban
					and tlg_rec.non_mod_seller_id = ph.seller_id
					and tlg_rec.contract_term = pd.contract_term
					AND tlg_rec.contract_type = (CASE 
						WHEN tlg_rec.contract_type = 'STD' 
							and upper(trim(pd.contract_type)) = 'SERVICE' 
								THEN tlg_rec.contract_type
						WHEN tlg_rec.contract_type = 'NEXT' 
							and upper(trim(pd.contract_type)) = 'INSTLMNT' 
								THEN tlg_rec.contract_type 
						END)
					AND tlg_rec.action_type = (CASE
						WHEN tlg_rec.action_type = 'NAC'
							and (upper(trim(pd.transaction_type)) = 'ACT' 
								OR upper(trim(pd.transaction_type)) = 'NEW-TITAN-PROVISION')
							and upper(trim(pd.event_type)) = 'RATEPLAN ADDED' 
							and tlg_rec.product_code = trim(pd.product_code)  
								THEN tlg_rec.action_type
						WHEN tlg_rec.action_type = 'C16' 
							and upper(tlg_rec.event_reason) like '%BRE%' 
							and upper(trim(pd.event_type)) = 'UPGRADE ADDED'
							and upper(pd.transaction_type) like '%BRE%'
							and tlg_rec.prev_product_code = trim(pd.product_code) 
								THEN tlg_rec.action_type
						WHEN tlg_rec.action_type = 'C16' 
							and (upper(tlg_rec.event_reason) NOT like '%BRE%'  OR tlg_rec.event_reason is null)
							and upper(trim(pd.event_type)) = 'UPGRADE ADDED'
							and upper(pd.transaction_type) NOT like '%BRE%' 
							and tlg_rec.prev_product_code = trim(pd.product_code) 
								THEN tlg_rec.action_type
						WHEN tlg_rec.action_type = 'P2P' 
							and upper(trim(pd.event_type)) = 'RATEPLAN ADDED'
							and upper(pd.transaction_type) like '%SWITCH%'
							and tlg_rec.product_code = trim(pd.product_code) 
								THEN tlg_rec.action_type
						END)
					ORDER BY pd.order_timestamp DESC)
				WHERE ROWNUM = 1;

			   EXCEPTION
				WHEN NO_DATA_FOUND THEN
					NotInPOS := NotInPOS +1;
					firstFound := 'N';
	    	END;
--*------------------------------------------------------------------------
--*	Get the device_id from the cpc table
--*------------------------------------------------------------------------
            if ( firstFound='Y') then
		BEGIN
			cpc_prod_id := 0;

			if ( pd_sku is NOT null ) then
				SELECT c.prod_id into cpc_prod_id
				FROM cpc_product_catlg c
				WHERE upper(c.prod_type) = 'ORACLE SKU'
					and upper(c.attrib_name) = 'PRODUCTCODE'
					and upper(c.attrib_value) = upper(pd_sku)
					and ph_order_date between c.eff_date and c.exp_date;
			else
				NAsku := NAsku +1;
			end if;

		   EXCEPTION
				WHEN NO_DATA_FOUND THEN
					NbrOfRecNotInCpc := NbrOfRecNotInCpc +1;
		END;

		if ( upper(trim(pd_equipment_type)) = 'DF' and pd_imei is null ) then 
			YesNo := 'Y';
		end if;
	    end if;
--*------------------------------------------------------------------------
--*  start COR changes to populate prepaid sku and price for Prepaid trans only
--*------------------------------------------------------------------------
             if (tlg_rec.product_family like '%PREPAID%' ) then
	        secondFound := 'Y';

		BEGIN  
				SELECT * INTO  prepaid_pos_trans_detail_key,pd_prepaid_sku, pd_sale_price
				FROM (
					SELECT pd.pos_trans_detail_key,pd.sku,pd.sale_price
					FROM pos_trans_header ph, pos_trans_detail pd, cpc_product_catlg c,cpc_product_catlg c1
					WHERE order_timestamp between l_first_dom and l_first_nxt_month
					and extract(year from pd.order_timestamp) = 
							extract(year from tlg_rec.action_date)
					and extract(month from pd.order_timestamp) = 
							extract(month from tlg_rec.action_date)
					and extract(day from pd.order_timestamp) = 
							extract(day from tlg_rec.action_date)
					and ph.order_id = pd.order_id
					and ph.ban = pd.ban
					and pd.record_type = 'WIRELESS'
					and pd.transaction_type = 'STANDALONE'
					and tlg_rec.current_mobile = pd.mobile
					--and tlg_rec.non_mod_seller_id = ph.seller_id					
					and upper(c.attrib_value) = upper(pd.sku)	
					and c.prod_id = c1.prod_id
					and upper(c.prod_type) = 'ORACLE SKU'
					and upper(c.attrib_name) = 'PRODUCTCODE'
					and ph.order_date between c.eff_date and c.exp_date
					and upper(c1.prod_type) = 'ORACLE SKU'
					and upper(c1.attrib_name) = 'PRODUCTFAMILY'
					and upper(c1.attrib_value) = 'PREPAID'
					and ph.order_date between c1.eff_date and c1.exp_date
				
					ORDER BY pd.order_timestamp DESC)
				WHERE ROWNUM = 1;

			   EXCEPTION
				WHEN NO_DATA_FOUND THEN
					NotInPOSPrepaid := NotInPOSPrepaid +1;
					secondFound := 'N';
					--continue;
		END;

 --*-----------------------------------------------------------------------------
  
	      end if; 
 --*-----------------------------------------------------------------------------
 --* end COR changes to populate prepaid sku and price for Prepaid trans only
 --*-----------------------------------------------------------------------------


		if ( firstFound='Y' or secondFound='Y') then

			if (firstFound='Y') then
                          if cpc_prod_id = 0 or cpc_prod_id is null
                          then
                            cpc_prod_id := tlg_rec.p_device_id;
                          end if;
			UPDATE tlg_daily_trans 
			SET 
				p_df_indicator = YesNo, 
				p_device_id = cpc_prod_id,
				s_device_id = cpc_prod_id,
				p_imei = pd_imei,
				s_imei = pd_imei,
				p_sku = NVL(pd_sku,'NA'),
				s_sku = NVL(pd_sku,'NA'),
				p_prepaid_price = pd_sale_price,
				p_prepaid_sku = pd_prepaid_sku,
				pos_trans_detail_key = pd_pos_trans_detail_key,
				mod_user = 'aSP_POS_TLG_UPDATE',
				mod_date = sysdate
				WHERE CURRENT OF tlg_cur;
			end if;

			if (secondFound='Y') then
			UPDATE tlg_daily_trans 
			SET 
				p_prepaid_price = pd_sale_price,
				p_prepaid_sku = pd_prepaid_sku,
				pos_trans_detail_key = decode(pd_pos_trans_detail_key,0,prepaid_pos_trans_detail_key, pd_pos_trans_detail_key),
				mod_user = 'cSP_POS_TLG_UPDATE',
				mod_date = sysdate
				WHERE CURRENT OF tlg_cur;
			end if;

		NbrOfRecUpdated := NbrOfRecUpdated +1;
		end if;

		END LOOP;

		COMMIT;

		dbms_output.put_line ('SP_POS_TLG_UPDATE for ' || p_month ||'/'||p_day||'/'||p_year||'.');
		dbms_output.put_line('Totals - Qualified: '|| NbrOfRecRead || ' Updated: '|| NbrOfRecUpdated || 
				' Not In POS: '|| NotInPOS ||' Not In Cpc: '|| NbrOfRecNotInCpc || ' Not In POS Prepaid: '|| NotInPOSPrepaid || ' for SP_POS_TLG_UPDATE' );

		dbms_output.put_line ('***NAsku: ' || NAsku );
		l_finish_time := SYSDATE;

		dbms_output.put_line ('Start time (SP_POS_TLG_UPDATE): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
		dbms_output.put_line ('End time (SP_POS_TLG_UPDATE): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));
END;

END SP_POS_TLG_UPDATE;
/
