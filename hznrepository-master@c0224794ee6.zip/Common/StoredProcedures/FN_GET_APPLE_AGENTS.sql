CREATE OR REPLACE FUNCTION FN_GET_APPLE_AGENTS (
	p_year IN integer,
	p_month IN integer)
   RETURN INTEGER
IS
		l_rowcount	number;

   --****************************************************
   --*    This function return the number of the agent codes in Apple_Agents 
   --*    table. The function uses month and year to look up the
   --*    EFF and EXP dates for the given agent code.
   --****************************************************

BEGIN
	DECLARE
		l_first_dom	DATE;
		l_last_dom	DATE;
		l_curr_time	DATE;

	BEGIN
		l_first_dom := to_date('' || p_month || '/01/' || p_year|| '', 'mm/dd/yyyy');
		l_last_dom := last_day(l_first_dom);
--*-------------------------------------------------------------------		
	   BEGIN
			l_curr_time := SYSDATE;
			dbms_output.put_line ( 'Truncating APPLE_AGENTS - '|| to_char(l_curr_time, 'mm/dd/yyyy hh24:mi:ss') );
			DELETE Apple_Agents;
			commit;
			l_curr_time := SYSDATE;
			dbms_output.put_line ( 'APPLE_AGENTS truncated - ' || to_char(l_curr_time, 'mm/dd/yyyy hh24:mi:ss') );
	   END;
--*-------------------------------------------------------------------		
	   BEGIN
			l_curr_time := SYSDATE;
			dbms_output.put_line ( 'INSERTing into Apple_Agents - ' || to_char(l_curr_time, 'mm/dd/yyyy hh24:mi:ss') );
			INSERT INTO Apple_Agents(locations_key, code, agents_key, 
			master_agent_key, eff_date, exp_date, mod_user, mod_date) 
			SELECT h.locations_key, h.code, h.agents_key, d.master_agent_key, 
			d.eff_date, d.exp_date, 'FN_GET_APPLE_AGENTS', sysdate
			FROM r_agent_header h, r_agent_detail d
			WHERE d.master_agent_key = 
				(select m.agents_key from r_agent_header m
					where m.code = 'APPLEMASTER'
					and l_first_dom between m.eff_date and m.exp_date
					and l_last_dom between m.eff_date and m.exp_date )
			and  h.agents_key = d.agents_key
			and l_first_dom between d.eff_date and d.exp_date
			and l_last_dom between d.eff_date and d.exp_date
			and l_first_dom between h.eff_date and h.exp_date
			and l_last_dom between h.eff_date and h.exp_date;
			
			l_rowcount := SQL%ROWCOUNT;
			COMMIT;
			
			l_curr_time := SYSDATE;
			dbms_output.put_line ( 'Apple_Agents is ready - ' || to_char(l_curr_time, 'mm/dd/yyyy hh24:mi:ss') );
			dbms_output.put_line ('Table Apple_Agents created with '|| l_rowcount ||' rows!');
	   END;
--*-------------------------------------------------------------------		
   END;

   RETURN l_rowcount;
END FN_GET_APPLE_AGENTS;
/
