CREATE OR REPLACE PROCEDURE SP_UPDATE_EOD_NAC_PROD_CODES
(
  p_month    IN INTEGER,
  p_year    IN INTEGER,
  p_errormessage	OUT VARCHAR2

)
IS
BEGIN
DECLARE
  v_ddl varchar2(32000);


    type inTBL10 is table of HZN_MULTIPLE_SVC%rowtype;
    outTBL10 inTBL10;
    type inTBL11 is table of HZN_SVC_MAX_TS%rowtype;
    outTBL11 inTBL11;
    type inTBL12 is table of HZN_SVC_MAX_KEY%rowtype;
    outTBL12 inTBL12;
    type inTBL13 is table of HZN_NAC_SVC_EOD%rowtype;
    outTBL13 inTBL13;                


  p_array_size number:=3000;
  	l_start_time	DATE;
	l_finish_time	DATE;
	l_minute_taken	NUMBER (8, 2);


-- p_month is month
-- p_day is day
-- p_year is year



   CURSOR tlg_cur_multi_svc IS
select current_mobile,action_type, action_date, count(*) cnt
from tlg_daily_trans 
where month=p_month and year=p_year and action_type='SVC' group by current_mobile,action_type, action_date having count(*) >= 1;


   CURSOR tlg_cur_svc_max_ts IS
select max(timestamp) ts, current_mobile, action_date from tlg_daily_trans where month=p_month and year=p_year and action_type='SVC' and 
current_mobile||action_date in (select current_mobile||action_date from hzn_multiple_svc) group by current_mobile, action_date;

   CURSOR tlg_cur_svc_max_key IS
select max(tlg_daily_trans_key) key, current_mobile, action_date from tlg_daily_trans  a where month=p_month and year=p_year and action_type='SVC' 
and current_mobile||action_date in (select current_mobile||action_date from 
hzn_svc_max_ts b where b.ts=a.timestamp) group by current_mobile, action_date;

   CURSOR tlg_cur_nac_svc_eod IS
select a.tlg_daily_trans_key, a.current_mobile, a.action_type, a.action_date, a.product_code NAC_PRODUCT_CODE, c.product_code SVC_EOD_PRODUCT_CODE 
from tlg_daily_trans a, hzn_svc_max_key b, tlg_daily_trans c
where a.month=p_month and a.year=p_year and a.action_type='NAC' and 
a.tlg_daily_trans_key=(select max(tlg_daily_trans_key) from tlg_daily_trans d where d.month=p_month and d.year=p_year 
and d.current_mobile=a.current_mobile and d.action_date=a.action_date and d.action_type='NAC') and 
a.current_mobile=b.current_mobile and
a.action_date=b.action_date and
b.key=c.tlg_daily_trans_key and
c.product_code!=a.product_code and 
c.timestamp>a.timestamp and 
a.eod_product_code is null;




BEGIN

l_start_time := SYSDATE;

DBMS_OUTPUT.PUT_LINE('SP_UPDATE_EOD_NAC_PROD_CODES Process Started >>>>> ');

DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_MULTIPLE_SVC Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_MULTIPLE_SVC';

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_MULTIPLE_SVC Completed >>>>> ');

DBMS_OUTPUT.PUT_LINE('Inserting into HZN_MULTIPLE_SVC Table Started >>>>> ');

open tlg_cur_multi_svc;
  loop
  fetch tlg_cur_multi_svc bulk collect into outTBL10 limit p_array_size;
      forall i in 1..outTBL10.count
          insert into HZN_MULTIPLE_SVC values outTBL10(i);
        commit;
  exit when tlg_cur_multi_svc%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_multi_svc;
  
  
DBMS_OUTPUT.PUT_LINE('Inserting into HZN_MULTIPLE_SVC Table Completed >>>>> ');

DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_MULTIPLE_SVC Table Started >>>>> ');

v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_MULTIPLE_SVC compute statistics';

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_MULTIPLE_SVC Table Completed >>>>> ');


DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_SVC_MAX_TS Table Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_SVC_MAX_TS';

EXECUTE IMMEDIATE v_ddl;

DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_SVC_MAX_TS Table Completed >>>>> ');

DBMS_OUTPUT.PUT_LINE('Inserting into HZN_SVC_MAX_TS Table Started >>>>> ');

open tlg_cur_svc_max_ts;
  loop
  fetch tlg_cur_svc_max_ts bulk collect into outTBL11 limit p_array_size;
      forall i in 1..outTBL11.count
          insert into HZN_SVC_MAX_TS values outTBL11(i);
        commit;
  exit when tlg_cur_svc_max_ts%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_svc_max_ts;

  DBMS_OUTPUT.PUT_LINE('Inserting into HZN_SVC_MAX_TS Table Completed >>>>> ');
  
  DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_SVC_MAX_TS Table Started >>>>> ');

v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_SVC_MAX_TS compute statistics';

EXECUTE IMMEDIATE v_ddl;

  DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_SVC_MAX_TS Table Completed >>>>> ');
  
  DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_SVC_MAX_KEY Table Started >>>>> ');

v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_SVC_MAX_KEY';

EXECUTE IMMEDIATE v_ddl;

  DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_SVC_MAX_KEY Table Completed >>>>> ');
  
  DBMS_OUTPUT.PUT_LINE('Inserting into HZN_SVC_MAX_KEY Table Started >>>>> ');

open tlg_cur_svc_max_key;
  loop
  fetch tlg_cur_svc_max_key bulk collect into outTBL12 limit p_array_size;
      forall i in 1..outTBL12.count
          insert into HZN_SVC_MAX_KEY values outTBL12(i);
        commit;
  exit when tlg_cur_svc_max_key%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_svc_max_key;

    DBMS_OUTPUT.PUT_LINE('Inserting into HZN_SVC_MAX_KEY Table Completed >>>>> ');
    
    DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_SVC_MAX_KEY Table Started >>>>> ');

v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_SVC_MAX_KEY compute statistics';

EXECUTE IMMEDIATE v_ddl;

    DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_SVC_MAX_KEY Table Completed >>>>> ');

    DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_NAC_SVC_EOD Table Started >>>>> ');
    
v_ddl :=' ';
v_ddl := 'TRUNCATE TABLE HZN_NAC_SVC_EOD';

EXECUTE IMMEDIATE v_ddl;

    DBMS_OUTPUT.PUT_LINE('TRUNCATE TABLE HZN_NAC_SVC_EOD Table Completed >>>>> ');
    
    DBMS_OUTPUT.PUT_LINE('Inserting into HZN_NAC_SVC_EOD Table Started >>>>> ');

open tlg_cur_nac_svc_eod;
  loop
  fetch tlg_cur_nac_svc_eod bulk collect into outTBL13 limit p_array_size;
      forall i in 1..outTBL13.count
          insert into HZN_NAC_SVC_EOD values outTBL13(i);
        commit;
  exit when tlg_cur_nac_svc_eod%NOTFOUND;
  end loop;
  commit;
  close tlg_cur_nac_svc_eod;

     DBMS_OUTPUT.PUT_LINE('Inserting into HZN_NAC_SVC_EOD Table Completed >>>>> ');
     
        DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_NAC_SVC_EOD Table Started >>>>> ');

v_ddl :=' ';
v_ddl := 'ANALYZE TABLE HZN_NAC_SVC_EOD compute statistics';

EXECUTE IMMEDIATE v_ddl;

        DBMS_OUTPUT.PUT_LINE('ANALYZE TABLE HZN_NAC_SVC_EOD Table Completed >>>>> ');
        
        DBMS_OUTPUT.PUT_LINE('Updating tlg_daily_trans Table Started >>>>> ');

v_ddl := ' ';
v_ddl := 'UPDATE tlg_daily_trans a set ';
v_ddl := v_ddl || '  mod_user='  ||chr(39)||'EOD_PROD_CODE_UPD' ||chr(39)||' ';
v_ddl := v_ddl || ',mod_date=sysdate, eod_product_code=(select SVC_EOD_PRODUCT_CODE from hzn_nac_svc_eod b where b.current_mobile=a.current_mobile and ';
v_ddl := v_ddl || 'b.action_date=a.action_date) where a.month=' ||p_month|| ' and a.year=' || p_year || ' and ';
v_ddl := v_ddl || 'a.action_type='||chr(39)||'NAC'||chr(39)|| ' and a.eod_product_code is null  and ';
v_ddl := v_ddl || 'a.current_mobile||a.action_date in (select c.current_mobile||c.action_date from hzn_nac_svc_eod c)';

--DBMS_OUTPUT.PUT_LINE('nac_svc_eod >>>>>v_ddl: '||v_ddl);

EXECUTE IMMEDIATE v_ddl;

    DBMS_OUTPUT.PUT_LINE('Updating tlg_daily_trans Table Completed >>>>> ');

	l_finish_time := sysdate;

	dbms_output.put_line('SP_UPDATE_EOD_NAC_PROD_CODES: processing completed for month: '|| p_month  || ' year: ' || p_year);
	l_minute_taken :=  (l_finish_time - l_start_time) *24*60 ;
	l_minute_taken :=  to_number(l_minute_taken , '9999.99') ;
	dbms_output.put_line('SP_UPDATE_EOD_NAC_PROD_CODES: Total time taken  =  '|| l_minute_taken ||' Minutes' );


END;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_errormessage := 'WARNING!!! Processing Unsuccessful: ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' );
    DBMS_OUTPUT.put_line(p_errormessage);
    DBMS_OUTPUT.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
    RAISE_APPLICATION_ERROR( -30019, p_errormessage || ' SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM );


END SP_UPDATE_EOD_NAC_PROD_CODES;
/
