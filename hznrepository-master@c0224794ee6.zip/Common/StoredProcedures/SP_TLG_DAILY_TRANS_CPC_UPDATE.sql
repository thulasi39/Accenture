CREATE OR REPLACE PROCEDURE SP_TLG_DAILY_TRANS_CPC_UPDATE
( 
  p_Month IN integer, 
  p_Day IN integer, 
  p_Year IN integer
)
IS
  ProductID NUMBER(28);
  TempProductID NUMBER(28);
  ProductName varchar2(50);
  ProductSubcatID NUMBER(28);
  ProductSubcatName varchar2(50);
  ProductCatID NUMBER(28);
  ProductCatName varchar2(50);
  ProductFamily VARCHAR2(255);
  CompRevenue NUMBER(10,2);
  PrevProductID NUMBER(28);
  PrevProductSubcatID NUMBER(28);
  PrevProductSubcatName varchar2(50);
  PrevProductCatID NUMBER(28);
  PrevProductCatName varchar2(50);
  PrevProductCodeDesc varchar2(50);
  PrevProductCodeRate NUMBER(10,2);
  DataCapacityID NUMBER(28);
  DeviceDataID NUMBER(28);
  DailyTransCounter INTEGER;
  UpdateCounter INTEGER;
  UpdateFlag INTEGER;
  UpdateCompRevenue INTEGER;
  StartTime DATE;
  EndTime Date;
      
-- tlg_daily_trans cursor
  CURSOR tlg_daily_trans_cursor IS
    SELECT action_date, com_trx_seq_no, product_code, prev_product_code, 
           nvl(mobile_type,' ') mobile_type, product_type, action_type, nvl(prev_mobile_type,' ') prev_mobile_type,
           comp_revenue, prev_product_code_rate, data_capacity_code, device_data_code 
    FROM tlg_daily_trans
    WHERE year = p_Year
      AND month = p_Month
      AND day = p_Day
  FOR UPDATE OF product_id, p_product_id, product_name, product_subcat_id,
                product_subcat_name, product_cat_id, product_cat_name,
                comp_revenue, product_family, prev_product_id, prev_product_subcat_id,
                prev_product_subcat_name, prev_product_cat_id, prev_product_cat_name,
                prev_product_code_desc, prev_product_code_rate, data_capacity_id, device_data_id,
                mod_user, mod_date; 
-- tlg_daily_trans record             
  tlg_daily_rec tlg_daily_trans_cursor%rowtype;
  
-- CPC cursor  
  CURSOR cpc_cursor IS
    SELECT *
    FROM cpc_product_catlg  a
    WHERE a.PROD_ID = ProductID
      AND tlg_daily_rec.action_date between a.eff_date and a.exp_date;
-- CPC record
    cpc_rec cpc_cursor%rowtype;
    
BEGIN
  DailyTransCounter := 0;
  UpdateCounter := 0;
  StartTime := SYSTIMESTAMP;
  DBMS_OUTPUT.ENABLE( buffer_size => NULL );
  DBMS_OUTPUT.PUT_LINE( 'SP_TLG_DAILY_TRANS_CPC_UPDATE v1.7' );
  DBMS_OUTPUT.PUT_LINE( 'Start Time: ' || to_char( StartTime, 'YYYY-MM-DD HH24:MI:SS' ));
  DBMS_OUTPUT.PUT_LINE( 'p_Year = ' || p_Year || ', p_Month = ' || p_Month || ', p_Day = ' || p_Day );
  
  OPEN tlg_daily_trans_cursor;
  DBMS_OUTPUT.PUT_LINE( 'Opened tlg_daily_trans cursor' );
  
  FETCH tlg_daily_trans_cursor into tlg_daily_rec;
  -- If no records in cursor.
  IF tlg_daily_trans_cursor%NOTFOUND
  THEN
    DBMS_OUTPUT.PUT_LINE( 'NO records in tlg_daily_trans cursor' );
  END IF;

  -- Loop through tlg_daily_trans records found looking for match in CPC.
  WHILE tlg_daily_trans_cursor%FOUND 
  LOOP
    UpdateFlag := 0; UpdateCompRevenue := 0;
    DailyTransCounter := DailyTransCounter + 1;
    ProductName := NULL; ProductSubcatID := NULL; ProductSubcatName := NULL; ProductCatID := NULL;
    ProductCatName := NULL; CompRevenue := NULL; ProductFamily := NULL;
    PrevProductID := NULL; PrevProductSubcatID := NULL; 
    PrevProductSubcatName := NULL; PrevProductCatID := NULL; 
    PrevProductCatName := NULL; PrevProductCodeDesc := NULL; 
    PrevProductCodeRate := NULL;
    DataCapacityID := NULL; DeviceDataID := NULL;

    -- Only want to update COMP_REVENUE and PREV_PRODUCT_CODE_RATE on these events.
    IF tlg_daily_rec.action_type = 'NAC' OR
       tlg_daily_rec.action_type = 'CAN' OR
       tlg_daily_rec.action_type = 'RCL' OR
       tlg_daily_rec.action_type = 'C16' OR
       tlg_daily_rec.action_type = 'C17' OR
       tlg_daily_rec.action_type = 'P2P' OR
       tlg_daily_rec.action_type = 'P2X'
    THEN
      UpdateCompRevenue := 1;
      CompRevenue := tlg_daily_rec.comp_revenue;
      PrevProductCodeRate := tlg_daily_rec.prev_product_code_rate;
    END IF;

    -- If product_code is populated, try to update CPC fields.
    IF tlg_daily_rec.product_code is not null
    THEN
      ---------------------------------------------------------                         
      -- Search CPC using product_code to get the product id.
      ---------------------------------------------------------
      BEGIN
        SELECT NVL(PROD_ID,0)
        INTO ProductID
        FROM cpc_product_catlg
        WHERE attrib_value = tlg_daily_rec.product_code 
          AND attrib_name = 'productCode' 
          AND (prod_type = 'generic rate plan' or prod_type = 'generic feature')
          AND tlg_daily_rec.action_date between eff_date and exp_date;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          ProductID := NULL;
      END;
        
      ---------------------------------------------------------
      -- Search through CPC attributes, pick ones needed.
      ---------------------------------------------------------
      BEGIN
        IF ProductID > 0
        THEN
          OPEN cpc_cursor;
          FETCH cpc_cursor into cpc_rec;
          WHILE cpc_cursor%FOUND LOOP
            IF cpc_rec.attrib_name = 'catalogProductName'
            THEN
              ProductName := SUBSTR(cpc_rec.attrib_value,1,50);
              UpdateFlag := 1;
            ELSIF cpc_rec.attrib_name = 'commissionSubCategoryID' THEN
              ProductSubcatID := cpc_rec.attrib_value;
              UpdateFlag := 1;
            ELSIF cpc_rec.attrib_name = 'commissionSubCategoryName' THEN
              ProductSubcatName := SUBSTR(cpc_rec.attrib_value,1,50);
              UpdateFlag := 1;
            ELSIF cpc_rec.attrib_name = 'commissionCategoryID' THEN
              ProductCatID := cpc_rec.attrib_value;
              UpdateFlag := 1;
            ELSIF cpc_rec.attrib_name = 'commissionCategoryName' THEN
              ProductCatName := SUBSTR(cpc_rec.attrib_value,1,50);
              UpdateFlag := 1;
            ELSIF (cpc_rec.attrib_name = 'secondaryCompRevenue') AND (tlg_daily_rec.mobile_type = 'S') AND (UpdateCompRevenue > 0) THEN
              CompRevenue := cpc_rec.attrib_value;
              UpdateFlag := 1;
            ELSIF (cpc_rec.attrib_name = 'compRevenue') AND (tlg_daily_rec.mobile_type != 'S') AND (UpdateCompRevenue > 0) THEN
              CompRevenue := cpc_rec.attrib_value;                   
              UpdateFlag := 1;
            ELSE
              IF cpc_rec.attrib_name = 'productFamily' THEN
                ProductFamily := cpc_rec.attrib_value;
                UpdateFlag := 1;
              END IF;
            END IF;
            FETCH cpc_cursor into cpc_rec;
          END LOOP;
          CLOSE cpc_cursor;
        END IF;
      END;
    END IF;

    -- If prev_product_code is populated, try to update CPC fields.
    IF tlg_daily_rec.prev_product_code is not null
    THEN
      ---------------------------------------------------------                         
      -- Search CPC using prev_product_code get the product id.
      ---------------------------------------------------------
      BEGIN
        SELECT NVL(PROD_ID,0)
        INTO PrevProductID
        FROM cpc_product_catlg
        WHERE attrib_value = tlg_daily_rec.prev_product_code 
          AND attrib_name = 'productCode' 
          AND (prod_type = 'generic rate plan' or prod_type = 'generic feature')
          AND tlg_daily_rec.action_date between eff_date and exp_date;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          PrevProductID := NULL;
      END;
        
      ---------------------------------------------------------
      -- Search through CPC attributes, pick ones needed.
      ---------------------------------------------------------
      BEGIN
        IF PrevProductID > 0
        THEN
          TempProductID := ProductID;
          ProductID := PrevProductID;
          OPEN cpc_cursor;
          FETCH cpc_cursor into cpc_rec;
          WHILE cpc_cursor%FOUND LOOP
            IF cpc_rec.attrib_name = 'commissionSubCategoryID' THEN
              PrevProductSubcatID := cpc_rec.attrib_value;
              UpdateFlag := 1;
            ELSIF cpc_rec.attrib_name = 'commissionSubCategoryName' THEN
              PrevProductSubcatName := SUBSTR(cpc_rec.attrib_value,1,50);
              UpdateFlag := 1;
            ELSIF cpc_rec.attrib_name = 'commissionCategoryID' THEN
              PrevProductCatID := cpc_rec.attrib_value;
              UpdateFlag := 1;
            ELSIF cpc_rec.attrib_name = 'commissionCategoryName' THEN
              PrevProductCatName := SUBSTR(cpc_rec.attrib_value,1,50); 
              UpdateFlag := 1;
            ELSIF (cpc_rec.attrib_name = 'secondaryCompRevenue') AND (tlg_daily_rec.mobile_type = 'S') AND (UpdateCompRevenue > 0) THEN
              PrevProductCodeRate := cpc_rec.attrib_value;
              UpdateFlag := 1;
            ELSIF (cpc_rec.attrib_name = 'compRevenue') AND (tlg_daily_rec.mobile_type != 'S') AND (UpdateCompRevenue > 0) THEN
              PrevProductCodeRate := cpc_rec.attrib_value;
              UpdateFlag := 1;
            ELSE
              IF cpc_rec.attrib_name = 'description' THEN
                PrevProductCodeDesc := SUBSTR(cpc_rec.attrib_value,1,50);
                UpdateFlag := 1;
              END IF;
            END IF;
            FETCH cpc_cursor into cpc_rec;
          END LOOP;
          CLOSE cpc_cursor;
          ProductID := TempProductID;
        END IF;
      END;
    END IF;

    -- If data_capacity_code is populated, try to update CPC fields.
    IF tlg_daily_rec.data_capacity_code is not null
    THEN
      ---------------------------------------------------------                         
      -- Search CPC using data_capacity_code to get the product id.
      ---------------------------------------------------------
      BEGIN
        SELECT NVL(PROD_ID,0)
        INTO DataCapacityID
        FROM cpc_product_catlg
        WHERE attrib_value = tlg_daily_rec.data_capacity_code 
          AND attrib_name = 'productCode' 
          AND (prod_type = 'generic rate plan' or prod_type = 'generic feature')
          AND tlg_daily_rec.action_date between eff_date and exp_date;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DataCapacityID := NULL;
      END;

      IF DataCapacityID > 0
      THEN
        UpdateFlag := 1;
      END IF;
    END IF;

    -- If device_data_code is populated, try to update CPC fields.
    IF tlg_daily_rec.device_data_code is not null
    THEN
      ---------------------------------------------------------                         
      -- Search CPC using device_data_code to get the product id.
      ---------------------------------------------------------
      BEGIN
        SELECT NVL(PROD_ID,0)
        INTO DeviceDataID
        FROM cpc_product_catlg
        WHERE attrib_value = tlg_daily_rec.device_data_code 
          AND attrib_name = 'productCode' 
          AND (prod_type = 'generic rate plan' or prod_type = 'generic feature')
          AND tlg_daily_rec.action_date between eff_date and exp_date;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DeviceDataID := NULL;
      END;

      IF DeviceDataID > 0
      THEN
        UpdateFlag := 1;
      END IF;
    END IF;

    ---------------------------------------------------------
    -- Update tlg_daily_trans.
    ---------------------------------------------------------      
    BEGIN
      IF UpdateFlag > 0
      THEN
        UPDATE tlg_daily_trans
        SET PRODUCT_ID = ProductID,
            P_PRODUCT_ID = ProductID,
            PRODUCT_NAME = ProductName,
            PRODUCT_SUBCAT_ID = ProductSubcatID,
            PRODUCT_SUBCAT_NAME = ProductSubcatName,
            PRODUCT_CAT_ID = ProductCatID,
            PRODUCT_CAT_NAME = ProductCatName,
            COMP_REVENUE = CompRevenue,               
            PRODUCT_FAMILY = ProductFamily,
            PREV_PRODUCT_ID = PrevProductID,
            PREV_PRODUCT_SUBCAT_ID = PrevProductSubcatID,
            PREV_PRODUCT_SUBCAT_NAME = PrevProductSubcatName,
            PREV_PRODUCT_CAT_ID = PrevProductCatID,
            PREV_PRODUCT_CAT_NAME = PrevProductCatName,
            PREV_PRODUCT_CODE_DESC = PrevProductCodeDesc,
            PREV_PRODUCT_CODE_RATE = PrevProductCodeRate,
            DATA_CAPACITY_ID = DataCapacityID,
            DEVICE_DATA_ID = DeviceDataID,
            MOD_USER = 'DLY_TRANS_CPC_UPDATE',
            MOD_DATE = SysDate 
        WHERE CURRENT OF tlg_daily_trans_cursor;
        UpdateCounter := UpdateCounter + 1;
      END IF;
    END;
    FETCH tlg_daily_trans_cursor into tlg_daily_rec;
  END LOOP;
  COMMIT;
  CLOSE tlg_daily_trans_cursor;
  EndTime := SYSTIMESTAMP;
  DBMS_OUTPUT.PUT_LINE( 'Closed tlg_daily_trans_cursor' );
  DBMS_OUTPUT.PUT_LINE( 'tlg_daily_trans records read: ' || DailyTransCounter );
  DBMS_OUTPUT.PUT_LINE( 'Records updated             : ' || UpdateCounter );
  DBMS_OUTPUT.PUT_LINE( 'End Time: ' || to_char( EndTime, 'YYYY-MM-DD HH24:MI:SS' ));
END SP_TLG_DAILY_TRANS_CPC_UPDATE;
/
