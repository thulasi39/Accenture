-- Top-Level Daily Update stored procedure 
drop procedure SP_HZNREP_DAILY_UPD;
drop procedure SP_DC_TLG_UPDATE;
drop procedure SP_CCPM_INST_TLG_UPDATE;
drop procedure SP_CCPM_WLINE_TRANS_MAIN;

-- NCI stored procedures
drop procedure SP_PROCESS_NCI;
drop procedure SP_LOAD_NCI_BASE;
drop procedure SP_LOAD_NCI_ACTIVITY;
drop procedure SP_NCI_MAP;
drop procedure SP_UPDATE_DAILY_TRANS_FOR_NCI;
drop procedure SP_NCI_LOOKUP;
drop procedure SP_GET_PRE_NCI_HISTORY;
drop procedure SP_GET_PRE_NCI_UPGB_HISTORY;

drop procedure SP_POS_TLG_UPDATE;
drop procedure SP_ERICSSON_TLG_UPDATE;
drop procedure SP_ERICSSON_SNPSHOT_TLG_UPDATE;

drop function FN_GET_APPLE_AGENTS;
drop procedure SP_INST_INFO_TLG_UPDATE;
drop procedure SP_TLG_DAILY_DEVICE_ID_UPD;
drop procedure SP_CCPM_INST_TLG_CATCHUP;
drop procedure SP_HZNREP_CCPM_WIRELESS;
drop procedure SP_WASH_TRANS;
drop procedure SP_UPDATE_EOD_NAC_PROD_CODES;

-- Cross Upgrade stored procedures
drop procedure SP_CMV_DELETE;
drop procedure SP_CMV_NCI;
drop procedure SP_CMV_LOAD_MOVE;
drop procedure SP_CMV_LOAD_REVERSAL;
drop procedure SP_CMV_LOAD;
drop procedure SP_CMV_LIVE_DAYS;
drop procedure SP_CMV_DONOR_DISC;
drop procedure SP_CMV_RECIPIENT_DISC;
drop procedure SP_CMV_UPGT_ADD;
drop procedure SP_CMV_UPGT_BACKOUT;
drop procedure SP_CMV_SVC;
drop procedure SP_CMV_UPDATE_TRANS;
drop procedure SP_CROSSUPG;
drop procedure SP_PRODUCT_UPG;
drop procedure SP_CMV_PRODUCT;

-- SWEEP procedure
drop procedure SP_SWEEP_TLG_SRVCHG_TRANS;
drop procedure SP_TLG_DAILY_TRANS_DUP_SWEEP;

-- CCPM
drop procedure SP_CCPM_DUP_CLEANUP;
drop procedure SP_CCPM_DTVN_CONTRACT_UPDATE;
drop procedure SP_CCPM_BRE_CONTRACT_UPDATE;

-- CPC
drop procedure SP_TLG_DAILY_TRANS_CPC_UPDATE;

commit;

-- NCI stored procedures
@SP_NCI_LOOKUP.sql;
show err;
@SP_GET_PRE_NCI_HISTORY.sql;
show err;
@SP_GET_PRE_NCI_UPGB_HISTORY.sql;
show err;
@SP_NCI_MAP.sql;
show err;
@SP_LOAD_NCI_ACTIVITY.sql;
show err;
@SP_LOAD_NCI_BASE.sql;
show err;

@SP_POS_TLG_UPDATE;
show err;
@SP_ERICSSON_TLG_UPDATE;
show err;
@SP_ERICSSON_SNPSHOT_TLG_UPDATE;
show err;

@FN_GET_APPLE_AGENTS;
show err;
@SP_INST_INFO_TLG_UPDATE;
show err;
@SP_TLG_DAILY_DEVICE_ID_UPD;
show err;
@SP_CCPM_INST_TLG_CATCHUP;
show err;
@SP_DC_TLG_UPDATE.sql;
show err;
@SP_CCPM_INST_TLG_UPDATE.sql;
show err;
@SP_HZNREP_CCPM_WIRELESS;
show err;
@SP_WASH_TRANS;
show err;
@SP_UPDATE_EOD_NAC_PROD_CODES;
show err;

-- Cross Upgrade stored procedures
@SP_CMV_PRODUCT.sql;
show err;
@SP_CMV_DELETE.sql;
show err;
@SP_CMV_NCI.sql;
show err;
@SP_CMV_LOAD_MOVE.sql;
show err;
@SP_CMV_LOAD_REVERSAL.sql;
show err;
@SP_CMV_LOAD.sql;
show err;
@SP_CMV_LIVE_DAYS.sql;
show err;
@SP_CMV_DONOR_DISC.sql;
show err;
@SP_CMV_RECIPIENT_DISC.sql;
show err;
@SP_CMV_UPGT_ADD.sql;
show err;
@SP_CMV_UPGT_BACKOUT.sql;
show err;
@SP_CMV_SVC.sql;
show err;
@SP_CMV_UPDATE_TRANS.sql;
show err;
@SP_PRODUCT_UPG.sql;
show err;
@SP_CROSSUPG.sql;
show err;

--Sweep procedures
@SP_SWEEP_TLG_SRVCHG_TRANS.sql;
show err;
@SP_TLG_DAILY_TRANS_DUP_SWEEP.prc;
show err;

-- CCPM
@SP_CCPM_DUP_CLEANUP.prc;
show err;
@SP_CCPM_DTVN_CONTRACT_UPDATE.sql;
show err;
@SP_CCPM_BRE_CONTRACT_UPDATE.sql;
show err;

-- CPC
@SP_TLG_DAILY_TRANS_CPC_UPDATE.sql
show err;

--*-------------------------------------------------------
--*     END Procedures
--*These procedure call Other procedures
--*-------------------------------------------------------
@SP_UPDATE_DAILY_TRANS_FOR_NCI.sql;
show err;
@SP_PROCESS_NCI.sql;
show err;
@SP_HZNREP_DAILY_UPD.sql;
show err;
@SP_CCPM_WLINE_TRANS_MAIN.sql;
show err;
commit;

-- NCI stored procedures
alter procedure SP_NCI_LOOKUP COMPILE;
show err;
alter procedure SP_GET_PRE_NCI_HISTORY COMPILE;
show err;
alter procedure SP_GET_PRE_NCI_UPGB_HISTORY COMPILE;
show err;
alter procedure SP_UPDATE_DAILY_TRANS_FOR_NCI COMPILE;
show err;
alter procedure SP_NCI_MAP COMPILE;
show err;
alter procedure SP_LOAD_NCI_ACTIVITY COMPILE;
show err;
alter procedure SP_LOAD_NCI_BASE COMPILE;
show err;
alter procedure SP_PROCESS_NCI COMPILE;
show err;

alter procedure SP_POS_TLG_UPDATE COMPILE;
show err;
alter procedure SP_ERICSSON_TLG_UPDATE COMPILE;
show err;
alter procedure SP_ERICSSON_SNPSHOT_TLG_UPDATE COMPILE;
show err;
alter procedure SP_HZNREP_CCPM_WIRELESS COMPILE;
show err;
alter procedure SP_WASH_TRANS COMPILE;
show err;
alter procedure SP_UPDATE_EOD_NAC_PROD_CODES COMPILE;
show err;

--- Apple project
alter function FN_GET_APPLE_AGENTS COMPILE;
show err;
alter procedure SP_INST_INFO_TLG_UPDATE COMPILE;
show err;
alter procedure SP_TLG_DAILY_DEVICE_ID_UPD COMPILE;
show err;
alter procedure SP_CCPM_INST_TLG_CATCHUP COMPILE;
show err;

-- Cross Upgrade stored procedures
alter procedure SP_CMV_DELETE COMPILE;
show err;
alter procedure SP_CMV_NCI COMPILE;
show err;
alter procedure SP_CMV_LOAD_MOVE COMPILE;
show err;
alter procedure SP_CMV_LOAD_REVERSAL COMPILE;
show err;
alter procedure SP_CMV_LOAD COMPILE;
show err;
alter procedure SP_CMV_LIVE_DAYS COMPILE;
show err;
alter procedure SP_CMV_DONOR_DISC COMPILE;
show err;
alter procedure SP_CMV_RECIPIENT_DISC COMPILE;
show err;
alter procedure SP_CMV_UPGT_ADD COMPILE;
show err;
alter procedure SP_CMV_UPGT_BACKOUT COMPILE;
show err;
alter procedure SP_CMV_SVC COMPILE;
show err;
alter procedure SP_CMV_UPDATE_TRANS COMPILE;
show err;
alter procedure SP_CROSSUPG COMPILE;
show err;
alter procedure SP_PRODUCT_UPG COMPILE;
show err;

-- sweep procedures
alter procedure SP_SWEEP_TLG_SRVCHG_TRANS COMPILE;
show err;
alter procedure SP_TLG_DAILY_TRANS_DUP_SWEEP COMPILE;
show err;

-- CCPM
alter procedure SP_CCPM_DUP_CLEANUP COMPILE;
show err;
alter procedure SP_CCPM_DTVN_CONTRACT_UPDATE COMPILE;
show err;
alter procedure SP_CCPM_BRE_CONTRACT_UPDATE COMPILE;
show err;

-- CPC
alter procedure SP_TLG_DAILY_TRANS_CPC_UPDATE COMPILE;
show err;

-- Top-Level Daily Update stored procedure 
alter procedure SP_DC_TLG_UPDATE COMPILE;
alter procedure SP_CCPM_INST_TLG_UPDATE COMPILE;
alter procedure SP_HZNREP_DAILY_UPD COMPILE;
alter procedure SP_CCPM_WLINE_TRANS_MAIN COMPILE;
show err;

commit;

--*----------------------------------------------------------------
spool off;
exit;
