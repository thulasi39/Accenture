CREATE OR REPLACE PROCEDURE SP_CMV_SVC
(
	p_tran in out tlg_daily_trans%rowtype
)
IS
	l_recipient INTEGER;
	l_donor 	INTEGER;
	l_unaccept 	CHAR(1);
BEGIN

	l_unaccept := 'N' ;
	
	dbms_output.put_line('Entering SP_CMV_SVC...');
	dbms_output.put_line('Transaction Key =[ ' || p_tran.tlg_daily_trans_key ||'] ');
	dbms_output.put_line('Mobile  =[ ' || p_tran.p_isd_mobile ||'] ');
	/*
	1. Shared upgrade is the new name for cross upgrade.
	2. This stored procedure is called for service change transactions only('SVC', 'SVD', 'MVC', 'MVD').
	3. If a mobile has ever been a recipient or donor in a shared upgrade and the shared upgrade is not reversed yet,  
		any service change transaction After the contract move should be unaccepted.
	*/
	
	/* For a mobile that is an active recipient, any service change transaction After the contract move should be unaccepted. */
	SELECT COUNT (*) into l_recipient FROM contract_moves 
	WHERE recipient_mobile = p_tran.p_isd_mobile AND recipient_isd = p_tran.p_mobile_isd
	AND timestamp < p_tran.timestamp
	AND reversal_date IS NULL;

	if( l_recipient > 0 ) THEN
		l_unaccept:= 'Y';
		dbms_output.put_line('service change transaction will be unaccepted: Mobile has been a recipient in a shared upgrade');
	END IF;
	
	
	/* For a mobile that is an active recipient, any service change transaction After the contract move should be unaccepted. */
	SELECT COUNT (*) into l_donor FROM contract_moves 
	WHERE donor_mobile = p_tran.p_isd_mobile AND donor_isd = p_tran.p_mobile_isd
	AND timestamp < p_tran.timestamp
	AND reversal_date IS NULL;

	if( l_donor > 0 ) THEN
		l_unaccept:= 'Y';
		dbms_output.put_line('service change transaction will be unaccepted: Mobile has been a donor in a shared upgrade');
	END IF;
		
	
	if( l_unaccept = 'Y' ) THEN
		UPDATE tlg_daily_trans 
		SET is_accepted = 'N', mod_user = 'CMV_SVC', mod_date = SYSDATE 
		WHERE tlg_daily_trans_key = p_tran.tlg_daily_trans_key;
	END IF;
	
	dbms_output.put_line('Leaving SP_CMV_SVC...');
END  SP_CMV_SVC;
/