CREATE OR REPLACE PROCEDURE SP_ERICSSON_TLG_UPDATE
(
	p_year IN integer,
	p_month IN integer,
	p_day IN integer,
	p_errormessage out varchar2
)
IS
BEGIN
	DECLARE
		l_mod_user                   varchar2(25);
		NbrOfRecRead                 number;
		NbrOfRecUpdated              number;
		NoBalance                    number;
		b_ericsson_balance_trans_key NUMBER(28);
		b_amount	             NUMBER(15,2);
		l_start_time                 DATE;
		l_finish_time                DATE;
		l_first_dom                  DATE;
		l_first_nxt_month	     DATE;
		action_month                 NUMBER;
		action_year                  NUMBER;
		firstFound                   varchar2(1);
                SEARCH_TLG1DAY_DELAY         BOOLEAN;
                prev_year                    number;
                prev_month                   number;
                e_cross_month_ind            VARCHAR2(1);
                b_transaction_date           DATE;
	--*	============================================================================
		CURSOR tlg_cur IS
		SELECT tlg_daily_trans_key, bill_mkt_code, current_mobile, ban,
		non_mod_seller_id, contract_term, contract_type, action_date, action_type,
		product_code, prev_product_code, imei, event_reason, p_device_id,
		device_id, p_imei,  p_df_indicator, product_family, mod_user,  mod_date,
		ericsson_balance_trans_key, prepaid_cross_month_ind, month, year, 
                prepaid_funded_date
		FROM tlg_daily_trans t
		WHERE ((month = p_month and year = p_year)  or (month = prev_month and year = prev_year))
			and ((action_type = 'NAC') or (action_type = 'P2P'))
			and product_cat_name = 'PREPAID'
			and product_subcat_name in ('PAY-AS-YOU-GO', 'DATA', 'WRLS HOME SVCS')
			and is_accepted = 'Y' and is_valid = 'Y'
                        and ericsson_balance_trans_key is null
	        FOR UPDATE OF  
                  t.ericsson_balance_trans_key,
                  t.p_airtime_amount,
                  t.prepaid_cross_month_ind,
                  t.prepaid_funded_date;

--*	============================================================================
	BEGIN
                dbms_output.put_line('PROCEDURE SP_ERICSSON_TLG_UPDATE v1.5');
                dbms_output.put_line( 'p_month: ' || p_month || ', p_year: ' || p_year  || '.');
		--*************************************
		--*		Checks Section
		--*************************************
		l_start_time := SYSDATE;
		l_mod_user := 'SP_ERIC_TLG_UPD';
		NbrOfRecRead := 0;
		NbrOfRecUpdated := 0;
		NoBalance := 0;

		if ( p_month not between 1 and 12 )
		then
			dbms_output.put_line('Not a valid month:[' || p_month||']. Allowed values are 1-12.');
			return ;
		end if;
		if ( p_year not between 2011 and 2050 )
		then
			dbms_output.put_line('Not a valid year:[' || p_year||']. Allowed range is 2011-2050.');
			return;
		end if;

                --*------------------------------------------------------------------
                --* Determine previous year / previous month for cross month matching
                --*------------------------------------------------------------------
                BEGIN
                  select to_char(add_months(to_date(to_char(p_year)||lpad(to_char(p_month),2,'0')||'01','yyyymmdd'), - 1),'yyyy'),
                         to_char(add_months(to_date(to_char(p_year)||lpad(to_char(p_month),2,'0')||'01','yyyymmdd'), - 1),'mm')
                  into prev_year, prev_month
                  from dual;
                  dbms_output.put_line( 'prev_month: ' || prev_month || ', prev_year: ' || prev_year || '.');
                END;

		--*************************************
		--*     Reset p_airtime_amount to null
		--*************************************
      		UPDATE tlg_daily_trans t
  		set t.p_airtime_amount=NULL,
  		t.ericsson_balance_trans_key=NULL,
  		t.mod_user='rSP_ERIC_TLG_UPD',
  		t.mod_date=sysdate
  		WHERE month = p_month and year = p_year and day = p_day
  			        and ((action_type = 'NAC') or (action_type = 'P2P'))
  				and product_cat_name = 'PREPAID'
  				and product_subcat_name in ('PAY-AS-YOU-GO', 'DATA', 'WRLS HOME SVCS')
  				and is_accepted = 'Y' and is_valid = 'Y'
  				and ericsson_balance_trans_key is not null;
  		commit;
		--*************************************
		--*		Loop Section
		--*************************************
		FOR tlg_rec IN tlg_cur
		LOOP
		NbrOfRecRead := NbrOfRecRead +1;
		action_month := extract(month from tlg_rec.action_date);
		action_year := extract(year from tlg_rec.action_date);
                SEARCH_TLG1DAY_DELAY := FALSE;

		b_amount := 0;
		b_ericsson_balance_trans_key := 0;

		--*------------------------------------------------------------------
		--*Find a matching transaction(s) in pos - pick the last one!
		--*------------------------------------------------------------------
		BEGIN  
                  SELECT * INTO b_amount,  b_ericsson_balance_trans_key, b_transaction_date
                  FROM (
                    SELECT e.transaction_amount,  ericsson_balance_trans_key, trunc(transaction_time)
                    FROM ericsson_balance_trans e
                    WHERE year = p_year 
                      and month = p_month 
                      and trunc(e.transaction_time) >= tlg_rec.action_date
                      and e.transaction_type ='ACTIVATION'
                      and tlg_rec.current_mobile = e.mobile
                  ORDER BY e.transaction_time, e.transaction_amount DESC )
                  WHERE ROWNUM = 1;

		  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      SEARCH_TLG1DAY_DELAY := TRUE;
		END;

                --*------------------------------------------------------------------
                -- If don't find a match the first time look at action_date -1
                --*------------------------------------------------------------------
                IF SEARCH_TLG1DAY_DELAY THEN
                  BEGIN
                    SELECT * INTO b_amount,  b_ericsson_balance_trans_key, b_transaction_date
                    FROM (
                      SELECT e.transaction_amount,  ericsson_balance_trans_key, trunc(transaction_time)
                      FROM ericsson_balance_trans e
                      WHERE year = p_year 
                        and month = p_month 
                        and trunc(e.transaction_time) >= (tlg_rec.action_date - 1)
                        and e.transaction_type ='ACTIVATION'
                        and tlg_rec.current_mobile = e.mobile
                    ORDER BY e.transaction_time, e.transaction_amount DESC )
                    WHERE ROWNUM = 1;

		    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        NoBalance := NoBalance +1;
                        continue;
                  END;
                END IF;

               --* If record is from previous month set flag.
                e_cross_month_ind := tlg_rec.prepaid_cross_month_ind;
                IF tlg_rec.month = prev_month AND tlg_rec.year = prev_year THEN
                  e_cross_month_ind := 'Y';
                END IF;

--*-----------------------------------------------------------------------------
--* 	Enter the amount in tlg_daily_trans
--*-----------------------------------------------------------------------------

		UPDATE tlg_daily_trans 
		SET 
			p_airtime_amount  = b_amount,
			ericsson_balance_trans_key = b_ericsson_balance_trans_key,
                        prepaid_funded_date = b_transaction_date,
			mod_user = l_mod_user,
			mod_date = sysdate,
                        prepaid_cross_month_ind = e_cross_month_ind
			WHERE CURRENT OF tlg_cur;

		NbrOfRecUpdated := NbrOfRecUpdated +1;

	END LOOP;

	COMMIT;

	dbms_output.put_line ('SP_ERICSSON_TLG_UPDATE for ' || p_month ||'/'||p_day||'/'||p_year||'.');
	dbms_output.put_line('Totals - Qualified: '|| NbrOfRecRead || ' Updated: '|| NbrOfRecUpdated || 
	' Not In Balance tbl: '|| NoBalance || ' for SP_ERICSSON_TLG_UPDATE');

	l_finish_time := SYSDATE;

	dbms_output.put_line ('Start time (SP_ERICSSON_TLG_UPDATE): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
	dbms_output.put_line ('End time (SP_ERICSSON_TLG_UPDATE): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));
	END;

END SP_ERICSSON_TLG_UPDATE;
/
