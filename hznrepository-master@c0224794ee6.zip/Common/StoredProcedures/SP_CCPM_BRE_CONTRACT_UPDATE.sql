CREATE OR REPLACE PROCEDURE SP_CCPM_BRE_CONTRACT_UPDATE
(
	p_year           IN     NUMBER,
	p_month          IN     NUMBER,
	p_day            IN     NUMBER	DEFAULT NULL,
	p_reset_count	OUT		NUMBER,
	p_update_count	OUT		NUMBER,
	p_result		OUT		VARCHAR2,
	p_errormessage  OUT		VARCHAR2
)
IS
   l_result	  VARCHAR2 (500);
   l_start_time         DATE;
   l_finish_time        DATE;
   l_minute_taken       NUMBER (8, 2);
   l_count				NUMBER;
BEGIN

    l_start_time := SYSDATE;
	
    DBMS_OUTPUT.put_line('Starting(SP_CCPM_BRE_CONTRACT_UPDATE) at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));

	l_count := 0;
	UPDATE ccpm_wline_trans 
		SET
			contract_start_date = null, 
			contract_end_date = null,
			contract_ind = 'N',
			contract_term = null,
			contract_trans_key = null,
			mod_user = 'rSP_CCPM_BRE_CONTRACT_UPDATE',
			mod_date = sysdate
			WHERE year = p_year AND month = p_month
				AND day= 
					(CASE WHEN p_day is NOT NULL then p_day
					ELSE day
					END)
				AND product_cat_name = 'OTT' 
				AND product_code like 'DTVN%'
				AND action_type = 'I' 
				AND order_status = 'S' 
				AND new_or_existing = 'N';
		
	l_count := SQL%ROWCOUNT;
	COMMIT;

	l_result := l_result || 'CCPM_WLINE_TRANS, RESET: ' || l_count || chr(10);
	
	p_reset_count := l_count;
	
	l_count := 0;
	MERGE INTO ccpm_wline_trans dtvn
	USING
	(
		SELECT * FROM
		(
			SELECT c.evergent_order_id as evergent_order_id, c.contract_added_date as contract_added_date,
					c.end_date as contract_end_date, r.contract_term as contract_term,
					c.ccpm_contract_trans_key as ccpm_contract_trans_key,
			ROW_NUMBER() OVER ( PARTITION BY c.evergent_order_id, c.start_date order by c.evergent_order_id, c.start_Date desc) as rnum
			FROM ccpm_contract_trans c 
			left outer join ccpm_contract_ref_trans r
			ON c.contract_version = r.contract_version
			WHERE c.year = p_year AND c.month = p_month
			AND c.day= 
					(CASE WHEN p_day is NOT NULL then p_day
					ELSE c.day
					END)
		)WHERE rnum=1
	) cntrct
	ON
	(
			dtvn.src_acct_id = cntrct.evergent_order_id
			AND to_char(dtvn.sale_date, 'mm/dd/yyyy') = to_char(cntrct.contract_added_date, 'mm/dd/yyyy')
	)
	WHEN MATCHED THEN UPDATE
			SET dtvn.contract_start_date = cntrct.contract_added_date,
			dtvn.contract_end_date = cntrct.contract_end_date,
			dtvn.contract_term = cntrct.contract_term,
			dtvn.contract_ind = 'Y',
			dtvn.contract_trans_key = cntrct.ccpm_contract_trans_key,
			mod_user = 'uSP_CCPM_BRE_CONTRACT_UPDATE',
			mod_date = sysdate
	WHERE dtvn.year = p_year AND dtvn.month = p_month
				AND dtvn.day= 
					(CASE WHEN p_day is NOT NULL then p_day
					ELSE dtvn.day
					END)
				AND dtvn.product_cat_name = 'OTT' 
				AND dtvn.product_code like 'DTVN%'
				AND dtvn.action_type = 'I' 
				AND dtvn.order_status = 'S' 
				AND dtvn.new_or_existing = 'N';
		
	l_count := SQL%ROWCOUNT;
	
	COMMIT;

	l_result := l_result || 'CCPM_WLINE_TRANS, UPDATED: ' || l_count || chr(10);
	
	p_update_count := l_count;
	
	p_result := l_result;
		

    l_finish_time := SYSDATE;
    l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
    l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');
	
    DBMS_OUTPUT.put_line('Finished (SP_CCPM_BRE_CONTRACT_UPDATE) at: ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line ('Start time (SP_CCPM_BRE_CONTRACT_UPDATE): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
    DBMS_OUTPUT.put_line ('End time (SP_CCPM_BRE_CONTRACT_UPDATE): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('Total time taken (SP_CCPM_BRE_CONTRACT_UPDATE)  =  '
                           || l_minute_taken
                           || ' Minutes');	
						   
	EXCEPTION
		WHEN OTHERS THEN
		ROLLBACK;
		p_errormessage := 'WARNING!!! Processing Unsuccessful: ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' );
		DBMS_OUTPUT.put_line(p_errormessage);
		DBMS_OUTPUT.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
		RAISE_APPLICATION_ERROR( -20018, p_errormessage || ' SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM );						   
						   
END SP_CCPM_BRE_CONTRACT_UPDATE;
/
