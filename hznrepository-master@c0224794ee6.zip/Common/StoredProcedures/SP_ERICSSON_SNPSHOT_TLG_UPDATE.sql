CREATE OR REPLACE PROCEDURE SP_ERICSSON_SNPSHOT_TLG_UPDATE
(
	p_year IN integer,
	p_month IN integer,
	p_errormessage out varchar2
)
IS
BEGIN
	DECLARE
                e_ericsson_ml_snapshot_key  NUMBER(28);
                e_funded_date               DATE;
                e_initial_installation_date DATE;
                e_ml_indicator              CHAR(1);
                e_rate_plan                 VARCHAR2(50);
                e_rateplan_status           VARCHAR2(1);
		NbrOfRecRead                number;
		NbrOfRecUpdated             number;
		NoBalance                   number;
		l_start_time                DATE;
		l_finish_time               DATE;
                SEARCH_TLG1DAY_DELAY        BOOLEAN;
                prev_year                   number;
                prev_month                  number;
                e_cross_month_ind           VARCHAR2(1);
                e_prod_id                   NUMBER(28);
                NoCPCMatch                  number;
                e_mod_user                  VARCHAR2(20);
                Match1                      number; 
                Match2                      number; 
                e_class_of_service          NUMBER(5);
	--*	============================================================================
		CURSOR tlg_cur IS
                SELECT current_mobile,
                  prepaid_ericsson_snapshot_key, prepaid_funded_date, prepaid_init_installation_date,
                  prepaid_ml_indicator, prepaid_rate_plan, prepaid_rate_plan_status,
                  mod_user, mod_date, action_date, year, month, prepaid_rate_plan_id, prepaid_class_of_service
		FROM tlg_daily_trans t
		WHERE ((month = p_month and year = p_year) or (month = prev_month and year = prev_year))
			and ((action_type = 'NAC') or (action_type = 'P2P'))
			and product_cat_name = 'PREPAID'
			and product_subcat_name in ('PAY-AS-YOU-GO', 'DATA', 'WRLS HOME SVCS')
			and is_accepted = 'Y' and is_valid = 'Y'
                        and ((prepaid_ericsson_snapshot_key is null) or 
                            ((prepaid_ericsson_snapshot_key is not null) and (prepaid_rate_plan is null)))
	        FOR UPDATE OF  
                  prepaid_ericsson_snapshot_key, prepaid_funded_date, prepaid_init_installation_date,
                  prepaid_ml_indicator, prepaid_rate_plan, prepaid_rate_plan_status,
                  mod_user, mod_date, prepaid_rate_plan_id, prepaid_class_of_service;

        --*============================================================================
	BEGIN
                dbms_output.put_line('PROCEDURE SP_ERICSSON_SNPSHOT_TLG_UPDATE v1.6');
                dbms_output.put_line( 'p_month: ' || p_month || ', p_year: ' || p_year  || '.');

		--*************************************
		--*		Checks Section
		--*************************************
		l_start_time := SYSDATE;
		NbrOfRecRead := 0;
		NbrOfRecUpdated := 0;
		NoBalance := 0;
		NoCPCMatch := 0;
                Match1 := 0;
                Match2 := 0;

		if ( p_month not between 1 and 12 )
		then
			dbms_output.put_line('Not a valid month:[' || p_month||']. Allowed values are 1-12.');
			return ;
		end if;
		if ( p_year not between 2011 and 2050 )
		then
			dbms_output.put_line('Not a valid year:[' || p_year||']. Allowed range is 2011-2050.');
			return;
		end if;

		--*------------------------------------------------------------------
		--* Determine previous year / previous month for cross month matching
		--*------------------------------------------------------------------
		BEGIN  
                  select to_char(add_months(to_date(to_char(p_year)||lpad(to_char(p_month),2,'0')||'01','yyyymmdd'), - 1),'yyyy'),
                         to_char(add_months(to_date(to_char(p_year)||lpad(to_char(p_month),2,'0')||'01','yyyymmdd'), - 1),'mm')
                  into prev_year, prev_month
                  from dual;
                  dbms_output.put_line( 'prev_month: ' || prev_month || ', prev_year: ' || prev_year || '.');
		END;

		--*************************************
		--*		Loop Section
		--*************************************
		FOR tlg_rec IN tlg_cur
		LOOP
		  NbrOfRecRead := NbrOfRecRead +1;
                  SEARCH_TLG1DAY_DELAY := FALSE;
                  e_mod_user := NULL;

		--*------------------------------------------------------------------
		--*If record has not previously been matched. *****
		--*------------------------------------------------------------------
                  IF tlg_rec.prepaid_ericsson_snapshot_key is NULL
                  THEN
		  --*------------------------------------------------------------------
		  --*Find a matching transaction(s) in pos - pick the first one!
		  --*------------------------------------------------------------------
		    BEGIN  
                      SELECT ericsson_ml_snapshot_key,
                             funded_date,
                             initial_installation_date,
                             ml_indicator,
                             rate_plan,
                             rateplan_status,
                             class_of_service
                      INTO   e_ericsson_ml_snapshot_key,
                             e_funded_date,
                             e_initial_installation_date,
                             e_ml_indicator,
                             e_rate_plan,
                             e_rateplan_status,
                             e_class_of_service
                      FROM (SELECT ericsson_ml_snapshot_key,
                                   to_date(snapshot_time - 1) FUNDED_DATE,
                                   initial_installation_date,
                                   ml_indicator,
                                   rate_plan,
                                   rateplan_status,
                                   class_of_service
                            FROM ericsson_ml_snapshot
                            WHERE year = p_year 
                              and month = p_month
                              and ((rateplan_status = 'A') or (rateplan_status is NULL))
                              and mobile = tlg_rec.current_mobile 
                              and activation_date >= tlg_rec.action_date
                            ORDER BY snapshot_time)
                      WHERE ROWNUM = 1;

		      EXCEPTION
			WHEN NO_DATA_FOUND THEN
                                SEARCH_TLG1DAY_DELAY := TRUE;
		    END;

                  --*------------------------------------------------------------------
                  -- If don't find a match the first time look at action_date -1
                  --*------------------------------------------------------------------
                    IF SEARCH_TLG1DAY_DELAY THEN
		      BEGIN  
                        SELECT ericsson_ml_snapshot_key,
                               funded_date,
                               initial_installation_date,
                               ml_indicator,
                               rate_plan,
                               rateplan_status,
                               class_of_service
                        INTO   e_ericsson_ml_snapshot_key,
                               e_funded_date,
                               e_initial_installation_date,
                               e_ml_indicator,
                               e_rate_plan,
                               e_rateplan_status,
                               e_class_of_service
                        FROM (SELECT ericsson_ml_snapshot_key,
                                     to_date(snapshot_time - 1) FUNDED_DATE,
                                     initial_installation_date,
                                     ml_indicator,
                                     rate_plan,
                                     rateplan_status,
                                     class_of_service
                              FROM ericsson_ml_snapshot
                              WHERE year = p_year 
                                and month = p_month
                                and ((rateplan_status = 'A') or (rateplan_status is NULL))
                                and mobile = tlg_rec.current_mobile 
                                and activation_date >= (tlg_rec.action_date - 1)
                              ORDER BY snapshot_time)
                        WHERE ROWNUM = 1;

		        EXCEPTION
			  WHEN NO_DATA_FOUND THEN
  				NoBalance := NoBalance +1;
  				continue;
		      END;
                    END IF;

                    Match1 := Match1 + 1;
                    e_mod_user := 'SP_ERIC_SNAPSHOT_UPD';

                  --*-----------------------------------------------------------------------------
                  --* Sometimes funded date is the day before installation_date
                  --*-----------------------------------------------------------------------------
                    IF e_funded_date < e_initial_installation_date THEN
                      e_funded_date := e_funded_date + 1;
                    END IF;

                  --*-----------------------------------------------------------------------------
                  --* If the funded date was already populated using balance file, then
                  --* leave it as is. 
                  --*-----------------------------------------------------------------------------
                    IF tlg_rec.prepaid_funded_date is NOT NULL 
                    THEN
                      e_funded_date := tlg_rec.prepaid_funded_date;
                    END IF;

		--*------------------------------------------------------------------
		--* Record has previously been matched, only looking for rate plan not null.
		--*------------------------------------------------------------------
                  ELSE

		  --*------------------------------------------------------------------
		  --*Find a matching transaction(s) in pos - pick the first one!
		  --*------------------------------------------------------------------
		    BEGIN  
                      SELECT ericsson_ml_snapshot_key,
                             rate_plan
                      INTO   e_ericsson_ml_snapshot_key,
                             e_rate_plan
                      FROM (SELECT ericsson_ml_snapshot_key,
                                   to_date(snapshot_time - 1) FUNDED_DATE,
                                   initial_installation_date,
                                   ml_indicator,
                                   rate_plan,
                                   rateplan_status
                            FROM ericsson_ml_snapshot
                            WHERE year = p_year 
                              and month = p_month
                              and ((rateplan_status = 'A') or (rateplan_status is NULL))
                              and mobile = tlg_rec.current_mobile 
                              and activation_date >= tlg_rec.action_date
                              and rate_plan is not null
                            ORDER BY snapshot_time)
                      WHERE ROWNUM = 1;

		      EXCEPTION
			WHEN NO_DATA_FOUND THEN
                                SEARCH_TLG1DAY_DELAY := TRUE;
		    END;
                  --*------------------------------------------------------------------
                  -- If don't find a match the first time look at action_date -1
                  --*------------------------------------------------------------------
                    IF SEARCH_TLG1DAY_DELAY THEN
		      BEGIN  
                        SELECT ericsson_ml_snapshot_key,
                               rate_plan
                        INTO   e_ericsson_ml_snapshot_key,
                               e_rate_plan
                        FROM (SELECT ericsson_ml_snapshot_key,
                                     to_date(snapshot_time - 1) FUNDED_DATE,
                                     initial_installation_date,
                                     ml_indicator,
                                     rate_plan,
                                     rateplan_status
                              FROM ericsson_ml_snapshot
                              WHERE year = p_year 
                                and month = p_month
                                and ((rateplan_status = 'A') or (rateplan_status is NULL))
                                and mobile = tlg_rec.current_mobile 
                                and activation_date >= (tlg_rec.action_date - 1)
                                and rate_plan is not null
                              ORDER BY snapshot_time)
                        WHERE ROWNUM = 1;

		        EXCEPTION
			  WHEN NO_DATA_FOUND THEN
  				NoBalance := NoBalance +1;
  				continue;
		      END;
                    END IF;

                    Match2 := Match2+1;
                    e_mod_user := 'SP_ERIC_SNAPSHOT_UP2';
                    e_funded_date := tlg_rec.prepaid_funded_date;
                    e_initial_installation_date := tlg_rec.prepaid_init_installation_date;
                    e_ml_indicator := tlg_rec.prepaid_ml_indicator;
                    e_rateplan_status := tlg_rec.prepaid_rate_plan_status;
                    e_class_of_service := tlg_rec.prepaid_class_of_service;

                  END IF;

                --*-----------------------------------------------------------------------------
                --* Insert ericsson_ml_snapshot records into ericsson_ml_snapshot_hist.
                --*-----------------------------------------------------------------------------
                  INSERT INTO ericsson_ml_snapshot_hist
                    SELECT *
                    FROM ericsson_ml_snapshot
                    WHERE year = p_year 
                      and month = p_month
                      and rateplan_status ='A'
                      and mobile = tlg_rec.current_mobile; 

                --*-----------------------------------------------------------------------------
                --* Get PRODUCT_ID from CPC 
                --*-----------------------------------------------------------------------------
                  e_prod_id := null;

		  BEGIN  
                    SELECT prod_id
                    INTO e_prod_id
                    FROM cpc_product_catlg
                    WHERE upper(attrib_name) = 'PRODUCTCODE'
                      AND tlg_rec.action_date between eff_date AND exp_date
                      AND upper(prod_type) = 'GENERIC RATE PLAN' AND attrib_value = e_rate_plan;

		    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        NoCPCMatch := NoCPCMatch +1;
                  END;

               --*-----------------------------------------------------------------------------
               --* Update tlg_daily_trans record
               --*-----------------------------------------------------------------------------

               --* If record is from previous month set flag. 
                  e_cross_month_ind := null; 
                  IF tlg_rec.month = prev_month AND tlg_rec.year = prev_year THEN 
                    e_cross_month_ind := 'Y'; 
                  END IF;

		  UPDATE tlg_daily_trans 
		  SET 
                    prepaid_ericsson_snapshot_key = e_ericsson_ml_snapshot_key, 
                    prepaid_funded_date = e_funded_date, 
                    prepaid_init_installation_date = e_initial_installation_date,
		    prepaid_ml_indicator = e_ml_indicator, 
                    prepaid_rate_plan = e_rate_plan, 
                    prepaid_rate_plan_status = e_rateplan_status,
                    prepaid_cross_month_ind = e_cross_month_ind,
                    mod_user = e_mod_user, 
                    mod_date = sysdate,
                    prepaid_rate_plan_id = e_prod_id,
                    prepaid_class_of_service = e_class_of_service
		  WHERE CURRENT OF tlg_cur;

		  NbrOfRecUpdated := NbrOfRecUpdated +1;

	        END LOOP;

	COMMIT;

	dbms_output.put_line ('SP_ERICSSON_SNPSHOT_TLG_UPDATE for ' || p_month ||'/'||p_year||'.');
	dbms_output.put_line('Total: '|| NbrOfRecRead || ' Updated: '|| NbrOfRecUpdated || ' for SP_ERICSSON_SNPSHOT_TLG_UPDATE'); 
	dbms_output.put_line('SP_ERIC_SNAPSHOT_UPD Match: ' || Match1 || ' SP_ERIC_SNAPSHOT_UP2 Match: '|| Match2 ); 

	l_finish_time := SYSDATE;

	dbms_output.put_line ('Start time (SP_ERICSSON_SNPSHOT_TLG_UPDATE): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
	dbms_output.put_line ('End time (SP_ERICSSON_SNPSHOT_TLG_UPDATE): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));
	END;

END SP_ERICSSON_SNPSHOT_TLG_UPDATE;
/
