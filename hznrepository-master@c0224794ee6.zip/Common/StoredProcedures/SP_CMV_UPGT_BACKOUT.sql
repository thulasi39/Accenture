CREATE OR REPLACE PROCEDURE SP_CMV_UPGT_BACKOUT
(
    p_tran in out tlg_daily_trans%rowtype
)
IS
l_cmv_rec contract_moves%rowtype;
l_update boolean;
BEGIN
    /*
    1. Shared upgrade is the new name for cross upgrade.
    2. This stored procedure is called only for C17(upgrade back out) transactions.
    3. There are three possibilities for a C17 
        a. The recipient tracking soc is expired during shared upgrade. This should be unaccepted.
        b. Cross upgrade reversal is being performed. This should be charged back, but we need to put additional information on the transactions.
        c. regular reversal(donor/recipient). no special processing is required 
    */
    dbms_output.put_line('starting SP_CMV_UPGT_BACKOUT... ');

    l_update := false;
    
    /* If the mobile is a recipient in a CMV event, find the corresponding donor mobile. */
    BEGIN
        SELECT * INTO l_cmv_rec FROM (
        SELECT * FROM  contract_moves cm 
        WHERE cm.recipient_mobile = p_tran.p_isd_mobile AND cm.recipient_isd = p_tran.p_mobile_isd and cm.action_type = 'CMR'
        AND  TRUNC(cm.action_date , 'DDD') = TRUNC(p_tran.action_date , 'DDD') 
        AND ( p_tran.timestamp - timestamp ) <= 1 -- we have to look for a contract move reversal around the same time as of the C17 
        ORDER BY TIMESTAMP DESC)
		WHERE ROWNUM = 1; 
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('Mobile [' || p_tran.p_isd_mobile || '] Mobile isd [' ||  p_tran.p_mobile_isd || '] is not an active recipient.' );
        WHEN OTHERS THEN
            NULL;
    END;
    
    /* If this is the C17 of an upgrade on a recipient mobile before a Cross Upgrade UPGT can be added, ignore this UPGT back out.*/
    IF (p_tran.event_reason = 'CUPG')  THEN    
        dbms_output.put_line('UPGT Backout for Recipeint mobiles set to unaccpeted before Cross Upgrade' ); 
        l_update := true;
        p_tran.is_accepted := 'N'; 
    END IF;
    
    /* if this is cross upgrade reversal, set the event_reason=CUPGR and p_info = donor mobile . This is done to make sure that chargeback can be applied for the appropriate transaction.*/
    IF(l_cmv_rec.contract_moves_key IS NOT NULL) THEN
        l_update := true;
        p_tran.p_info := l_cmv_rec.donor_mobile ;
        p_tran.agt_event_reason := 'CUPGR'; 
    END IF;
    
    if(l_update = false) then
        return;
    end if;
    
    
    p_tran.mod_user := 'CMV_UPGT_BACKOUT';
    p_tran.mod_date := SYSDATE ;
    
    UPDATE tlg_daily_trans 
    SET row = p_tran
    WHERE tlg_daily_trans_key = p_tran.tlg_daily_trans_key;
        
    
END SP_CMV_UPGT_BACKOUT;
/