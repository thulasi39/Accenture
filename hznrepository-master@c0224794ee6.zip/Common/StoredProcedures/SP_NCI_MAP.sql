CREATE OR REPLACE PROCEDURE SP_NCI_MAP  (
        p_errormessage  OUT      VARCHAR2
)
IS
--************************************************************************
--*     SP_NCI_MAP - Map NCI_ACTIVTY_BASE information into NCI_ACTIVITY
--*
--*     This procedure copies any unmapped cancellation records ('CAN') in NCI_ACTIVITY_BASE into
--*     NCI_ACTIVITY.  It will then try to match any unmapped new activation ('NAC') records in 
--*     NCI_ACTIVITY_BASE with the correspnding unmapped cancelation in NCI_ACTIVITY.
--*************************************************************************

    prev_nci_activity_key  integer;
    
    --*************************************************************************
    --* Create a cursor that will match unmapped cancellation records ('CAN') in the nci_activity table with the
    --* corresponding unmapped new activation ('NAC') records in the nci_activity_base table.  The matching
    --* is done on mobile, product_type, and the nci_move_date and isd_date being within two days of each other.
    --*************************************************************************
    CURSOR nci_cur IS
       select s.nci_activity_key as nci_activity_key, t.nci_activity_base_key as nci_activity_base_key, t.bill_mkt_code as bill_mkt_code, 
            t.mobile_mkt_code as mobile_mkt_code, t.isd_mobile as isd_mobile, t.isd_date as isd_date, t.isd_ban as isd_ban, 
            t.product_code as product_code, t.product_type as product_type, t.product_agent as product_agent, 
            t.nci_move_date as nci_move_date, t.file_date as file_date
            from nci_activity_base t, nci_activity s where
            t.action_type = 'NAC' and
            t.isd_mobile = s.s_last_mobile and
            s.s_nci_move_date = t.nci_move_date and
            t.is_mapped = 'N' and
            s.is_mapped = 'N' and
            s.s_product_type = t.product_type and
			s.s_bill_mkt_code != t.bill_mkt_code
            order by  s.nci_activity_key, t.isd_date asc;
    
    BEGIN     
    
        --*************************************************************************
        --* First insert all of the unmapped NCI cancellations ('CAN' ) records in the nci_activity_base table 
        --* into the nci_acitivty_table, and marked them as mapped in the nci_activity_base table
        --*************************************************************************
        INSERT INTO nci_activity ( 
                    nci_activity_key, s_bill_mkt_code, s_mobile_mkt_code, s_isd_mobile, s_isd_date, 
                    s_isd_ban, s_orig_agent,  
                    s_last_mobile, s_last_ban, s_fan, s_customer_name, s_sva_code, 
                    s_product_type, s_product_id, s_product_code, s_product_agent, s_product_isd, 
                    s_live_days, s_term, s_iru_cru, s_nci_move_date, s_file_date, is_mapped, 
					mod_user, mod_date) 
            SELECT 
                    seq_nci_activity.NEXTVAL, bill_mkt_code, mobile_mkt_code, isd_mobile, isd_date, 
                    isd_ban, orig_agent,  
                    last_mobile, last_ban, fan, customer_name, sva_code, 
                    product_type, product_id, product_code, product_agent, product_isd, 
                    live_days, term, iru_cru, nci_move_date, file_date, 'N' as is_mapped,
					'NCIActivityMap', SYSDATE 
            FROM nci_activity_base 
                    where is_mapped = 'N' and action_type = 'CAN';
                    
        UPDATE nci_activity_base set is_mapped = 'Y' where is_mapped = 'N' and action_type = 'CAN';
                    
        COMMIT;
                    
        
        --*************************************************************************
        -- * For each match of a cancellation record in nci_activity to an unmapped new activation in nci_activity_base
        --* move the new activation information into the target protion of the nci_activity record, marking both the
        --* newly completed nci_activity record and the corresponding nci_activity_base record as mapped.
        --*************************************************************************
        prev_nci_activity_key := 0;
    
        FOR nci_rec in nci_cur
        LOOP
        
            --*************************************************************************
            --* If the nci_activity 'CAN' record that is being processed has two possible new activation 'NAC' matches 
            --* from the nci_activity_base table (possibly bad data), take the first match, ordered by isd_date, and ignore
            --* the rest.  This occurs when the last processed nci_activity_key (prev_nci_activity_key) record is the same 
            --* as the next one.  Only u[date NCI_ACTIVITY if the records being processed is different than the previous one.
            --*************************************************************************
            IF ( prev_nci_activity_key <> nci_rec.nci_activity_key ) THEN
                
                --*************************************************************************
                --* Update NCI_ACTIVITY with the coresponding new activation information and mark the record as mapped.
                --*************************************************************************
                UPDATE NCI_ACTIVITY set 
                   t_bill_mkt_code = nci_rec.bill_mkt_code,
                    t_mobile_mkt_code = nci_rec.mobile_mkt_code,
                    t_isd_mobile = nci_rec.isd_mobile,
                    t_isd_date = nci_rec.isd_date,
                    t_isd_ban = nci_rec.isd_ban,
                    t_product_code = nci_rec.product_code,
                    t_product_type = nci_rec.product_type,
                    t_product_agent = nci_rec.product_agent,
                    t_nci_move_date = nci_rec.nci_move_date,
                    t_file_date = nci_rec.file_date,
                    IS_MAPPED = 'Y' 
                WHERE nci_activity_key = nci_rec.nci_activity_key;
                
                --*************************************************************************
                --* Update NCI_ACTIVITY_BASE new activation record as mapped. 
                --*************************************************************************
                UPDATE NCI_ACTIVITY_BASE 
                    SET is_mapped = 'Y' 
                    WHERE nci_activity_base_key =nci_rec. nci_activity_base_key;
                    
              COMMIT;
              
              --*************************************************************************
              --* Record the key of the nci_activity record so that if it has another match, it the next match will be ignored.
              --*************************************************************************
              prev_nci_activity_key := nci_rec.nci_activity_key;
              
            END IF;

        END LOOP;
        
END SP_NCI_MAP;

/