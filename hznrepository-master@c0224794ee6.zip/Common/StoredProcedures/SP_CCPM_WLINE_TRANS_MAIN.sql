CREATE OR REPLACE PROCEDURE SP_CCPM_WLINE_TRANS_MAIN
(
	p_year           IN     NUMBER,
	p_month          IN     NUMBER,
	p_day            IN     NUMBER	DEFAULT NULL,   
	p_result		OUT		VARCHAR2,
	p_errormessage  OUT		VARCHAR2
)
IS
   l_errmsg   VARCHAR2 (100);
   l_result	  VARCHAR2 (500);
   l_update_count		NUMBER;
   l_tot_update_count	NUMBER;
   l_reset_count		NUMBER;
   l_tot_reset_count	NUMBER;
   l_start_time         DATE;
   l_finish_time        DATE;
   l_minute_taken       NUMBER (8, 2);
BEGIN

    l_start_time := SYSDATE;
    l_tot_update_count := 0;
    l_tot_reset_count := 0;
	
    DBMS_OUTPUT.put_line('Starting(SP_CCPM_WLINE_TRANS_MAIN) at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));

	SP_CCPM_DTVN_CONTRACT_UPDATE(p_year => p_year, p_month => p_month, p_day => p_day, 
									p_reset_count => l_reset_count, p_update_count => l_update_count,
									p_result => l_result,
									p_errormessage => l_errmsg);

   l_tot_update_count := l_tot_update_count + l_update_count;
   l_tot_reset_count := l_tot_reset_count + l_reset_count;
   p_result := p_result || l_result;
   p_errormessage := l_errmsg;
   DBMS_OUTPUT.put_line('Finished (SP_CCPM_DTVN_CONTRACT_UPDATE) at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

	SP_CCPM_BRE_CONTRACT_UPDATE(p_year => p_year, p_month => p_month, p_day => p_day, 
									p_reset_count => l_reset_count, p_update_count => l_update_count,
									p_result => l_result,
									p_errormessage => l_errmsg);

    l_tot_update_count := l_tot_update_count + l_update_count;
    l_tot_reset_count := l_tot_reset_count + l_reset_count;
    p_result := p_result || l_result;
	p_errormessage := l_errmsg;
    DBMS_OUTPUT.put_line('Finished (SP_CCPM_BRE_CONTRACT_UPDATE) at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

	-- Populate totals for insert/update/delete/reset for populating the count in load_status/job_status
	p_result := p_result || 'TOTAL RECORDS RESET=' || l_tot_reset_count || chr(10);
	p_result := p_result || 'TOTAL RECORDS UPDATED=' || l_tot_update_count || chr(10);
    DBMS_OUTPUT.put_line('l_tot_reset_count: ' || l_tot_reset_count );
    DBMS_OUTPUT.put_line('l_tot_update_count: ' || l_tot_update_count );

    l_finish_time := SYSDATE;
    l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
    l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');
	
    DBMS_OUTPUT.put_line('Finished (SP_CCPM_WLINE_TRANS_MAIN) at: ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line ('Start time (SP_CCPM_WLINE_TRANS_MAIN): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
    DBMS_OUTPUT.put_line ('End time (SP_CCPM_WLINE_TRANS_MAIN): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('Total time taken (SP_CCPM_WLINE_TRANS_MAIN)  =  '
                           || l_minute_taken
                           || ' Minutes');	
						   
END SP_CCPM_WLINE_TRANS_MAIN;
/
