CREATE OR REPLACE PROCEDURE SP_NCI_LOOKUP(
    p_mobile         IN       varchar2,
    p_ban         IN       varchar2,
    p_isd_date        IN        DATE, 
    p_producttype          IN       VARCHAR2 default 'GENERIC RATE PLAN',
    p_productcode            in varchar2 default null,
    p_key_list          IN          NUMBER_TYPE default NUMBER_TYPE(0),
    p_resultset           OUT      sys_refcursor
)
IS
 TYPE nci_out_record IS RECORD (  nci_activity_key integer, isd_mobile varchar2(10), 
	isd_date date, isd_ban varchar2(30),  
	live_days integer, prod_sys_isd date,
	app_err_msg varchar2(32) );

   current_rec nci_out_record;
   prev_rec nci_out_record;
   l_ban varchar2(16);
   l_key_list NUMBER_TYPE;

BEGIN
    --dbms_output.put_line('product type '||p_producttype);
    l_ban := LTRIM(p_ban, '0');
    l_key_list := NUMBER_TYPE();

    BEGIN
        SELECT nci_activity_key, s_isd_mobile , s_isd_date , s_isd_ban ,  s_live_days,
        s_product_isd  , NULL
        into current_rec
        FROM nci_activity
        WHERE T_ISD_MOBILE = p_mobile
        AND LTRIM(T_ISD_BAN, '0') = l_ban
        AND T_ISD_DATE = p_isd_date
        AND t_product_type = p_producttype
        AND t_product_code = case when p_productcode is null then t_product_code else p_productcode end
        AND nci_activity_key NOT IN (SELECT column_value from table(p_key_list))
        AND rownum = 1 ORDER BY nci_activity_key ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                --dbms_output.put_line('No data found for source mobile = '||current_rec.l_isd_mobile ||' source BAN= '||current_rec.l_isd_ban);
                current_rec.isd_mobile := NULL;
                current_rec.live_days := 0;
				current_rec.nci_activity_key := 0;
                /*either no data found or we have reached to the end of the chain */
    END;
    current_rec.app_err_msg:= NULL  ;
    IF ( current_rec.isd_mobile  IS NOT NULL AND current_rec.isd_ban = l_ban)
    THEN
        /*avoid infinite recursion*/
        dbms_output.put_line('source and target ban should not be identical. mobile = '
        ||p_mobile ||' source BAN = '||l_ban );
        current_rec.app_err_msg:= ' INFINITE RECURSION'  ;
    END IF;


    --dbms_output.put_line('target mobile = ['|| p_mobile || '] target BAN= ['||l_ban ||
    --'] target isd_date = ['|| p_isd_Date ||
    --'] source mobile = ['||current_rec.isd_mobile || '] source BAN= ['||current_rec.isd_ban ||']' ||
    --'source isd_date = ['|| current_rec.isd_date || ']' );

    /* call recursively untill we reach to the end of the chain */
    IF ( current_rec.isd_mobile  IS NOT NULL and current_rec.app_err_msg is null ) THEN
     
        l_key_list := p_key_list MULTISET UNION NUMBER_TYPE(current_rec.nci_activity_key);
    
		if (p_producttype = 'GENERIC FEATURE')
		THEN
			SP_NCI_LOOKUP  (p_mobile => current_rec.isd_mobile , p_ban=>current_rec.isd_ban , p_isd_date=>current_rec.prod_sys_isd, p_key_list=>l_key_list, p_productcode=>p_productcode, p_producttype=>p_producttype , p_resultset=> p_resultset);		
		ELSE
			SP_NCI_LOOKUP  (p_mobile => current_rec.isd_mobile , p_ban=>current_rec.isd_ban , p_isd_date=>current_rec.isd_date, p_key_list=>l_key_list, p_productcode=>p_productcode, p_producttype=>p_producttype , p_resultset=> p_resultset);
		END IF;
		
        FETCH p_resultset INTO prev_rec;

        IF( prev_rec.isd_mobile IS NULL )
        THEN
            dbms_output.put_line('We have reached the end of the chain, Can not find history for mobile=[' || p_mobile || '] and ban = [' ||l_ban||']');
        ELSE
            /* make sure to add the live days for all moves*/
            prev_rec.live_days := prev_rec.live_days + current_rec.live_days;
            /* we need the isd level values for everything, so assign the previous values to the current values*/
            current_rec := prev_rec;
        END IF;
    END IF;

    OPEN p_resultset FOR
    SELECT  current_rec.nci_activity_key AS nci_activity_key, current_rec.isd_mobile AS isd_mobile, 
	current_rec.isd_date AS mobile_isd_date, current_rec.isd_ban AS isd_ban, 
	current_rec.live_days AS live_days, current_rec.prod_sys_isd AS prod_sys_isd,
    current_rec.app_err_msg as app_err_msg
    FROM dual;


END SP_NCI_LOOKUP;
/