CREATE OR REPLACE PROCEDURE SP_CMV_LOAD_REVERSAL 
(
	p_donor_mobile		IN VARCHAR2, 
	p_donor_isd			IN DATE, 
	p_recipient_mobile	IN VARCHAR2, 
	p_recipient_isd		IN DATE, 
	p_action_date		IN DATE,
	p_product_code_isd	IN DATE,
	p_is_active			OUT CHAR,
	p_contract_id		OUT NUMBER
)
IS
	CURSOR cmv_cur IS
		SELECT contract_moves_key, contract_id FROM ( SELECT contract_moves_key, contract_id FROM contract_moves 
			WHERE  eff_donor_mobile =  p_donor_mobile AND eff_donor_isd = p_donor_isd AND
				recipient_mobile =  p_recipient_mobile AND recipient_isd = p_recipient_isd 
			ORDER BY timestamp DESC) WHERE ROWNUM = 1;

	CURSOR chain_cur IS
		SELECT contract_moves_key FROM ( SELECT contract_moves_key FROM contract_moves 
			WHERE  eff_donor_mobile =  p_donor_mobile AND eff_donor_isd = p_donor_isd AND
				(recipient_mobile <>  p_recipient_mobile OR recipient_isd <> p_recipient_isd)
			ORDER BY timestamp DESC) WHERE ROWNUM = 1;

	l_is_active CHAR;
    l_contract_id NUMBER;

BEGIN
	dbms_output.put_line('SP_CMV_LOAD_REVERSAL:   Donor: ' || p_donor_mobile || ' Recipient: ' || p_recipient_mobile );

	l_is_active := 'N';
	l_contract_id := 0;

	/* Set the reversal date and make is_active = 'N' on the corresponding CMV that is being reversed */
	FOR cmv_rec IN cmv_cur LOOP
		
		UPDATE contract_moves SET is_active = 'N', reversal_date = p_action_date, mod_user = 'CMV_LOAD', mod_date = SYSDATE WHERE
			contract_moves_key = cmv_rec.contract_moves_key;

		l_contract_id := cmv_rec.contract_id;

	END LOOP;

	/* Handle the Reversal if it is part of a chain move. */
	FOR chain_rec IN chain_cur LOOP

		dbms_output.put_line('New CMR is part of a chain move.  Eff Donor set to: ' || p_recipient_mobile || ' contract_moves_key ' || l_contract_id);

		UPDATE contract_moves SET eff_donor_mobile = p_recipient_mobile, eff_donor_isd = p_recipient_isd, 
			mod_user = 'CMV_LOAD', mod_date = SYSDATE 
		WHERE contract_moves_key = chain_rec.contract_moves_key;

	END LOOP;

	p_is_active := l_is_active;
	p_contract_id := l_contract_id;

END SP_CMV_LOAD_REVERSAL;
/
