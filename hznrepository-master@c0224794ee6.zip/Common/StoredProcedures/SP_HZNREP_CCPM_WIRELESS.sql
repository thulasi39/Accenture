CREATE OR REPLACE PROCEDURE SP_HZNREP_CCPM_WIRELESS
(
    p_year IN integer,
    p_month IN integer,
    p_day IN integer,
    p_errormessage out varchar2
)
IS
BEGIN

    DECLARE
      i_tlg  tlg_daily_trans%ROWTYPE;
      i_ffsc  bid_prod_family_svc_chgs%ROWTYPE;
      o_rec  hznrep_ccpm_wireless_trans%ROWTYPE;
      
      i_latest_tlg  tlg_daily_trans%ROWTYPE;
      i_svc_latest_tlg  tlg_daily_trans%ROWTYPE;
      i_isd_tlg  tlg_daily_trans%ROWTYPE;
      sv_tlg  tlg_daily_trans%ROWTYPE;
      i_isd_tlg_addr  tlg_daily_trans%ROWTYPE;
      sv_tlg_addr  tlg_daily_trans%ROWTYPE;
      i_tlg_disconnect  tlg_daily_trans%ROWTYPE;
      i_tlg_rcl  tlg_daily_trans%ROWTYPE;
      i_tlg_nac_c16  tlg_daily_trans%ROWTYPE;
      
      l_ffsc_pair  bid_prod_family_svc_chgs%ROWTYPE;
      i_latest_ffsc  bid_prod_family_svc_chgs%ROWTYPE;
      
      cpc_rec cpc_product_catlg%rowtype;

      l_tlg_rec_ctr INTEGER;
      l_ffsc_rec_ctr INTEGER;
      l_rec_ctr INTEGER;
      
      l_tlg_insert_ctr INTEGER;
      l_ffsc_insert_ctr INTEGER;
      l_insert_ctr INTEGER;

      l_delete_ctr INTEGER;
      
      l_ffsc_skip_ctr INTEGER;
      
      l_prod_id NUMBER(28);
      l_prod_type varchar2(100);
      l_attrib_name varchar2(50);
      l_attrib_value varchar2(150);
      l_action_date DATE;
      
      sv_isd_mobile varchar2(10);
      sv_isd DATE;
      sv_action_date DATE;
      
      l_hznrep_ccpm_wrless_trans_key NUMBER;
      
      TLG_LATEST_FOUND BOOLEAN;
      FFSC_LATEST_FOUND BOOLEAN;
      TLG_ISD_FOUND BOOLEAN;
      TLG_ISD_ADDR_FOUND BOOLEAN;
      PAIR_FOUND BOOLEAN;
      RCL_FOUND BOOLEAN;
      NAC_C16_FOUND BOOLEAN;
      DISCONNECT_FOUND BOOLEAN;

      
      -- TLG input cursor
      CURSOR tlg_input_cursor IS
      SELECT *
      FROM tlg_daily_trans
      WHERE year = p_year
        AND month = p_month
        AND day = p_day
        AND is_valid = 'Y'
        AND ((action_type = 'NAC' and product_type = 'generic rate plan') or
             (action_type = 'CAN' and product_type = 'generic rate plan') or
             (action_type = 'RCL' and product_type = 'generic rate plan') or
             (action_type in ('C16','C17','SVC')) or
             (action_type = 'CAN' and
              product_id in (SELECT prod_id
                             FROM cpc_product_catlg
                             WHERE attrib_name = 'equipmentUpgradeSOC'
                               AND attrib_value = '1'))
             );

      -- FFSC input cursor
      CURSOR ffsc_input_cursor IS
      SELECT *
      FROM bid_prod_family_svc_chgs
      WHERE year = p_year
        AND month = p_month
        AND day = p_day
        AND action_type in ('A','B','F','H','K','X','Y')
        AND NVL(promo_ind,' ') <> 'N' 
      ORDER BY isd_mobile, isd, action_date;
      
      -- CPC cursor
      CURSOR cpc_cur IS
      SELECT *
      FROM cpc_product_catlg
      WHERE prod_id = l_prod_id
        AND UPPER(attrib_name) in ('PRODUCTCODE','DESCRIPTION','PRODUCTTYPE','COMPREVENUE','MONTHLYCOST')
        AND l_action_date BETWEEN eff_date AND exp_date;
              
    BEGIN
    
      DBMS_OUTPUT.put_line ('SP_HZNREP_CCPM_WIRELESS Start on ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' ));

      l_tlg_rec_ctr := 0;
      l_ffsc_rec_ctr := 0;
      l_rec_ctr := 0;
      l_tlg_insert_ctr := 0;
      l_ffsc_insert_ctr := 0;
      l_insert_ctr := 0;
      l_delete_ctr := 0;
      l_ffsc_skip_ctr := 0;
      
      sv_isd_mobile := ' ';
      sv_isd := to_date('20000101','YYYYMMDD');
      sv_action_date := to_date('20000101','YYYYMMDD');
      
      --
      -- START: Delete this day's data in case of a rerun
      --
      DBMS_OUTPUT.put_line ('SP_HZNREP_CCPM_WIRELESS Start Delete on ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' ));
               
      DELETE 
      FROM hznrep_ccpm_wireless_trans
      WHERE year = p_year
        AND month = p_month
        AND day = p_day;

      l_delete_ctr := l_delete_ctr + SQL%ROWCOUNT;
      
      COMMIT;
      
      DBMS_OUTPUT.put_line ('SP_HZNREP_CCPM_WIRELESS End Delete on ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' ));
      --
      -- END: Delete this day's data in case of a rerun
      --

      o_rec.year := p_year;
      o_rec.month := p_month;
      o_rec.day := p_day;
      o_rec.mod_user := 'HZNREP_CCPM_WIRELESS';
      
      --
      -- BEGIN FOR 1..2 LOOP
      --
      -- First pass is TLG_DAILY_TRANS
      -- Second pass is FFSC
      --
      FOR l_index IN 1..2
      LOOP
        
        BEGIN
          IF l_index = 1 THEN
             OPEN tlg_input_cursor;
          ELSE
             OPEN ffsc_input_cursor;
          END IF;
         
          LOOP
            IF l_index = 1 THEN
               -------------------------------------
               -- START: Process TLG_DAILY_TRANS
               -------------------------------------
               FETCH tlg_input_cursor into i_tlg;
               EXIT WHEN tlg_input_cursor%NOTFOUND;
                              
               l_tlg_rec_ctr := l_tlg_rec_ctr + 1;
               
               --
               -- Get product details from CPC_PRODUCT_CATLG using product_id 
               --
               
               -- Set to default value
               o_rec.product_code := 'UNKNOWN';
               o_rec.product_desc := 'UNKNOWN';
               o_rec.product_type := NULL;
               o_rec.mrc := 0;
               o_rec.comp_revenue := 0;
               
               l_prod_id := i_tlg.product_id;
               l_action_date := i_tlg.action_date;
               
               FOR cpc_rec in cpc_cur
               LOOP
                 l_attrib_name := UPPER(cpc_rec.attrib_name);
                 
                 IF l_attrib_name = 'PRODUCTCODE' THEN
                    o_rec.product_code := SUBSTR(cpc_rec.attrib_value,1,20);
                 ELSIF l_attrib_name = 'DESCRIPTION' then
                    o_rec.product_desc := SUBSTR(cpc_rec.attrib_value,1,100);
                 ELSIF (l_attrib_name = 'PRODUCTTYPE' ) THEN
                    IF UPPER(cpc_rec.attrib_value) = 'GENERIC RATE PLAN' THEN
                       o_rec.product_type := 'R';
                    ELSE
                       o_rec.product_type := 'F';
                    END IF;
                 ELSIF l_attrib_name = 'MONTHLYCOST' THEN
                    o_rec.mrc := cpc_rec.attrib_value;
                 ELSIF l_attrib_name = 'COMPREVENUE' THEN
                    o_rec.comp_revenue := cpc_rec.attrib_value;
                 ELSE
                    NULL; 
                 END IF;
               END LOOP;
               
               o_rec.bill_market := i_tlg.bill_mkt_code;
               o_rec.ctn_market := i_tlg.mobile_mkt_code;
               o_rec.dealer_code := i_tlg.seller_id;
               o_rec.cust_name := i_tlg.custname;
               o_rec.fan_id := i_tlg.fan;
               o_rec.ctn := i_tlg.current_mobile;
               o_rec.isd_ctn := i_tlg.p_isd_mobile;
               o_rec.ban := i_tlg.ban;
               o_rec.isd_ban := i_tlg.isd_ban;
               
               --
               -- Action Type
               --
               IF i_tlg.action_type = 'NAC' THEN
                  o_rec.action_type := 'ACT';
               ELSIF i_tlg.action_type = 'RCL' THEN
                  o_rec.action_type := 'ACT';
               ELSIF i_tlg.action_type = 'CAN' THEN
                  o_rec.action_type := 'DISC';
               ELSIF i_tlg.action_type = 'C16' THEN
                  o_rec.action_type := 'EQUUPG';
               ELSIF i_tlg.action_type = 'C17' THEN
                  o_rec.action_type := 'EQUUPGRVL';
               ELSIF i_tlg.action_type = 'SVC' THEN
                  o_rec.action_type := 'CHRP';
               ELSE
                  o_rec.action_type := 'UNKNOWN';
               END IF;
               
               --
               -- Override Upgrade SOC CAN
               --
               IF i_tlg.action_type = 'CAN' and i_tlg.product_type <> 'generic rate plan' THEN
                  o_rec.action_type := 'EQUUPGRVL';
               END IF;
               
               o_rec.action_date := i_tlg.action_date;
               
               --
               -- Device Model
               --
               o_rec.device_model := NULL;
               
               BEGIN
                 SELECT attrib_value
                 INTO l_attrib_value
                 FROM cpc_product_catlg
                 WHERE prod_type = 'Oracle SKU'
                   AND UPPER(attrib_name) = 'MODEL'
                   AND i_tlg.action_date BETWEEN eff_date AND exp_date
                   AND prod_id = (
                       SELECT prod_id
                       FROM cpc_product_catlg
                       WHERE prod_type = 'Oracle SKU'
                         AND UPPER(attrib_name) = 'ITEMID'
                         AND attrib_value = i_tlg.item_id
                         AND i_tlg.action_date BETWEEN eff_date AND exp_date
                         AND ROWNUM = 1);
               EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                   o_rec.device_model := 'UNKNOWN';
               END;
               
               IF NVL(o_rec.device_model,' ') <> 'UNKNOWN' THEN
                  o_rec.device_model := SUBSTR(l_attrib_value,1,50);
               END IF;
               
               IF i_tlg.p_imei IS NULL THEN
                  o_rec.imei := i_tlg.imei;
               ELSE
                  o_rec.imei := i_tlg.p_imei;
               END IF;
               
               o_rec.customer_type := i_tlg.customer_type;
               o_rec.manufacturer := i_tlg.manufacturer;
               o_rec.segment := i_tlg.segment;
               
               --
               -- Contract
               --
               o_rec.contract_date := NULL;
               o_rec.contract_term := NULL;
               o_rec.contract_type := NULL;
               
               IF i_tlg.action_type in ('NAC','C16','C17') AND
                  i_tlg.contract_term > 0 THEN
                  
                  IF i_tlg.action_type = 'C17' THEN
                     o_rec.contract_date := i_tlg.product_code_isd;
                  ELSE
                     o_rec.contract_date := i_tlg.action_date;
                  END IF;
                  
                  o_rec.contract_term := i_tlg.contract_term;
                  o_rec.contract_type := i_tlg.contract_type;
                  
               ELSIF i_tlg.action_type = 'SVC' THEN
                  
                  TLG_LATEST_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_latest_tlg
                    FROM (SELECT *
                          FROM tlg_daily_trans
                          WHERE p_isd_mobile = i_tlg.p_isd_mobile
                            AND p_mobile_isd = i_tlg.p_mobile_isd
                            AND action_date <= i_tlg.action_date
                            AND timestamp <= i_tlg.timestamp
                            AND action_type in ('CAN','RCL','NAC')
                            AND product_type = 'generic rate plan'
                          ORDER BY action_date desc, timestamp desc)
                    WHERE rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      TLG_LATEST_FOUND := FALSE;
                  END;
                  
                  IF TLG_LATEST_FOUND AND
                     i_latest_tlg.action_type = 'NAC' AND
                     i_latest_tlg.contract_term > 0 AND
                     add_months(i_latest_tlg.action_date, i_latest_tlg.contract_term) >= i_tlg.action_date THEN
                     o_rec.contract_date := i_latest_tlg.action_date;
                     o_rec.contract_term := i_latest_tlg.contract_term;
                     o_rec.contract_type := i_latest_tlg.contract_type;                     
                  END IF;
                  
               ELSIF i_tlg.action_type = 'CAN' AND i_tlg.product_type = 'generic rate plan' THEN
                  
                  TLG_LATEST_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_latest_tlg
                    FROM (SELECT *
                          FROM tlg_daily_trans
                          WHERE p_isd_mobile = i_tlg.p_isd_mobile
                            AND p_mobile_isd = i_tlg.p_mobile_isd
                            AND action_date <= i_tlg.action_date
                            AND timestamp < i_tlg.timestamp
                            AND action_type in ('CAN','RCL','NAC','SVC')
                            AND product_type = 'generic rate plan'
                          ORDER BY action_date desc, timestamp desc)
                    WHERE rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      TLG_LATEST_FOUND := FALSE;
                  END;
                                    
                  IF TLG_LATEST_FOUND THEN
                     IF i_latest_tlg.action_type = 'NAC' AND
                        i_latest_tlg.contract_term > 0 THEN
                        o_rec.contract_date := i_latest_tlg.action_date;
                        o_rec.contract_term := i_latest_tlg.contract_term;
                        o_rec.contract_type := i_latest_tlg.contract_type;
                        
                     ELSIF i_latest_tlg.action_type = 'SVC' THEN
                     
                        TLG_LATEST_FOUND := TRUE;
                        
                        BEGIN
                          SELECT *
                          INTO i_svc_latest_tlg
                          FROM (SELECT *
                                FROM tlg_daily_trans
                                WHERE p_isd_mobile = i_latest_tlg.p_isd_mobile
                                  AND p_mobile_isd = i_latest_tlg.p_mobile_isd
                                  AND action_date <= i_latest_tlg.action_date
                                  AND timestamp <= i_latest_tlg.timestamp
                                  AND action_type in ('CAN','RCL','NAC')
                                  AND product_type = 'generic rate plan'
                                ORDER BY action_date desc, timestamp desc)
                          WHERE rownum = 1;
                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                            TLG_LATEST_FOUND := FALSE;
                        END;
                        
                        IF TLG_LATEST_FOUND AND
                           i_svc_latest_tlg.action_type = 'NAC' AND
                           i_svc_latest_tlg.contract_term > 0 AND
                           add_months(i_svc_latest_tlg.action_date, i_svc_latest_tlg.contract_term) >= i_latest_tlg.action_date THEN
                           o_rec.contract_date := i_svc_latest_tlg.action_date;
                           o_rec.contract_term := i_svc_latest_tlg.contract_term;
                           o_rec.contract_type := i_svc_latest_tlg.contract_type;                     
                        END IF;
                     END IF;
                  END IF;
                  
               ELSIF i_tlg.action_type = 'CAN' AND i_tlg.product_type <> 'generic rate plan' THEN
                  
                  TLG_LATEST_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_latest_tlg
                    FROM (SELECT *
                          FROM tlg_daily_trans
                          WHERE p_isd_mobile = i_tlg.p_isd_mobile
                            AND p_mobile_isd = i_tlg.p_mobile_isd
                            AND action_date <= i_tlg.action_date
                            AND timestamp < i_tlg.timestamp
                            AND product_code = i_tlg.product_code
                            AND action_type in ('CAN','RCL','NAC','C16')
                          ORDER BY action_date desc, timestamp desc)
                    WHERE rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      TLG_LATEST_FOUND := FALSE;
                  END;
                  
                  IF TLG_LATEST_FOUND AND
                     i_latest_tlg.action_type in ('C16','NAC')  AND
                     i_latest_tlg.contract_term > 0 THEN
                     o_rec.contract_date := i_latest_tlg.action_date;
                     o_rec.contract_term := i_latest_tlg.contract_term;
                     o_rec.contract_type := i_latest_tlg.contract_type;                     
                  END IF;
                  
               END IF;
               
               --
               -- Device Class
               --
               o_rec.device_class := NULL;
               
               BEGIN
                 SELECT attrib_value
                 INTO l_attrib_value
                 FROM cpc_product_catlg
                 WHERE prod_type = 'Oracle SKU'
                   AND UPPER(attrib_name) = 'DEVICECLASS'
                   AND i_tlg.action_date BETWEEN eff_date AND exp_date
                   AND prod_id = (
                       SELECT prod_id
                       FROM cpc_product_catlg
                       WHERE prod_type = 'Oracle SKU'
                         AND UPPER(attrib_name) = 'ITEMID'
                         AND attrib_value = i_tlg.item_id
                         AND i_tlg.action_date BETWEEN eff_date AND exp_date
                         AND ROWNUM = 1);
               EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                   o_rec.device_class := 'OTHER';
               END;
               
               IF NVL(o_rec.device_class,' ') <> 'OTHER' THEN
                  o_rec.device_class := SUBSTR(l_attrib_value,1,30);
               END IF;
               
               --
               -- Get previous product details from CPC_PRODUCT_CATLG using prev_product_id 
               --
               
               -- Set to default value
               o_rec.prev_product_code := NULL;
               o_rec.prev_mrc := NULL;
               o_rec.prev_comp_revenue := NULL;
               
               IF i_tlg.prev_product_id IS NOT NULL THEN
               
                  o_rec.prev_product_code := 'UNKNOWN';
                  o_rec.prev_mrc := 0;
                  o_rec.prev_comp_revenue := 0;
                  
                  l_prod_id := i_tlg.prev_product_id;
                  l_action_date := i_tlg.action_date;
                  
                  FOR cpc_rec in cpc_cur
                  LOOP
                    l_attrib_name := UPPER(cpc_rec.attrib_name);
                    
                    IF l_attrib_name = 'PRODUCTCODE' THEN
                       o_rec.prev_product_code := SUBSTR(cpc_rec.attrib_value,1,20);
                    ELSIF l_attrib_name = 'MONTHLYCOST' THEN
                       o_rec.prev_mrc := cpc_rec.attrib_value;
                    ELSIF l_attrib_name = 'COMPREVENUE' THEN
                       o_rec.prev_comp_revenue := cpc_rec.attrib_value;
                    ELSE
                       NULL; 
                    END IF;
                  END LOOP;
                  
               END IF;
                              
               IF i_tlg.action_type in ('C16','C17') AND
                  i_tlg.previous_term > 0 THEN
                  o_rec.prev_contract_term := i_tlg.previous_term;
                  o_rec.prev_contract_type := i_tlg.prev_contract_type;
               ELSE
                  o_rec.prev_contract_term := NULL;
                  o_rec.prev_contract_type := NULL;
               END IF;
               
               o_rec.addr1 := i_tlg.addr_line1;
               o_rec.addr2 := i_tlg.addr_line2;
               o_rec.city := i_tlg.city;
               o_rec.state := i_tlg.state;
               o_rec.zipcd := i_tlg.zip_code;
               o_rec.tlg_daily_trans_key := i_tlg.tlg_daily_trans_key;
               o_rec.bid_prod_family_key := NULL;
               o_rec.product_id := i_tlg.product_id;
               o_rec.src_action_type := i_tlg.action_type;
               o_rec.isd := i_tlg.p_mobile_isd;
               o_rec.mobile_type := i_tlg.mobile_type;
               
               IF i_tlg.action_type = 'C17' THEN
                  o_rec.feature_isd := i_tlg.product_code_isd;
               ELSE
                  o_rec.feature_isd := NULL;
               END IF;
               
               IF i_tlg.action_type = 'RCL' THEN
                  o_rec.dcd := i_tlg.sys_dcd;
               ELSIF i_tlg.action_type = 'CAN' THEN
                  o_rec.dcd := i_tlg.action_date;
               ELSE
                  o_rec.dcd := NULL;
               END IF;
               
               --
               -- END: Process TLG_DAILY_TRANS
               --
            ELSE
               --------------------------
               -- START: Process FFSC
               --------------------------
               FETCH ffsc_input_cursor into i_ffsc;
               EXIT WHEN ffsc_input_cursor%NOTFOUND;
               
               l_ffsc_rec_ctr := l_ffsc_rec_ctr + 1;
               
               BEGIN
                 SELECT prod_type
                 INTO l_prod_type
                 FROM cpc_product_catlg
                 WHERE prod_id = i_ffsc.product_id
                   AND UPPER(attrib_name) = 'PRODUCTID'
                   AND i_ffsc.action_date BETWEEN eff_date AND exp_date;
               EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                   l_prod_type := NULL;
               END;
               
               --
               -- Only process features
               --
               IF l_prod_type = 'generic rate plan' THEN
                  l_ffsc_skip_ctr := l_ffsc_skip_ctr + 1;
                  CONTINUE;
               END IF;
               
               --
               -- Get product details from CPC_PRODUCT_CATLG using product_id 
               --
               
               -- Set to default value
               o_rec.product_code := 'UNKNOWN';
               o_rec.product_desc := 'UNKNOWN';
               o_rec.mrc := 0;
               o_rec.comp_revenue := 0;
               
               l_prod_id := i_ffsc.product_id;
               l_action_date := i_ffsc.action_date;
               
               FOR cpc_rec in cpc_cur
               LOOP
                 l_attrib_name := UPPER(cpc_rec.attrib_name);
                 
                 IF l_attrib_name = 'PRODUCTCODE' THEN
                    o_rec.product_code := SUBSTR(cpc_rec.attrib_value,1,20);
                 ELSIF l_attrib_name = 'DESCRIPTION' then
                    o_rec.product_desc := SUBSTR(cpc_rec.attrib_value,1,100);
                 ELSIF l_attrib_name = 'MONTHLYCOST' THEN
                    o_rec.mrc := cpc_rec.attrib_value;
                 ELSIF l_attrib_name = 'COMPREVENUE' THEN
                    o_rec.comp_revenue := cpc_rec.attrib_value;
                 ELSE
                    NULL; 
                 END IF;
               END LOOP;
               
               o_rec.bill_market := i_ffsc.bill_mkt_code;
               o_rec.ctn_market := i_ffsc.mobile_mkt_code;
               o_rec.dealer_code := i_ffsc.seller_id;
               o_rec.product_type := 'F';               
               o_rec.cust_name := i_ffsc.customer_name;
               o_rec.fan_id := i_ffsc.fan;
               o_rec.ctn := i_ffsc.current_mobile;
               o_rec.isd_ctn := i_ffsc.isd_mobile;
               o_rec.ban := i_ffsc.account_number;
               
               --
               -- Action Type
               --
               IF i_ffsc.action_type in ('A','X') THEN
                  o_rec.action_type := 'FEATADD';
               ELSIF i_ffsc.action_type in ('B','Y') THEN
                  o_rec.action_type := 'FEATRMV';
               ELSIF i_ffsc.action_type in ('F','H','K') THEN
                  o_rec.action_type := 'CHF';
               ELSE
                  o_rec.action_type := 'UNKNOWN';
               END IF;
               
               o_rec.action_date := i_ffsc.action_date;
               
               o_rec.device_model := i_ffsc.device_type;
               o_rec.imei := i_ffsc.imei;               
               o_rec.customer_type := i_ffsc.customer_type;
               o_rec.manufacturer := i_ffsc.manufacturer;
               
               --
               -- Device Class
               --
               o_rec.device_class := 'OTHER';
               
               --
               -- Get previous product details from CPC_PRODUCT_CATLG using prev_product_id 
               --
               
               -- Set to default value
               o_rec.prev_product_code := NULL;
               o_rec.prev_mrc := NULL;
               o_rec.prev_comp_revenue := NULL;
               
               IF i_ffsc.prev_product_id IS NOT NULL THEN
               
                  o_rec.prev_product_code := 'UNKNOWN';
                  o_rec.prev_mrc := 0;
                  o_rec.prev_comp_revenue := 0;
                  
                  l_prod_id := i_ffsc.prev_product_id;
                  l_action_date := i_ffsc.action_date;
                  
                  FOR cpc_rec in cpc_cur
                  LOOP
                    l_attrib_name := UPPER(cpc_rec.attrib_name);
                    
                    IF l_attrib_name = 'PRODUCTCODE' THEN
                       o_rec.prev_product_code := SUBSTR(cpc_rec.attrib_value,1,20);
                    ELSIF l_attrib_name = 'MONTHLYCOST' THEN
                       o_rec.prev_mrc := cpc_rec.attrib_value;
                    ELSIF l_attrib_name = 'COMPREVENUE' THEN
                       o_rec.prev_comp_revenue := cpc_rec.attrib_value;
                    ELSE
                       NULL; 
                    END IF;
                  END LOOP;
               
               END IF;
               
               o_rec.bid_prod_family_key := i_ffsc.bid_prod_family_key;
               o_rec.product_id := i_ffsc.product_id;
               o_rec.src_action_type := i_ffsc.action_type;
               o_rec.isd := i_ffsc.isd;
               
               IF i_ffsc.product_type_id = 'G' THEN
                  o_rec.mobile_type := i_ffsc.mobile_type;
               ELSIF i_ffsc.shared_data_product_type = 'G' THEN
                  o_rec.mobile_type := i_ffsc.shared_data_mobile_type;
               ELSE
                  o_rec.mobile_type := NULL;
               END IF;
               
               --
               -- START: Set FEATURE_ISD
               --
               o_rec.feature_isd := NULL;
               o_rec.pair_key := NULL;
               
               IF i_ffsc.action_type in ('A','X') THEN
                  o_rec.feature_isd := i_ffsc.action_date;
               ELSIF i_ffsc.action_type in ('B','Y') THEN                     
                    BEGIN
                          Select max(action_date) into
                          o_rec.feature_isd 
                          from
                          bid_prod_family_svc_chgs
                          Where isd_mobile = i_ffsc.isd_mobile 
                          and   isd = i_ffsc.isd
                          and   action_date  < i_ffsc.action_date
                          and   product_code = i_ffsc.product_code 
                          and   action_type in ('A','F','H','K','X')
                          AND NVL(promo_ind,' ') <> 'N';
                    EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      o_rec.feature_isd := NULL;
                    END;
               ELSIF i_ffsc.action_type in ('F','H','K') THEN
                  PAIR_FOUND := TRUE;                 
                  BEGIN
                    SELECT *
                    INTO l_ffsc_pair
                    FROM bid_prod_family_svc_chgs
                    WHERE year = i_ffsc.year
                      AND month = i_ffsc.month
                      AND day = i_ffsc.day
                      AND current_mobile = i_ffsc.current_mobile
                      AND account_number = i_ffsc.account_number
                      AND action_date = i_ffsc.action_date
                      AND product_code = i_ffsc.prev_product_code
                      AND action_type in ('E','G','J')
                      AND NVL(promo_ind,' ') <> 'N' 
                      AND rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      PAIR_FOUND := FALSE;
                  END;
                  
                  IF PAIR_FOUND THEN
                     o_rec.pair_key := l_ffsc_pair.bid_prod_family_key;
                     BEGIN
                          Select max(action_date) into
                          o_rec.feature_isd 
                          from
                          bid_prod_family_svc_chgs
                          Where isd_mobile = l_ffsc_pair.isd_mobile
                          and   isd = l_ffsc_pair.isd
                          and   action_date  < l_ffsc_pair.action_date  
                          and   product_code = l_ffsc_pair.product_code 
                          and   action_type in  ('A','F','H','K','X')
                          AND NVL(promo_ind,' ') <> 'N';
                     EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                       o_rec.feature_isd := NULL;
                     END;
                  END IF;
                  
               END IF;
               --
               -- END: Set FEATURE_ISD
               --
                              
               --
               -- START: Set DCD
               --
               o_rec.dcd := NULL;
               o_rec.activation_key := NULL;
               o_rec.disconnect_key := NULL;
                              
               IF i_ffsc.action_type in ('B','Y') THEN
               
                  DISCONNECT_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_tlg_disconnect
                    FROM tlg_daily_trans
                    WHERE p_isd_mobile = i_ffsc.isd_mobile
                      AND p_mobile_isd = i_ffsc.isd
                      AND current_mobile = i_ffsc.current_mobile
                      AND ban = i_ffsc.account_number
                      AND action_date = i_ffsc.action_date
                      AND action_type = 'CAN'
                      AND product_type = 'generic rate plan'
                      AND rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      DISCONNECT_FOUND := FALSE;
                  END;
                  
                  IF DISCONNECT_FOUND THEN
                     o_rec.disconnect_key := i_tlg_disconnect.tlg_daily_trans_key;
                     o_rec.dcd := i_tlg_disconnect.action_date;
                  END IF;
                  
               ELSIF i_ffsc.action_type in ('A','X') THEN
               
                  RCL_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_tlg_rcl
                    FROM tlg_daily_trans
                    WHERE p_isd_mobile = i_ffsc.isd_mobile
                      AND p_mobile_isd = i_ffsc.isd
                      AND current_mobile = i_ffsc.current_mobile
                      AND ban = i_ffsc.account_number
                      AND action_date = i_ffsc.action_date
                      AND action_type = 'RCL'
                      AND product_type = 'generic rate plan'
                      AND rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      RCL_FOUND := FALSE;
                  END;
                  
                  IF RCL_FOUND THEN
                  
                     o_rec.activation_key := i_tlg_rcl.tlg_daily_trans_key;
                     
                     PAIR_FOUND := TRUE;
                  
                     BEGIN
                       SELECT *
                       INTO l_ffsc_pair
                       FROM bid_prod_family_svc_chgs
                       WHERE isd_mobile = i_ffsc.isd_mobile
                         AND isd = i_ffsc.isd
                         AND current_mobile = i_ffsc.current_mobile
                         AND account_number = i_ffsc.account_number
                         AND product_code = i_ffsc.product_code
                         AND action_date = i_tlg_rcl.sys_dcd
                         AND action_type in ('B','Y')
                         AND NVL(promo_ind,' ') <> 'N' 
                         AND rownum = 1;
                     EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                         PAIR_FOUND := FALSE;
                     END;
                     
                     IF PAIR_FOUND THEN
                        o_rec.disconnect_key := l_ffsc_pair.bid_prod_family_key;
                        o_rec.dcd := i_tlg_rcl.sys_dcd;
                     END IF;
                  
                  END IF;
                  
               END IF;
               --
               -- END: Set DCD
               --
               
               --
               -- START: Set Contract Date, Contract Term, Contract Type
               --
               o_rec.contract_date := NULL;
               o_rec.contract_term := NULL;
               o_rec.contract_type := NULL;
               o_rec.tlg_daily_trans_key := NULL;
               
               IF i_ffsc.action_type in ('A','X','F','H','K') THEN
               
                  NAC_C16_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_tlg_nac_c16
                    FROM (SELECT *
                          FROM tlg_daily_trans
                          WHERE p_isd_mobile = i_ffsc.isd_mobile
                            AND p_mobile_isd = i_ffsc.isd
                            AND action_date <= i_ffsc.action_date
                            AND ((action_type in ('CAN','RCL','NAC') and product_type = 'generic rate plan') OR
                                 (action_type = 'C16'))
                          ORDER BY action_date desc, timestamp desc)
                    WHERE rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      NAC_C16_FOUND := FALSE;
                  END;
                  
                  IF NAC_C16_FOUND THEN
                  
                     o_rec.tlg_daily_trans_key := i_tlg_nac_c16.tlg_daily_trans_key;
                     
                     IF i_tlg_nac_c16.action_type in ('NAC','C16') AND
                        i_tlg_nac_c16.contract_term > 0 AND
                        add_months(i_tlg_nac_c16.action_date, i_tlg_nac_c16.contract_term) >= i_ffsc.action_date THEN
                        o_rec.contract_date := i_tlg_nac_c16.action_date;
                        o_rec.contract_term := i_tlg_nac_c16.contract_term;
                        o_rec.contract_type := i_tlg_nac_c16.contract_type;
                     END IF;
                     
                  END IF;
                  
               ELSIF i_ffsc.action_type in ('B','Y') THEN
               
                  FFSC_LATEST_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_latest_ffsc
                    FROM (SELECT *
                          FROM bid_prod_family_svc_chgs
                          WHERE isd_mobile = i_ffsc.isd_mobile
                            AND isd = i_ffsc.isd
                            AND action_date < i_ffsc.action_date
                            AND product_code = i_ffsc.product_code
                            AND action_type in ('A','F','H','K','X')
                            AND NVL(promo_ind,' ') <> 'N'
                          ORDER BY action_date desc)
                    WHERE rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      FFSC_LATEST_FOUND := FALSE;
                  END;
                                    
                  IF FFSC_LATEST_FOUND THEN
                  
                     NAC_C16_FOUND := TRUE;
                                          
                     BEGIN
                       SELECT *
                       INTO i_tlg_nac_c16
                       FROM (SELECT *
                             FROM tlg_daily_trans
                             WHERE p_isd_mobile = i_latest_ffsc.isd_mobile
                               AND p_mobile_isd = i_latest_ffsc.isd
                               AND action_date <= i_latest_ffsc.action_date
                               AND ((action_type in ('CAN','RCL','NAC') and product_type = 'generic rate plan') OR
                                    (action_type = 'C16'))
                             ORDER BY action_date desc, timestamp desc)
                       WHERE rownum = 1;
                     EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                         NAC_C16_FOUND := FALSE;
                     END;
                     
                     IF NAC_C16_FOUND THEN
                     
                        o_rec.tlg_daily_trans_key := i_tlg_nac_c16.tlg_daily_trans_key;
                        
                        IF i_tlg_nac_c16.action_type in ('NAC','C16') AND
                           i_tlg_nac_c16.contract_term > 0 AND
                           add_months(i_tlg_nac_c16.action_date, i_tlg_nac_c16.contract_term) >= i_latest_ffsc.action_date THEN
                           o_rec.contract_date := i_tlg_nac_c16.action_date;
                           o_rec.contract_term := i_tlg_nac_c16.contract_term;
                           o_rec.contract_type := i_tlg_nac_c16.contract_type;
                        END IF;
                        
                     END IF;
                     
                  END IF;
               END IF;
               --
               -- END: Set Contract Date, Contract Term, Contract Type
               --

               --
               -- Look for additional fields
               -- in TLG_DAILY_TRANS only if break
               --
               IF i_ffsc.isd_mobile <> sv_isd_mobile OR
                  i_ffsc.isd <> sv_isd OR
                  i_ffsc.action_date <> sv_action_date THEN
                                                   
                  TLG_ISD_ADDR_FOUND := TRUE;
                  
                  BEGIN
                    SELECT *
                    INTO i_isd_tlg_addr
                    FROM (SELECT *
                          FROM tlg_daily_trans
                          WHERE p_isd_mobile = i_ffsc.isd_mobile
                            and p_mobile_isd = i_ffsc.isd
                            and action_date <= i_ffsc.action_date
                          ORDER BY action_date desc, timestamp desc)
                    WHERE rownum = 1;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      TLG_ISD_ADDR_FOUND := FALSE;
                  END;
                  
                  IF TLG_ISD_ADDR_FOUND THEN
                     sv_tlg_addr.isd_ban := i_isd_tlg_addr.isd_ban;
                     sv_tlg.segment := i_isd_tlg_addr.segment;
                     sv_tlg_addr.addr_line1 := i_isd_tlg_addr.addr_line1;
                     sv_tlg_addr.addr_line2 := i_isd_tlg_addr.addr_line2;
                     sv_tlg_addr.city := i_isd_tlg_addr.city;
                     sv_tlg_addr.state := i_isd_tlg_addr.state;
                     sv_tlg_addr.zip_code := i_isd_tlg_addr.zip_code;
                     sv_tlg_addr.custname := i_isd_tlg_addr.custname;
                     sv_tlg_addr.tlg_daily_trans_key := i_isd_tlg_addr.tlg_daily_trans_key;
                  ELSE
                     sv_tlg_addr.isd_ban := NULL;
                     sv_tlg.segment := NULL;
                     sv_tlg_addr.addr_line1 := NULL;
                     sv_tlg_addr.addr_line2 := NULL;
                     sv_tlg_addr.city := NULL;
                     sv_tlg_addr.state := NULL;
                     sv_tlg_addr.zip_code := NULL;
                     sv_tlg_addr.custname := NULL;
                     sv_tlg_addr.tlg_daily_trans_key := NULL;
                  END IF;
                  
                  sv_isd_mobile := i_ffsc.isd_mobile;
                  sv_isd := i_ffsc.isd;
                  sv_action_date := i_ffsc.action_date;
               
               END IF;
               
               --
               -- Populate additional fields 
               -- from saved control break fields
               --
               o_rec.prev_contract_term := NULL;
               o_rec.prev_contract_type := NULL;
               
               o_rec.isd_ban := sv_tlg_addr.isd_ban;
               o_rec.segment := sv_tlg.segment;
               o_rec.addr1 := sv_tlg_addr.addr_line1;
               o_rec.addr2 := sv_tlg_addr.addr_line2;
               o_rec.city := sv_tlg_addr.city;
               o_rec.state := sv_tlg_addr.state;
               o_rec.zipcd := sv_tlg_addr.zip_code;
               o_rec.tlg_daily_trans_key_addr := sv_tlg_addr.tlg_daily_trans_key;
               
               IF TLG_ISD_ADDR_FOUND and trim(sv_tlg_addr.custname) IS NOT NULL THEN
                  o_rec.cust_name := sv_tlg_addr.custname;
               END IF;
               
               --
               -- END: Process FFSC
               --
            END IF;
            
            --
            -- Common
            --
            o_rec.mod_date := sysdate;
            
            SELECT seq_hznrep_ccpm_wireless_trans.nextval INTO l_hznrep_ccpm_wrless_trans_key FROM dual;
            o_rec.hznrep_ccpm_wireless_trans_key := l_hznrep_ccpm_wrless_trans_key;
                      
            --
            -- Insert record.
            --
            BEGIN
              INSERT INTO hznrep_ccpm_wireless_trans
                 (hznrep_ccpm_wireless_trans_key,
                  bill_market,
                  ctn_market,
                  dealer_code,
                  product_code,
                  product_desc,
                  product_type,
                  cust_name,
                  fan_id,
                  ctn,
                  isd_ctn,
                  ban,
                  isd_ban,
                  action_type,
                  action_date,
                  mrc,
                  device_model,
                  imei,
                  customer_type,
                  contract_date,
                  contract_term,
                  contract_type,
                  manufacturer,
                  segment,
                  device_class,
                  prev_product_code,
                  prev_mrc,
                  prev_contract_term,
                  prev_contract_type,
                  addr1,
                  addr2,
                  city,
                  state,
                  zipcd,
                  tlg_daily_trans_key,
                  tlg_daily_trans_key_addr,
                  bid_prod_family_key,
                  year,
                  month,
                  day,
                  product_id,
                  src_action_type,
                  mod_user,
                  mod_date,
                  comp_revenue,
                  prev_comp_revenue,
                  isd,
                  mobile_type,
                  feature_isd,
                  dcd,
                  disconnect_key,
                  activation_key,
                  pair_key
                  )
              VALUES
                 (o_rec.hznrep_ccpm_wireless_trans_key,
                  o_rec.bill_market,
                  o_rec.ctn_market,
                  o_rec.dealer_code,
                  o_rec.product_code,
                  o_rec.product_desc,
                  o_rec.product_type,
                  o_rec.cust_name,
                  o_rec.fan_id,
                  o_rec.ctn,
                  o_rec.isd_ctn,
                  o_rec.ban,
                  o_rec.isd_ban,
                  o_rec.action_type,
                  o_rec.action_date,
                  o_rec.mrc,
                  o_rec.device_model,
                  o_rec.imei,
                  o_rec.customer_type,
                  o_rec.contract_date,
                  o_rec.contract_term,
                  o_rec.contract_type,
                  o_rec.manufacturer,
                  o_rec.segment,
                  o_rec.device_class,
                  o_rec.prev_product_code,
                  o_rec.prev_mrc,
                  o_rec.prev_contract_term,
                  o_rec.prev_contract_type,
                  o_rec.addr1,
                  o_rec.addr2,
                  o_rec.city,
                  o_rec.state,
                  o_rec.zipcd,
                  o_rec.tlg_daily_trans_key,
                  o_rec.tlg_daily_trans_key_addr,
                  o_rec.bid_prod_family_key,
                  o_rec.year,
                  o_rec.month,
                  o_rec.day,
                  o_rec.product_id,
                  o_rec.src_action_type,
                  o_rec.mod_user,
                  o_rec.mod_date,
                  o_rec.comp_revenue,
                  o_rec.prev_comp_revenue,
                  o_rec.isd,
                  o_rec.mobile_type,
                  o_rec.feature_isd,
                  o_rec.dcd,
                  o_rec.disconnect_key,
                  o_rec.activation_key,
                  o_rec.pair_key
                  );
            END;
            
            IF l_index = 1 THEN
               l_tlg_insert_ctr := l_tlg_insert_ctr + SQL%ROWCOUNT;
            ELSE
               l_ffsc_insert_ctr := l_ffsc_insert_ctr + SQL%ROWCOUNT;
            END IF;
            
            l_insert_ctr := l_insert_ctr + SQL%ROWCOUNT;
            
            IF mod(l_insert_ctr,10000) = 0 THEN
               DBMS_OUTPUT.put_line ('Committed on ' || l_insert_ctr || ' records.');
               COMMIT;
            END IF;
            
          END LOOP;
          
          IF l_index = 1 THEN
             CLOSE tlg_input_cursor;
          ELSE
             CLOSE ffsc_input_cursor;
          END IF;
          
        END;
                
      END LOOP;
      --
      -- END FOR 1..2 LOOP
      --
      
      l_rec_ctr := l_tlg_rec_ctr + l_ffsc_rec_ctr;
      
      DBMS_OUTPUT.put_line ('Deleted ' || l_delete_ctr || ' records for SP_HZNREP_CCPM_WIRELESS.');
      DBMS_OUTPUT.put_line ('Fetched ' || l_rec_ctr || ' records for SP_HZNREP_CCPM_WIRELESS.');
      DBMS_OUTPUT.put_line ('==> TLG Read ' || l_tlg_rec_ctr);
      DBMS_OUTPUT.put_line ('==> FFSC Read ' || l_ffsc_rec_ctr);
      DBMS_OUTPUT.put_line ('==> FFSC Skip ' || l_ffsc_skip_ctr);
      DBMS_OUTPUT.put_line ('Inserted ' || l_insert_ctr || ' records for SP_HZNREP_CCPM_WIRELESS.');
      DBMS_OUTPUT.put_line ('==> TLG Insert ' || l_tlg_insert_ctr);
      DBMS_OUTPUT.put_line ('==> FFSC Insert ' || l_ffsc_insert_ctr);

      COMMIT;
      
      DBMS_OUTPUT.put_line ('SP_HZNREP_CCPM_WIRELESS End on ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' ));
      
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        p_errormessage := 'WARNING!!! Processing Unsuccessful: ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' );
        DBMS_OUTPUT.put_line ('Processing tlg_daily_trans_key: ' || o_rec.tlg_daily_trans_key || ' bid_prod_family_key: ' || o_rec.bid_prod_family_key);
        DBMS_OUTPUT.put_line(p_errormessage);
        DBMS_OUTPUT.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
        RAISE_APPLICATION_ERROR( -30018, p_errormessage || ' SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM );
    END;
    
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_errormessage := 'WARNING!!! Processing Unsuccessful: ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' );
    DBMS_OUTPUT.put_line(p_errormessage);
    DBMS_OUTPUT.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
    RAISE_APPLICATION_ERROR( -30019, p_errormessage || ' SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM );
    
END SP_HZNREP_CCPM_WIRELESS;
/
