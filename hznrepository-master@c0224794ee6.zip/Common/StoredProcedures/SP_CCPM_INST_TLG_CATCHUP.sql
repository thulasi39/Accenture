CREATE OR REPLACE PROCEDURE SP_CCPM_INST_TLG_CATCHUP
(
    p_year IN integer,
    p_month IN integer,
    p_errormessage out varchar2
)
IS
BEGIN

    -- delete this month's data from the backup table in case of a rerun
    DELETE 
    FROM ccpm_enb_tlg_catchup_hist
    WHERE year = p_year
      AND month = p_month;

    DECLARE
      v_tlg_daily tlg_daily_trans%ROWTYPE;
      v_inst ccpm_enb_inst%ROWTYPE;
      v_cpc cpc_product_catlg%ROWTYPE;

      v_rec_ctr INTEGER;
      v_upd_ctr INTEGER;
      v_hist_ctr INTEGER;
      v_src_tbl CHAR(9);
      
      v_cpc_found CHAR(1);

    CURSOR in_cursor IS
      SELECT tlg_daily_trans_key,
             action_date,
             action_type,
             current_mobile,
             ban,
             cnt_seq_no,
             device_status,
             year,
             month
        FROM tlg_daily_trans t,
             apple_agents a
        WHERE t.year = p_year
          AND t.month = p_month
          AND t.p_seller_id = a.code
          AND t.contract_type = 'NEXT'
          AND t.is_accepted = 'Y'
          AND t.is_valid = 'Y'
          AND t.cnt_seq_no > 0;

    BEGIN

      v_rec_ctr := 0;
      v_upd_ctr := 0;
      v_hist_ctr := 0;

      v_src_tbl := ' ';
     
      OPEN in_cursor;

      LOOP
        FETCH in_cursor
		INTO v_tlg_daily.tlg_daily_trans_key,
             v_tlg_daily.action_date,
             v_tlg_daily.action_type,
             v_tlg_daily.current_mobile,
             v_tlg_daily.ban,
             v_tlg_daily.cnt_seq_no,
             v_tlg_daily.device_status,
             v_tlg_daily.year,
             v_tlg_daily.month;

        EXIT WHEN in_cursor%NOTFOUND;
        
        BEGIN

          v_rec_ctr := v_rec_ctr + 1;

          v_src_tbl := ' ';

          BEGIN

            SELECT ccpm_enb_inst_key,
                   nvl(ip_identifier,' '),
                   nvl(device_down_payment,0),
                   nvl(device_price,0),
                   nvl(imei,' '),
                   nvl(item_id,' ')
            INTO v_inst.ccpm_enb_inst_key,
                 v_inst.ip_identifier,
                 v_inst.device_down_payment,
                 v_inst.device_price,
                 v_inst.imei,
                 v_inst.item_id
            FROM (SELECT ccpm_enb_inst_key,
                         ip_identifier,
                         device_down_payment,
                         device_price,
                         imei,
                         item_id
                  FROM ccpm_enb_inst
                  WHERE year = v_tlg_daily.year
                    AND month = v_tlg_daily.month
                    AND ban = v_tlg_daily.ban
                    AND ctn = v_tlg_daily.current_mobile
                    AND cnt_seq_no = v_tlg_daily.cnt_seq_no
                  ORDER BY year DESC, month DESC, day DESC, inst_id DESC)
            WHERE ROWNUM = 1;

            IF SQL%FOUND THEN
               v_src_tbl := 'INST';
            END IF;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN NULL;
          END;

          IF v_src_tbl = ' ' THEN

             BEGIN

               SELECT ccpm_enb_inst_hist_key,
                      nvl(ip_identifier,' '),
                      nvl(device_down_payment,0),
                      nvl(device_price,0),
                      nvl(imei,' '),
                      nvl(item_id,' ')
               INTO v_inst.ccpm_enb_inst_key,
                    v_inst.ip_identifier,
                    v_inst.device_down_payment,
                    v_inst.device_price,
                    v_inst.imei,
                    v_inst.item_id
               FROM (SELECT ccpm_enb_inst_hist_key,
                            ip_identifier,
                            device_down_payment,
                            device_price,
                            imei,
                            item_id
                     FROM ccpm_enb_inst_hist
                     WHERE year = v_tlg_daily.year
                       AND month = v_tlg_daily.month
                       AND ban = v_tlg_daily.ban
                       AND ctn = v_tlg_daily.current_mobile
                       AND cnt_seq_no = v_tlg_daily.cnt_seq_no
                     ORDER BY year DESC, month DESC, day DESC, inst_id DESC, hist_seq DESC)
               WHERE ROWNUM = 1;

               IF SQL%FOUND THEN
                  v_src_tbl := 'INST_HIST';
               END IF;

             EXCEPTION
               WHEN NO_DATA_FOUND THEN NULL;
             END;

          END IF;

          IF v_src_tbl = 'INST' OR v_src_tbl = 'INST_HIST' THEN

             v_cpc_found := 'N';

             BEGIN

               SELECT prod_id
               INTO v_cpc.prod_id
               FROM cpc_product_catlg
               WHERE attrib_name = 'itemID'
                 AND prod_type = 'Oracle SKU'
                 AND attrib_value = v_inst.item_id
                 AND v_tlg_daily.action_date between eff_date and exp_date
                 AND rownum = 1;

               IF SQL%FOUND THEN
                  v_cpc_found := 'Y';
               END IF;

             EXCEPTION
               WHEN NO_DATA_FOUND THEN NULL;
             END;

             IF v_cpc_found = 'N' THEN

                v_cpc.prod_id := '0';

                IF v_tlg_daily.device_status IS NULL OR
                   v_tlg_daily.device_status <> 'IMEI PREVIOUSLY ACTIVATED' THEN
                   v_tlg_daily.device_status := 'IMEI NOT ELIGIBLE SMARTPHONE';
                END IF;

             END IF;

             IF v_tlg_daily.action_type = 'MVD' OR
                v_tlg_daily.action_type = 'MVC' OR
                v_tlg_daily.action_type = 'SVC' OR
                v_tlg_daily.action_type = 'BUG' OR
                v_tlg_daily.action_type = 'GCO' OR
                v_tlg_daily.action_type = 'GCI' THEN
                v_tlg_daily.device_status := NULL;
             END IF;

             BEGIN

               UPDATE tlg_daily_trans
               SET ip_identifier = v_inst.ip_identifier,
                   device_down_payment = v_inst.device_down_payment,
                   device_price = v_inst.device_price,
                   imei = v_inst.imei,
                   p_imei = v_inst.imei,
                   inst_imei = v_inst.imei,
                   item_id = v_inst.item_id,
                   device_id = v_cpc.prod_id,
                   p_device_id = v_cpc.prod_id,
                   device_status = v_tlg_daily.device_status,
                   mod_user = 'CCPM_INST_TLGCATCHUP',
                   mod_date = sysdate
               WHERE tlg_daily_trans_key = v_tlg_daily.tlg_daily_trans_key;

             EXCEPTION
               WHEN NO_DATA_FOUND THEN NULL;
             END;

             v_upd_ctr := v_upd_ctr + SQL%ROWCOUNT;

             -- save the temp table data to the backup table
             BEGIN

               INSERT INTO ccpm_enb_tlg_catchup_hist
                 (tlg_daily_trans_key,
                  ip_identifier,
                  device_down_payment,
                  device_price,
                  imei,
                  item_id,
                  device_id,
                  device_status,
                  source_table,
                  ccpm_enb_inst_key,
                  month,
                  year)
               VALUES
                 (v_tlg_daily.tlg_daily_trans_key,
                  v_inst.ip_identifier,
                  v_inst.device_down_payment,
                  v_inst.device_price,
                  v_inst.imei,
                  v_inst.item_id,
                  v_cpc.prod_id,
                  v_tlg_daily.device_status,
                  TRIM(v_src_tbl),
                  v_inst.ccpm_enb_inst_key,
                  v_tlg_daily.month,
                  v_tlg_daily.year
                 );
            
             END;

             v_hist_ctr := v_hist_ctr + SQL%ROWCOUNT;

             IF mod(v_rec_ctr,1000) = 0 THEN
                DBMS_OUTPUT.put_line ('Commit on ' || v_rec_ctr || '/'  || v_upd_ctr || '/' || v_hist_ctr || ' records read/updated/inserted.');
                COMMIT;
             END IF;

          END IF;

        END;
      
      END LOOP;

      DBMS_OUTPUT.put_line ('Fetched ' || v_rec_ctr || ' TLG_DAILY_TRANS records.');
      DBMS_OUTPUT.put_line ('Updated ' || v_upd_ctr || ' TLG_DAILY_TRANS records.');
      DBMS_OUTPUT.put_line ('Inserted ' || v_hist_ctr || ' CCPM_ENB_TLG_CATCHUP_HIST records.');

      CLOSE in_cursor;

      COMMIT;
      
    END;

END SP_CCPM_INST_TLG_CATCHUP;
/
