CREATE OR REPLACE PROCEDURE SP_CMV_LIVE_DAYS
(
	p_mobile		IN VARCHAR2,
	p_contract_id	IN NUMBER,
	p_live_days		IN OUT NUMBER
)
IS

	CURSOR ld_cur IS
		SELECT
			donor_live_days,
			recipient_live_days,
			action_type
		FROM contract_moves WHERE
			contract_id = p_contract_id
		 ORDER BY timestamp desc;

BEGIN

	dbms_output.put_line('SP_CMV_LIVE_DAYS: Compute Live Days on : ' || p_mobile || ' Start with ' || p_live_days);

	/* Process each record for contract that is being disconnected or backed out*/
	FOR ld_rec in ld_cur LOOP

		IF (ld_rec.action_type = 'CMV') THEN
			p_live_days := p_live_days - ld_rec.donor_live_days + ld_rec.recipient_live_days;
		ELSE
			p_live_days := p_live_days -ld_rec.recipient_live_days + ld_rec.donor_live_days;
		END IF;

		dbms_output.put_line('For Live Days Computation:  Contact Live Days: ' || p_live_days || ' Donor Live Days: ' || ld_rec.donor_live_days ||
			', Recipient Live Days: ' || ld_rec.recipient_live_days );

	END LOOP;

END SP_CMV_LIVE_DAYS;



/
