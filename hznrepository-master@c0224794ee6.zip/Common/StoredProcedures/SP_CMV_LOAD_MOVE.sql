CREATE OR REPLACE PROCEDURE SP_CMV_LOAD_MOVE
(
	p_donor_mobile		IN VARCHAR2, 
	p_donor_isd			IN DATE, 
	p_recipient_mobile	IN VARCHAR2, 
	p_recipient_isd		IN DATE, 
	p_is_active			OUT CHAR,
	p_contract_id		OUT NUMBER
) 
IS

	CURSOR cmv_cur IS
		SELECT contract_moves_key FROM ( SELECT contract_moves_key FROM contract_moves 
			WHERE  eff_donor_mobile =  p_recipient_mobile AND eff_donor_isd = p_recipient_isd AND is_active = 'Y' 
			ORDER BY timestamp DESC) WHERE ROWNUM = 1;

	l_is_active		CHAR;
    l_contract_id	NUMBER;

BEGIN
	dbms_output.put_line('SP_CMV_LOAD_MOVE:  Donor: ' || p_donor_mobile || ' Recipient: ' || p_recipient_mobile );

	l_is_active := 'Y';
	l_contract_id := 0;

	FOR cmv_rec IN cmv_cur LOOP

		/* If an active CMV records exists, where the effective donor is the same as the recipient of this new record, then this is a contract chain move.  Update the effective donor
		information on the existing record with the donor information from the new record.  This new record should then be inserted as inactive. */
		dbms_output.put_line('New CMV is part of a chain move.  Donor: ' || p_donor_mobile || ' Recipient: ' || p_recipient_mobile );

		l_contract_id := cmv_rec.contract_moves_key;


		UPDATE contract_moves SET eff_donor_mobile = p_donor_mobile, eff_donor_isd = p_donor_isd, mod_user = 'CMV_LOAD', mod_date = SYSDATE
			WHERE contract_moves_key = l_contract_id;

		l_is_active := 'N';

	END LOOP;

	/* A mobile can only actively be a donor to one recipient at a time.  If there exists and older active CMV record where the donor matches this new, active donor make it inactive.*/
	IF (l_is_active = 'Y') THEN
		UPDATE contract_moves SET is_active = 'N', mod_user = 'CMV_LOAD', mod_date = SYSDATE WHERE eff_donor_mobile = p_donor_mobile AND eff_donor_isd = p_donor_isd;
	END IF;

    p_is_active := l_is_active;
	p_contract_id := l_contract_id;
    
END SP_CMV_LOAD_MOVE;
/
