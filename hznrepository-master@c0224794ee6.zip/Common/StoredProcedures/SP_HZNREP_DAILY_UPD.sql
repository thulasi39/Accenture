CREATE OR REPLACE PROCEDURE SP_HZNREP_DAILY_UPD 
(
	p_year           IN     NUMBER,
	p_month          IN     NUMBER,
	p_day            IN     NUMBER,   
	p_errormessage  OUT	VARCHAR2
)
IS
   l_errmsg   VARCHAR2 (100);
   l_start_time         DATE;
   l_finish_time        DATE;
   l_minute_taken       NUMBER (8, 2);
BEGIN

    l_start_time := SYSDATE;
	
    DBMS_OUTPUT.put_line('Starting SP_HZNREP_DAILY_UPD at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('P_YEAR: ' || p_year);
    DBMS_OUTPUT.put_line('P_MONTH: ' || p_month);
    DBMS_OUTPUT.put_line('P_DAY: ' || p_day);

    DBMS_OUTPUT.put_line('==> Starting SP_DC_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_DC_TLG_UPDATE(p_month => p_month, p_day => p_day, p_year => p_year, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_DC_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_PROCESS_NCI at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_PROCESS_NCI(p_year => p_year, p_month => p_month, p_day => p_day, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_PROCESS_NCI at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_CROSSUPG at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_CROSSUPG(p_year => p_year, p_month => p_month, p_day => p_day, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_CROSSUPG at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_PRODUCT_UPG at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_PRODUCT_UPG(p_year => p_year, p_month => p_month, p_day => p_day, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_PRODUCT_UPG at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_SWEEP_TLG_SRVCHG_TRANS at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_SWEEP_TLG_SRVCHG_TRANS(p_year => p_year, p_month => p_month, p_day => p_day);
    DBMS_OUTPUT.put_line('==> Finished SP_SWEEP_TLG_SRVCHG_TRANS at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_CCPM_INST_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_CCPM_INST_TLG_UPDATE(p_month => p_month, p_day => p_day, p_year => p_year, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_CCPM_INST_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_TLG_DAILY_DEVICE_ID_UPD at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_TLG_DAILY_DEVICE_ID_UPD(p_month => p_month, p_day => p_day, p_year => p_year, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_TLG_DAILY_DEVICE_ID_UPD at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_POS_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_POS_TLG_UPDATE(p_year => p_year, p_month => p_month, p_day => p_day, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_POS_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_ERICSSON_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_ERICSSON_TLG_UPDATE(p_year => p_year, p_month => p_month, p_day => p_day, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_ERICSSON_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('==> Starting SP_ERICSSON_SNPSHOT_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
    SP_ERICSSON_SNPSHOT_TLG_UPDATE(p_year => p_year, p_month => p_month, p_errormessage => l_errmsg);
    DBMS_OUTPUT.put_line('==> Finished SP_ERICSSON_SNPSHOT_TLG_UPDATE at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    l_finish_time := SYSDATE;
    l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
    l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');

    DBMS_OUTPUT.put_line('Finished SP_HZNREP_DAILY_UPD at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));
	
    DBMS_OUTPUT.put_line('Total time taken SP_HZNREP_DAILY_UPD  =  ' || l_minute_taken || ' Minutes');
						   
END SP_HZNREP_DAILY_UPD;
/
