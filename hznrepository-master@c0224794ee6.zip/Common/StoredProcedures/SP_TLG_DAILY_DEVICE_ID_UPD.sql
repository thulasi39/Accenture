CREATE OR REPLACE PROCEDURE SP_TLG_DAILY_DEVICE_ID_UPD
(
    p_month IN integer,
    p_day IN integer,
    p_year IN integer,
    p_errormessage out varchar2
)
IS
BEGIN

    DECLARE
      v_tlg_daily tlg_daily_trans%ROWTYPE;
      v_cpc cpc_product_catlg%ROWTYPE;

      v_rec_ctr INTEGER;
      v_skip_ctr INTEGER;
      v_upd_ctr INTEGER;
      
      v_cpc_found CHAR(1);
      v_save tlg_daily_trans%ROWTYPE;
      
      CURSOR in_cursor IS
      SELECT tlg_daily_trans_key,
             item_id,
             action_type,
             action_date,
             nvl(device_id,0) device_id,
             device_status
      FROM tlg_daily_trans
      WHERE year = p_year
        AND month = p_month
        AND day = p_day
        AND item_id is not NULL
      ORDER BY item_id, action_date;

    BEGIN

      v_rec_ctr := 0;
      v_skip_ctr := 0;
      v_upd_ctr := 0;
      v_cpc_found := 'N';
      v_save.item_id := ' ';
      v_save.action_date := SYSDATE;
     
      OPEN in_cursor;

      LOOP
        FETCH in_cursor
        INTO v_tlg_daily.tlg_daily_trans_key,
             v_tlg_daily.item_id,
             v_tlg_daily.action_type,
             v_tlg_daily.action_date,
             v_tlg_daily.device_id,
             v_tlg_daily.device_status;

        EXIT WHEN in_cursor%NOTFOUND;
        
        BEGIN

          v_rec_ctr := v_rec_ctr + 1;
              
          IF v_tlg_daily.action_type = 'SVD' OR
             v_tlg_daily.action_type = 'XUP' OR
             v_tlg_daily.action_type = 'XUR' THEN
             v_skip_ctr := v_skip_ctr + 1;
          ELSIF v_tlg_daily.action_type = 'BUG' AND
             v_tlg_daily.device_id > 0 THEN
             v_skip_ctr := v_skip_ctr + 1;
          ELSE
             IF v_tlg_daily.item_id <> v_save.item_id OR
                v_tlg_daily.action_date <> v_save.action_date THEN

                BEGIN

                  SELECT nvl(prod_id,0)
                  INTO v_cpc.prod_id
                  FROM cpc_product_catlg
                  WHERE attrib_name = 'itemID'
                    AND prod_type = 'Oracle SKU'
                    AND attrib_value = v_tlg_daily.item_id
                    AND v_tlg_daily.action_date between eff_date and exp_date
                    AND rownum = 1;

                  IF SQL%FOUND THEN
                     v_cpc_found := 'Y';
                  END IF;

                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                       v_cpc_found := 'N';
                       v_cpc.prod_id := '0';
                END;

                DBMS_OUTPUT.put_line ('SELECT on R_CPC_PRODUCT_CATLG ITEM ID: ' || v_tlg_daily.item_id || ' DATE: ' || v_tlg_daily.action_date || ' DEVICE ID: ' || v_cpc.prod_id);

                v_save.item_id := v_tlg_daily.item_id;
                v_save.action_date := v_tlg_daily.action_date;

             END IF;

             IF v_cpc_found = 'N' THEN

                IF v_tlg_daily.device_status IS NULL OR
                   v_tlg_daily.device_status <> 'IMEI PREVIOUSLY ACTIVATED' THEN
                   v_tlg_daily.device_status := 'IMEI NOT ELIGIBLE SMARTPHONE';
                END IF;

             END IF;

             IF v_tlg_daily.action_type = 'MVD' OR
                v_tlg_daily.action_type = 'MVC' OR
                v_tlg_daily.action_type = 'SVC' OR
                v_tlg_daily.action_type = 'BUG' OR
                v_tlg_daily.action_type = 'GCO' OR
                v_tlg_daily.action_type = 'GCI' THEN
                v_tlg_daily.device_status := NULL;
             END IF;

             BEGIN

               UPDATE tlg_daily_trans
               SET device_id = v_cpc.prod_id,
                   p_device_id = v_cpc.prod_id,
                   s_device_id = v_cpc.prod_id,
                   device_status = v_tlg_daily.device_status,
                   s_device_status = v_tlg_daily.device_status,
                   mod_user = 'TLG_DEVICE_ID_UPD',
                   mod_date = SYSDATE
               WHERE tlg_daily_trans_key = v_tlg_daily.tlg_daily_trans_key;

             EXCEPTION
               WHEN NO_DATA_FOUND THEN NULL;
             END;

             v_upd_ctr := v_upd_ctr + SQL%ROWCOUNT;

             IF mod(v_upd_ctr,1000) = 0 THEN
                DBMS_OUTPUT.put_line ('Commit on ' || v_rec_ctr || '/' || v_skip_ctr || '/' || v_upd_ctr || ' records read/skip/update.');
                COMMIT;
             END IF;

          END IF;

        END;
      
      END LOOP;

      DBMS_OUTPUT.put_line ('Fetched ' || v_rec_ctr || ' TLG_DAILY_TRANS records for SP_TLG_DAILY_DEVICE_ID_UPD.');
      DBMS_OUTPUT.put_line ('Skipped ' || v_skip_ctr || ' TLG_DAILY_TRANS records for SP_TLG_DAILY_DEVICE_ID_UPD.');
      DBMS_OUTPUT.put_line ('Updated ' || v_upd_ctr || ' TLG_DAILY_TRANS records for SP_TLG_DAILY_DEVICE_ID_UPD.');

      CLOSE in_cursor;

      COMMIT;
      
    END;

END SP_TLG_DAILY_DEVICE_ID_UPD;
/
