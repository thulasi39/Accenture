CREATE OR REPLACE PROCEDURE SP_LOAD_NCI_BASE (
   p_year           IN     NUMBER,
   p_month          IN     NUMBER,
   p_day            IN     NUMBER,   
   p_errormessage      OUT VARCHAR2)
IS
   l_file_date   VARCHAR2 (12);
   l_day         VARCHAR2 (2);
   l_month       VARCHAR2 (2);
   l_year        VARCHAR2 (4);
   l_start_time         DATE;
   l_finish_time        DATE;
   l_minute_taken       NUMBER (8, 2);
   
BEGIN

   l_start_time := SYSDATE;

   DBMS_OUTPUT.put_line('Starting(SP_LOAD_NCI_BASE) at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));

   l_day := TO_CHAR (p_day);
   l_month := TO_CHAR (p_month);
   l_year := TO_CHAR (p_year);

   l_file_date := l_month || '/' || l_day || '/' || l_year;

   DBMS_OUTPUT.put_line ('file date: ' || l_file_date);

   -- Delete from NCI_ACTIVITY_BASE
   DELETE FROM NCI_ACTIVITY_BASE
         WHERE year = p_year AND month = p_month AND day = p_day;

   DBMS_OUTPUT.put_line (
      'Records deleted from NCI_ACTIVITY_BASE: ' || SQL%ROWCOUNT);

   COMMIT;

   --Delete Source side from NCI_ACTIVITY
   DELETE FROM NCI_ACTIVITY
         WHERE s_file_date = TO_DATE (l_file_date, 'MM/DD/YYYY');

   DBMS_OUTPUT.put_line (
      'Records deleted from NCI_ACTIVITY: ' || SQL%ROWCOUNT);

   COMMIT;

   --Update Target side from NCI_ACTIVITY
   UPDATE NCI_ACTIVITY
      SET t_bill_mkt_code = '',
          t_mobile_mkt_code = '',
          t_isd_mobile = '',
          t_isd_date = '',
          t_isd_ban = '',
          t_product_type = '',
          t_product_code = '',
          t_product_agent = '',
          t_nci_move_date = '',
          t_file_date = '',
          is_mapped = 'N',
          mod_user = 'NCIActivityLoad',
          mod_date = SYSDATE
    WHERE t_file_date = TO_DATE (l_file_date, 'MM/DD/YYYY');

   DBMS_OUTPUT.put_line ('Records updated in NCI_ACTIVITY: ' || SQL%ROWCOUNT);

   COMMIT;

   -- Insert NCI data from tld_daily_trans into nci_activity_base
   INSERT INTO nci_activity_base (nci_activity_base_key,
                                  bill_mkt_code,
                                  mobile_mkt_code,
                                  isd_mobile,
                                  isd_date,
                                  isd_ban,
                                  orig_agent,
                                  last_mobile,
                                  last_ban,
                                  fan,
                                  customer_name,
                                  sva_code,
                                  product_type,
                                  product_id,
                                  product_code,
                                  product_agent,
                                  product_isd,
                                  live_days,
                                  term,
                                  action_type,
                                  nci_move_date,
                                  is_mapped,
                                  file_date,
                                  day,
                                  month,
                                  year)
      (SELECT seq_nci_activity_base.NEXTVAL,
              bill_mkt_code,
              mobile_mkt_code,
              isd_mobile,
              sys_isd,
              isd_ban,
              prev_seller_id,
              current_mobile,
              ban,
              fan,
              custname,
              srv_area_code,
              UPPER(product_type),
              product_id,
              product_code,
              seller_id,
              product_code_isd,
              active_days,
              contract_term,
              CASE action_type
                 WHEN 'MVD' THEN 'CAN'
                 WHEN 'MVC' THEN 'NAC'
                 ELSE action_type
              END
                 AS action_type,
              action_date,
              'N' AS is_mapped,
              TO_DATE (l_file_date, 'MM/DD/YYYY'),
              day,
              month,
              year
         FROM tlg_daily_trans
        WHERE     day = p_day
              AND month = p_month
              AND year = p_year
              AND action_type IN ('MVC', 'MVD'));

   DBMS_OUTPUT.put_line (
      'Records inserted in NCI_ACTIVITY_BASE: ' || SQL%ROWCOUNT);

   COMMIT;
   l_finish_time := SYSDATE;
   l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
   l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');
	
   DBMS_OUTPUT.put_line('Finished (SP_LOAD_NCI_BASE) at: ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

   DBMS_OUTPUT.put_line ('Start time (SP_LOAD_NCI_BASE): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
   DBMS_OUTPUT.put_line ('End time (SP_LOAD_NCI_BASE): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

   DBMS_OUTPUT.put_line('Total time taken (SP_LOAD_NCI_BASE)  =  '
                           || l_minute_taken
                           || ' Minutes');	 
						   
END SP_LOAD_NCI_BASE;
/