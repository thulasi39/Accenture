#!/bin/ksh

###############################################################################
# FileName - load_hznrepos_procedures.sh
# Description - Load and compile the stored procedures in the test databases
###############################################################################

if [[ -z "${CDR_BIN}" ]];
then
  export CDR_BIN="/opt/app/users/hzndev/bin"
fi

source ${CDR_BIN}/profile_CDR_HznRepository.inc

source ${CDR_BIN}/common_CDR.inc

###############################################################################
# ReadInputParams : Read Input Parameters
###############################################################################
function ReadInputParams
{
  WriteLn "----------- ReadInputParams -----------" 
    while getopts e:h opt ; do
    case ${opt} in
        e) export RUN_ENV=`WriteLn ${OPTARG} | tr '[A-Z]' '[a-z]'`;;
        h) USAGE; exit 0 ;;
        *) WriteLn "Check Options other than e:h "
           WriteLn "OPT is ${OPT}"
           USAGE
           exit 1;
           ;;
    esac
    done

  WriteLn "----------- end ReadInputParams -----------" 
}

###############################################################################
# ValidateAndSetDbEnv : Validate DB Env passed on command line
#            Set username/password.
###############################################################################
function ValidateAndSetDbEnv
{
  WriteLn "----------- ValidateAndSetDbEnv -----------" 
  case ${RUN_ENV} in 
    dev |sys |qc |uat |prod ) 
      WriteLn "RUN_ENV is [${RUN_ENV}]"; 
      ;;
    * ) 
      WriteLn "Invalid value for the Environment [${RUN_ENV}]"; 
      USAGE
      exit 99
      ;;
  esac

  PROC_PATH=${CDR_SP}
  SPOOLFILE=${CDR_LOG}/${SCRIPT_NAME}_${HOSTNAME}_$$.log
  
  DECRYPT=${CDR_BIN}/Decrypt;
  WriteLn ${DECRYPT};

  if [[ -f ${DECRYPT} ]] && [[ -x ${DECRYPT} ]] 
  then
    COMM_DBASE=$(${DECRYPT} -e${RUN_ENV} -d);
    COMM_DBUSER=$(${DECRYPT}  -e${RUN_ENV} -u) ;
    COMM_DBPASS=$(${DECRYPT}  -e${RUN_ENV} -p)
  else
    WriteLn "*Error* ${DECRYPT} does not exist or does not have execute permisson set";
    ErrorExit ${ERROR_STATUS}
  fi
  if [[ -z ${COMM_DBASE} ]]
  then
    WriteLn "*Error* COMM_DBASE not defined! !!";
    ErrorExit ${ERROR_STATUS}
  fi
  
  if [[ -z ${COMM_DBUSER} ]]
  then
    WriteLn "*Error* COMM_DBUSER not defined! !!";
    ErrorExit ${ERROR_STATUS}
  fi
  if [[ -z ${COMM_DBPASS} ]]
  then
    WriteLn "*Error* COMM_DBPASS not defined! !!";
    ErrorExit ${ERROR_STATUS}
  fi  
  COMM_SERVER=${COMM_DBASE}

  WriteLn "Connected to Database:${COMM_DBASE} as User:${COMM_DBUSER}"

  WriteLn "----------- end ValidateAndSetDbEnv -----------" 
}

#######################################################################################
# Load_Functions : Load and compile the functions
#######################################################################################
function Load_Functions
{

  WriteLn "----------- start Load_Functions -----------" 
  WriteLn " ---------------Section to Drop Functions---------------"

  # drop and load functions
  for l_func_name in `cat $CDR_SP/load_hznrepos_functions.list`
  do
    # drop the functions
    FUNC_NAME=`echo ${l_func_name} | cut -f 1 -d . `
    WriteLn "Now dropping ${FUNC_NAME} ..." 
    result=`sqlplus -s ${COMM_DBUSER}/${COMM_DBPASS}@${COMM_SERVER} <<EOF
      spool ${SPOOLFILE} append
      
        set serveroutput on
	declare
	cnt number;
	begin
	select count(*) into cnt from user_procedures where object_name='${FUNC_NAME}' and object_type='FUNCTION';
	if cnt=1 then
	  execute immediate 'drop function ${FUNC_NAME}'; 
	else
	  dbms_output.put_line('WARNING: ${FUNC_NAME} does not exist!!');
	end if;
	end;
	/
	show error;
	set serveroutput off
EOF`

    ORAERR=$(echo ${result} | egrep "ORA\-|Warning\:");
    if ! [ -z "${ORAERR}" ]
    then
      WriteLn "***** ERROR ***** There were errors while dropping the function [${FUNC_NAME}]"
      WriteLn ${ORAERR}
    fi
    
    WriteLn ${result} 
    WriteLn "          --------------------------------------------------"  
    done
   
  # load the functions
  WriteLn " ---------------Section to Create Functions---------------"
  
  for l_func_name in `cat $CDR_SP/load_hznrepos_functions.list`
  do
    SQLFILE="@${PROC_PATH}/${l_func_name}";
    WriteLn "Now creating ${l_func_name} ..." 
    WriteLn "using ${SQLFILE} ..." 
    result=`sqlplus -s ${COMM_DBUSER}/${COMM_DBPASS}@${COMM_SERVER} <<EOF
      spool ${SPOOLFILE} append
      ${SQLFILE};
      show error;
EOF`

    ORAERR=$(echo ${result} | egrep "ORA\-|Warning\:");
    if ! [ -z "${ORAERR}" ]
    then
      WriteLn "***** ERROR ***** There were errors while creating the function [${l_func_name}]"
      WriteLn ${ORAERR}
    fi
      
    WriteLn ${result} 
    WriteLn "          --------------------------------------------------"  
  done

  WriteLn "----------- end Load_Functions -----------" 

}

#######################################################################################
# Load_Procedures : Load and compile the stored procedures
#######################################################################################
function Load_Procedures
{
  # drop and load procedures
  WriteLn "----------- start Load_Procedures -----------" 
  WriteLn " ---------------Section to Drop Procedures----------------"

  for l_proc_name in `cat $CDR_SP/load_hznrepos_procedures.list`
  do
    # drop the procedures
    PROC_NAME=`echo ${l_proc_name} | cut -f 1 -d . `
    WriteLn "Now dropping ${PROC_NAME} ..." 
    result=`sqlplus -s ${COMM_DBUSER}/${COMM_DBPASS}@${COMM_SERVER} <<EOF
      spool ${SPOOLFILE} append
     
        set serveroutput on
	declare
	cnt number;
	begin
	select count(*) into cnt from user_procedures where object_name='${PROC_NAME}' and object_type='PROCEDURE';
	if cnt=1 then
	  execute immediate 'drop procedure ${PROC_NAME}'; 
	else
	  dbms_output.put_line('WARNING: ${PROC_NAME} does not exist!!');
	end if;
	end;
	/
	show error;
	set serveroutput off
EOF`

    ORAERR=$(echo ${result} | egrep "ORA\-|Warning\:");
    if ! [ -z "${ORAERR}" ]
    then
      WriteLn "***** ERROR ***** There were errors while dropping the stored procedure [${PROC_NAME}]"
      WriteLn ${ORAERR}
    fi
    
    WriteLn ${result} 
    WriteLn "          --------------------------------------------------" 
  done
  

  # load the procedures
  WriteLn " ---------------Section to Create Procedures----------------"

  for l_proc_name in `cat $CDR_SP/load_hznrepos_procedures.list`
  do
    SQLFILE="@${PROC_PATH}/${l_proc_name}";
    WriteLn "Now creating ${l_proc_name} ..." 
    WriteLn "using ${SQLFILE} ..." 
    result=`sqlplus -s ${COMM_DBUSER}/${COMM_DBPASS}@${COMM_SERVER} <<EOF
      spool ${SPOOLFILE} append
      ${SQLFILE};
      show error;
EOF`

    ORAERR=$(echo ${result} | egrep "ORA\-|Warning\:");
    if ! [ -z "${ORAERR}" ]
    then
      WriteLn "***** ERROR ***** There were errors while creating the stored procedure [${l_proc_name}]"
      WriteLn ${ORAERR}
    fi
      
    WriteLn ${result}     
    WriteLn "          --------------------------------------------------"  

  done

  WriteLn "----------- end Load_Procedures -----------" 
}

###############################################################################
# USAGE : Display usage for the shell script.
###############################################################################
function USAGE
{
  WriteLn "-------------------------------------Usage----------------------------------";
  WriteLn "The usage of ${BASE_SCRIPT_NAME} is: " ;
  WriteLn "${BASE_SCRIPT_NAME} [Options]"
  typeset tabs="\t" ;
  WriteLn "${tabs}Options:" ;
  tabs="\t\t";
  WriteLn "${tabs}-e<environment>   [dev|sys|qc|uat|prod] ";  
  WriteLn "${tabs}-h                Show USAGE ";  

  exit 97;
} #end USAGE

###############################################################################
# Main code
###############################################################################

InitEnv;

if [ -z "$*" ]
then
  USAGE;
  exit 0;
fi

ReadInputParams ${ALLARGS};
ValidateAndSetDbEnv;
Load_Functions;
Load_Procedures;
WriteLn "Loading functions and stored procedures completed - log file: ${CDR_LOG_FILE}"
WriteLn
WriteLn

exit 0
