CREATE OR REPLACE PROCEDURE SP_UPDATE_DAILY_TRANS_FOR_NCI (
   p_year           IN     NUMBER,
   p_month          IN     NUMBER,
   p_day            IN     NUMBER,   
   p_errormessage      OUT VARCHAR2)
IS
BEGIN
   DECLARE
      P_RESULTSET          SYS_REFCURSOR;
      l_start_time         DATE;
      l_finish_time        DATE;
      l_minute_taken       NUMBER (8, 2);
      l_update_counter     INTEGER;

      TYPE nci_activity_record IS RECORD (
      nci_activity_key   INTEGER,
      isd_mobile         VARCHAR2 (10),
      isd_date           DATE,
      isd_ban            VARCHAR2 (30),
      live_days          INTEGER,
      prod_sys_isd       DATE,
      app_err_msg        VARCHAR2 (32)
   );

      nci_history_rec      nci_activity_record;

      CURSOR tlg_daily_trans_cur
      IS
         SELECT tlg_daily_trans_key,
                isd_mobile,
                isd_ban,
                sys_isd,
                UPPER(product_type) product_type,
                product_code,
                product_code_isd,
                active_days,
				action_type
           FROM tlg_daily_trans
          WHERE year = p_year AND month = p_month AND day = p_day
                AND (BILL_MKT_CODE = 'NBI'
                     OR SYS_ISD > TO_DATE ('01/01/2013', 'mm/dd/yyyy'))
                AND action_type IN ('CAN', 'P2X', 'C16', 'C17', 'BUG', 'SVC', 'SVD', 'MVC', 'MVD', 'GCI', 'GCO')
         FOR UPDATE OF
            p_isd_mobile, p_mobile_isd, p_product_code_isd, p_active_days;

      l_nci_activity_key   INTEGER;
      l_isd_mobile         VARCHAR2 (10);
      l_isd_date           DATE;
      l_live_days          INTEGER;
      l_prod_sys_isd       DATE;
      l_app_err_msg        VARCHAR2 (32);
   BEGIN
      l_start_time := SYSDATE;
      l_update_counter := 0;

      DBMS_OUTPUT.put_line('Starting(SP_UPDATE_DAILY_TRANS_FOR_NCI) at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));

	  
      FOR tlg_daily_trans_rec IN tlg_daily_trans_cur
      LOOP
         l_nci_activity_key := NULL;
         l_isd_mobile := NULL;
         l_isd_date := NULL;
         l_live_days := NULL;
         l_prod_sys_isd := NULL;
         l_app_err_msg := NULL;

         IF ((tlg_daily_trans_rec.action_type = 'C17') OR 
				(tlg_daily_trans_rec.action_type = 'CAN' AND tlg_daily_trans_rec.product_type = 'GENERIC FEATURE'))
         THEN
            SP_GET_PRE_NCI_UPGB_HISTORY (
               p_mobile      	=> tlg_daily_trans_rec.isd_mobile,
               p_ban         	=> tlg_daily_trans_rec.isd_ban,
               p_isd_date    	=> tlg_daily_trans_rec.sys_isd,
               p_upgtsoc     	=> tlg_daily_trans_rec.product_code,
			   p_upgt_isd_Date 	=> tlg_daily_trans_rec.product_code_isd,
               p_resultset   	=> P_RESULTSET);
         ELSE
            SP_GET_PRE_NCI_HISTORY (
               p_mobile      	=> tlg_daily_trans_rec.isd_mobile,
               p_ban        	=> tlg_daily_trans_rec.isd_ban,
               p_isd_date    	=> tlg_daily_trans_rec.sys_isd,
               p_resultset   	=> P_RESULTSET);
         END IF;

         FETCH P_RESULTSET INTO nci_history_rec;

         l_nci_activity_key := nci_history_rec.nci_activity_key;

         IF (l_nci_activity_key = 0 OR l_nci_activity_key IS NULL)
         THEN
            DBMS_OUTPUT.put_line ('Not able to find NCI history');
         ELSE
            DBMS_OUTPUT.put_line('Found NCI History : nci_activity_key =  '
                                 || l_nci_activity_key);

            IF ((tlg_daily_trans_rec.action_type = 'C17') OR 
				(tlg_daily_trans_rec.action_type = 'CAN' AND tlg_daily_trans_rec.product_type = 'GENERIC FEATURE'))
            THEN
               -- set p_mobile_isd, p_isd_mobile, p_product_code_isd, p_active_days
               l_isd_mobile := nci_history_rec.isd_mobile;
               l_isd_date := nci_history_rec.isd_date;
               l_live_days :=
                  nci_history_rec.live_days + tlg_daily_trans_rec.active_days;
               l_prod_sys_isd := NVL(nci_history_rec.prod_sys_isd, tlg_daily_trans_rec.product_code_isd);
            ELSE
               IF (tlg_daily_trans_rec.action_type = 'C16')
               THEN
                  -- set p_mobile_isd, p_isd_mobile
                  l_isd_mobile := nci_history_rec.isd_mobile;
                  l_isd_date := nci_history_rec.isd_date;
                  l_live_days := tlg_daily_trans_rec.active_days;
                  l_prod_sys_isd := tlg_daily_trans_rec.product_code_isd;
			   ELSE 
			      IF (tlg_daily_trans_rec.action_type = 'BUG')
			      THEN
			         -- set p_mobile_isd, p_isd_mobile, p_product_code_isd, p_active_days
				     -- For BUG, product_code_isd will be same as mobile_isd
				     l_isd_mobile := nci_history_rec.isd_mobile;
                     l_isd_date := nci_history_rec.isd_date;
                     l_live_days :=
						nci_history_rec.live_days + tlg_daily_trans_rec.active_days;
                     l_prod_sys_isd := nci_history_rec.isd_date;
				  ELSE -- action_type other than C16/C17/BUG
                     -- set p_mobile_isd, p_isd_mobile, p_active_days
                     l_isd_mobile := nci_history_rec.isd_mobile;
                     l_isd_date := nci_history_rec.isd_date;
                     l_live_days :=
						nci_history_rec.live_days + tlg_daily_trans_rec.active_days;
                     l_prod_sys_isd := tlg_daily_trans_rec.product_code_isd;
				  END IF;
               END IF;
            END IF;

            -- update tlg_daily_trans
            UPDATE tlg_daily_trans
               SET p_isd_mobile = l_isd_mobile,
                   p_mobile_isd = l_isd_date,
                   p_active_days = l_live_days,
                   p_product_code_isd = l_prod_sys_isd,
				   mod_user = 'NCIProcess',
				   mod_date = SYSDATE
             WHERE CURRENT OF tlg_daily_trans_cur;

            l_update_counter := l_update_counter + 1;
         END IF;
      END LOOP;

      COMMIT;
	  
      DBMS_OUTPUT.put_line ('Transactions updated  =  ' || l_update_counter);
		 
      l_finish_time := SYSDATE;
      l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
      l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');
	  
      DBMS_OUTPUT.put_line ('Finished (SP_UPDATE_DAILY_TRANS_FOR_NCI ) at: ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));
	  
	  DBMS_OUTPUT.put_line ('Start time (SP_UPDATE_DAILY_TRANS_FOR_NCI ): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
      DBMS_OUTPUT.put_line ('End time (SP_UPDATE_DAILY_TRANS_FOR_NCI ): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

      DBMS_OUTPUT.put_line('Total time taken (SP_UPDATE_DAILY_TRANS_FOR_NCI)  =  '
                           || l_minute_taken
                           || ' Minutes');

   END;
   
END SP_UPDATE_DAILY_TRANS_FOR_NCI;
/
