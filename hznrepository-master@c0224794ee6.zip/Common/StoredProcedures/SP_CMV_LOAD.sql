CREATE OR REPLACE PROCEDURE SP_CMV_LOAD
(
	p_year	IN INTEGER,
	p_month	IN INTEGER,
	p_day	IN INTEGER
)
IS
	R_RESULTSET SYS_REFCURSOR;

	TYPE nci_cmv_record IS RECORD (
		donor_mobile			VARCHAR2 (10),
		donor_isd				DATE,
		donor_ban				VARCHAR2(30),
		donor_live_days			INTEGER,
		recipient_mobile		VARCHAR2(10),
		recipient_isd			DATE,
		recipient_ban			VARCHAR2(30),
		recipient_live_days		INTEGER,
		recipient_prod_sys_isd	DATE,
		app_err_msg				VARCHAR2 (32)
	);
	nci_cmv_rec nci_cmv_record;

	/* get new CMV  and CMR records for the given day */
	CURSOR cmv_cur is
		SELECT
            bill_mkt_code as bill_mkt_code,
            current_mobile as donor_mobile,
            product_id as recipient_product_id,
            product_code as recipient_product_code,
            custname as recipient_custname,
            action_type,
            action_date,
            isd_mobile as recipient_mobile,
            sys_isd as recipient_isd,
            sys_rcd as donor_isd,
            seller_id as recipient_seller_id,
            product_code_isd as recipient_product_code_isd,
            active_days as recipient_live_days,
            prev_product_id as donor_product_id,
            ban as recipient_current_ban,
            product_type as recipient_product_type,
            isd_ban as recipient_isd_ban,
            assoc_ban as donor_isd_ban,
            contract_type,
            df_indicator,
            donor_live_days,
            timestamp
		FROM tlg_daily_trans
		WHERE month = p_month AND day = p_day AND year = p_year AND action_type in ('CMV', 'CMR') and is_valid = 'Y' ORDER BY TIMESTAMP asc;

	l_is_active				CHAR;
	l_contract_moves_key	NUMBER;
	l_contract_id			NUMBER;

 BEGIN

	dbms_output.put_line('SP_CMV_LOAD: Process,  month: ' || p_month || ' day:  ' ||   p_day || ' year:  ' ||   p_year);

	/* Process each new CMV record from tlg_daily_trans */
	FOR cmv_rec IN cmv_cur LOOP

		l_contract_id := 0;

		dbms_output.put_line('Update Donor and Recipient info in CMV record using NCI lookup ' || cmv_rec.donor_isd);

		/* get the NCI updated information for the Donor and the Recipient at the time of the CMV or CMR event */
		SP_CMV_NCI(p_donor_mobile => cmv_rec.donor_mobile, p_donor_ban => cmv_rec.donor_isd_ban , p_donor_isd => cmv_rec.donor_isd, p_recipient_mobile => cmv_rec.recipient_mobile, 
			p_recipient_ban => cmv_rec.recipient_isd_ban, p_recipient_isd => cmv_rec.recipient_isd, p_recipient_prod_code => cmv_rec.recipient_product_code, 
			p_recipient_product_type => cmv_rec.recipient_product_type, p_recipient_prod_sys_isd => cmv_rec.recipient_product_code_isd, p_resultset => R_RESULTSET);
		FETCH R_RESULTSET INTO nci_cmv_rec;

		cmv_rec.donor_mobile := nci_cmv_rec.donor_mobile;
		cmv_rec.donor_isd := nci_cmv_rec.donor_isd;
		cmv_rec.donor_isd_ban := nci_cmv_rec.donor_ban;
		cmv_rec.donor_live_days := cmv_rec.donor_live_days + nci_cmv_rec.donor_live_days;
		cmv_rec.recipient_mobile := nci_cmv_rec.recipient_mobile;
		cmv_rec.recipient_isd := nci_cmv_rec.recipient_isd;
		cmv_rec.recipient_isd_ban := nci_cmv_rec.recipient_ban;
		cmv_rec.recipient_live_days := cmv_rec.recipient_live_days + nci_cmv_rec.recipient_live_days;
		cmv_rec.recipient_product_code_isd := nci_cmv_rec.recipient_prod_sys_isd;

		/* Update contract_moves table for a chain move for the contract. */
		IF (cmv_rec.action_type = 'CMV') THEN
			SP_CMV_LOAD_MOVE(p_donor_mobile => cmv_rec.donor_mobile, p_donor_isd => cmv_rec.donor_isd, p_recipient_mobile => cmv_rec.recipient_mobile, p_recipient_isd =>cmv_rec.recipient_isd, 
				p_is_active => l_is_active, p_contract_id => l_contract_id);

		END IF;

		/* Reverse the CMV record in the contract_moves table and handle reversal of chain moves */
		IF (cmv_rec.action_type = 'CMR') THEN
			SP_CMV_LOAD_REVERSAL(p_donor_mobile => cmv_rec.donor_mobile, p_donor_isd => cmv_rec.donor_isd, p_recipient_mobile => cmv_rec.recipient_mobile, 
				p_recipient_isd => cmv_rec.recipient_isd, p_action_date => cmv_rec.action_date,
				p_product_code_isd => cmv_rec.recipient_product_code_isd, p_is_active => l_is_active, p_contract_id => l_contract_id);

		END IF;

        /* insert the new record */
		SELECT seq_contract_moves.nextval INTO l_contract_moves_key FROM dual;

        INSERT INTO contract_moves
                (CONTRACT_MOVES_KEY, MONTH, DAY, YEAR, BILL_MKT_CODE, ACTION_TYPE,  ACTION_DATE, DONOR_MOBILE, DONOR_ISD, DONOR_PRODUCT_ID,
                    DONOR_LIVE_DAYS, DONOR_ISD_BAN, EFF_DONOR_MOBILE, EFF_DONOR_ISD, RECIPIENT_MOBILE, RECIPIENT_ISD,  RECIPIENT_SELLER_ID,
                    RECIPIENT_PRODUCT_ID,  RECIPIENT_PRODUCT_CODE, RECIPIENT_PRODUCT_TYPE, RECIPIENT_PRODUCT_CODE_ISD,  RECIPIENT_LIVE_DAYS, RECIPIENT_CURRENT_BAN,
                    RECIPIENT_ISD_BAN,  RECIPIENT_CUSTNAME, RECIPIENT_DF_INDICATOR,  RECIPIENT_CONTRACT_TYPE, REVERSAL_DATE, IS_ACTIVE,
                    TIMESTAMP, MOD_USER, MOD_DATE, CONTRACT_ID)
            VALUES
                (l_contract_moves_key, p_month, p_day, p_year,
                    cmv_rec.bill_mkt_code,
                    cmv_rec.action_type,
                    cmv_rec.action_date,
                    cmv_rec.donor_mobile,
                    cmv_rec.donor_isd,
                    cmv_rec.donor_product_id,
                    cmv_rec.donor_live_days,
                    cmv_rec.donor_isd_ban,
                    cmv_rec.donor_mobile,
                    cmv_rec.donor_isd,
                    cmv_rec.recipient_mobile,
                    cmv_rec.recipient_isd,
                    cmv_rec.recipient_seller_id,
                    cmv_rec.recipient_product_id,
                    cmv_rec.recipient_product_code,
                    cmv_rec.recipient_product_type,
                    cmv_rec.recipient_product_code_isd,
                    cmv_rec.recipient_live_days,
                    cmv_rec.recipient_current_ban,
                    cmv_rec.recipient_isd_ban,
                    cmv_rec. recipient_custname,
                    cmv_rec.df_indicator,
                    cmv_rec.contract_type,
                    NULL,
                    l_is_active,
                    cmv_rec.timestamp,
                    'CROSSUPG',
                    SYSDATE,
					CASE WHEN l_contract_id = 0 THEN l_contract_moves_key ELSE l_contract_id END);

	END LOOP;

END
SP_CMV_LOAD;
/
