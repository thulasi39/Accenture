CREATE OR REPLACE PROCEDURE SP_PRODUCT_UPG 
(
	p_year			IN INTEGER,
	p_month			IN INTEGER,
	p_day			IN INTEGER,
	p_errormessage	OUT VARCHAR2 
)
IS
	l_start_time	DATE;
	l_finish_time	DATE;
	l_minute_taken	NUMBER (8, 2);
	updatedCount  NUMBER;      
BEGIN

	l_start_time := SYSDATE;

	dbms_output.put_line('SP_PRODUCT_UPG: Updating Product Info (product family/name/cat name/subcat name,cat id/subcat id) for CAN/C17 Cross UPG records for  month: ' || p_month || ' day:  ' ||   p_day || ' year:  ' ||   p_year);

	update tlg_daily_trans t  set 
	product_code= (select attrib_value from cpc_product_catlg where prod_id=t.p_product_id and upper(attrib_name)='PRODUCTCODE'
	and t.action_date>=eff_date and t.action_date<=exp_date),
	product_cat_id= (select rtrim(attrib_value) from cpc_product_catlg where prod_id=t.p_product_id and upper(attrib_name)='COMMISSIONCATEGORYID'
	and t.action_date>=eff_date and t.action_date<=exp_date),
	product_cat_name = (select substr(attrib_value,1,50) from cpc_product_catlg where prod_id=t.p_product_id and upper(attrib_name)='COMMISSIONCATEGORYNAME'
	and t.action_date>=eff_date and t.action_date<=exp_date),
	product_subcat_id= (select  rtrim(attrib_value) from cpc_product_catlg where prod_id=t.p_product_id and upper(attrib_name)='COMMISSIONSUBCATEGORYID'
	and t.action_date>=eff_date and t.action_date<=exp_date),
	product_subcat_name= (select substr(attrib_value,1,50) from cpc_product_catlg where prod_id=t.p_product_id and upper(attrib_name)='COMMISSIONSUBCATEGORYNAME'
	and t.action_date>=eff_date and t.action_date<=exp_date),
	product_name= (select substr(attrib_value,1,50) from cpc_product_catlg where prod_id=t.p_product_id and upper(attrib_name)='DESCRIPTION'
	and t.action_date>=eff_date and t.action_date<=exp_date),
	product_family= (select attrib_value from cpc_product_catlg where prod_id=t.p_product_id and upper(attrib_name)='PRODUCTFAMILY'
	and t.action_date>=eff_date and t.action_date<=exp_date),
	Mod_user='CUPG_RETAIL', mod_date=sysdate
	where month=p_month and year=p_year and day=p_day
	and event_reason='CUPG'  and is_valid='Y' and is_accepted='Y'
	and (action_type='CAN' or action_type='C17') and p_product_id!=product_id;

	updatedCount := sql%rowcount;


	COMMIT; 

	l_finish_time := sysdate;

	dbms_output.put_line('SP_PRODUCT_UPG: '|| updatedCount || ' Cross UPGT trans updated with product info for month: '|| p_month ||  ' day: ' || p_day || ' year: ' || p_year);
	l_minute_taken :=  (l_finish_time - l_start_time) *24*60 ;
	l_minute_taken :=  to_number(l_minute_taken , '9999.99') ;
	dbms_output.put_line('SP_PRODUCT_UPG: Total time taken  =  '|| l_minute_taken ||' Minutes' );

END SP_PRODUCT_UPG;
/
