CREATE OR REPLACE PROCEDURE SP_CMV_UPGT_ADD
(
    p_tran in out tlg_daily_trans%rowtype
)
IS
l_donor_rec contract_moves%rowtype;
BEGIN
    dbms_output.put_line('Starting SP_CMV_UPGT_ADD: ');
    dbms_output.put_line('Mobile [' || p_tran.p_isd_mobile || '] Mobile isd [' ||  p_tran.p_mobile_isd || '] tlg_daily_trans_key = [' || p_tran.tlg_daily_trans_key || '] ');
    
    /* If the mobile is a recipient in a CMV event, find the corresponding donor mobile. */
    BEGIN
        SELECT * INTO l_donor_rec FROM (
        SELECT * FROM  contract_moves cm 
        WHERE cm.recipient_mobile = p_tran.p_isd_mobile AND cm.recipient_isd = p_tran.p_mobile_isd and cm.action_type = 'CMV'
        AND cm.reversal_date is null
        AND  TRUNC(cm.action_date , 'DDD') = TRUNC(p_tran.p_product_code_isd , 'DDD') 
        --AND p_timestamp >= timestamp ( not sure if we need this, commented for now)
        ORDER BY TIMESTAMP DESC)
		WHERE ROWNUM = 1;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('Mobile [' || p_tran.p_isd_mobile || '] Mobile isd [' ||  p_tran.p_mobile_isd || '] is not an active recipient.' );
        WHEN OTHERS THEN
            NULL;
    END;
    
    /* If this is a Cross Upgrade UPGT, update the info field of the donor mobile */
    IF (p_tran.event_reason = 'CUPG') THEN
            dbms_output.put_line('CUPG UPGT Add for Recipeint mobile: ' || p_tran.p_isd_mobile || ' has a Donor of. ' || l_donor_rec.donor_mobile );
            UPDATE tlg_daily_trans SET p_info = l_donor_rec.donor_mobile , mod_user = 'CMV_UPGT_ADD', mod_date = SYSDATE 
            WHERE tlg_daily_trans_key = p_tran.tlg_daily_trans_key AND l_donor_rec.donor_mobile IS NOT NULL;

    /* if this is a regular UPGT, check to see if this mobile is an active Donor.  If so, make the contract_moves record inactive */
    ELSE
        UPDATE contract_moves 
        set is_active = 'N', mod_user = 'CMV_UPGT_ADD', mod_date = SYSDATE 
        WHERE eff_donor_mobile = p_tran.p_isd_mobile and donor_isd = p_tran.p_mobile_isd and is_active = 'Y';
    END IF;

END SP_CMV_UPGT_ADD;
/