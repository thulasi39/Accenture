CREATE OR REPLACE PROCEDURE SP_DC_TLG_UPDATE
(
    p_month IN integer,
    p_day IN integer,
    p_year IN integer,
    p_errormessage out varchar2
)
IS
BEGIN

    DECLARE
      v_tlg_daily tlg_daily_trans%ROWTYPE;
      v_dlr_code_changes tlg_dealer_code_changes%ROWTYPE;
      v_tlg_daily_cnt INTEGER;

    CURSOR cur_dc_tlg_daily IS
      SELECT a.tlg_daily_trans_key, b.tlg_dealer_code_changes_key, a.seller_id, a.isd_mobile,
             b.rate_plan, b.old_seller_id, b.new_seller_id
      FROM tlg_daily_trans a, tlg_dealer_code_changes b
      WHERE a.bill_mkt_code = b.bill_mkt_code
        AND a.isd_mobile = b.isd_mobile
        AND a.ban = to_number(b.account_number)
        AND a.product_code = b.product_code
        AND a.seller_id = b.old_seller_id
        AND b.old_seller_id != b.new_seller_id
        AND a.action_date = b.action_date
        AND a.month = p_month AND a.year = p_year
        AND a.month = b.month AND a.year = b.year AND b.day = p_day;

    BEGIN
      v_tlg_daily_cnt := 0;
      -- Loop through temporary DT DC true up table and update the DT base and repository tables
      OPEN cur_dc_tlg_daily;
      LOOP
        FETCH cur_dc_tlg_daily
        INTO v_tlg_daily.tlg_daily_trans_key,
             v_dlr_code_changes.tlg_dealer_code_changes_key,
             v_tlg_daily.seller_id,
             v_tlg_daily.isd_mobile,
             v_dlr_code_changes.rate_plan,
             v_dlr_code_changes.old_seller_id,
             v_dlr_code_changes.new_seller_id;
        EXIT WHEN cur_dc_tlg_daily%NOTFOUND;
        
        BEGIN
          BEGIN
            UPDATE tlg_daily_trans
            SET seller_id = v_dlr_code_changes.new_seller_id,
                p_seller_id = v_dlr_code_changes.new_seller_id,
                mod_date = sysdate,
                mod_user = 'Daily DC Update '
            WHERE month = p_month AND year = p_year AND tlg_daily_trans_key = v_tlg_daily.tlg_daily_trans_key;

            v_tlg_daily_cnt := v_tlg_daily_cnt + SQL%ROWCOUNT;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN NULL;
          END;
        END;

        -- save the temp table data to the backup table
        BEGIN
          INSERT INTO dc_tlg_daily_hist
            (tlg_daily_trans_key,
             tlg_dealer_code_changes_key,
             seller_id,
             isd_mobile,
             rate_plan,
             old_seller_id,
             new_seller_id,
             month,
             day,
             year)
          VALUES
            (v_tlg_daily.tlg_daily_trans_key,
             v_dlr_code_changes.tlg_dealer_code_changes_key,
             v_tlg_daily.seller_id,
             v_tlg_daily.isd_mobile,
             v_dlr_code_changes.rate_plan,
             v_dlr_code_changes.old_seller_id,
             v_dlr_code_changes.new_seller_id,
             p_month,
             p_day,
             p_year
            );
            
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;
      
      END LOOP;
      DBMS_OUTPUT.put_line ('Updated ' || v_tlg_daily_cnt || ' TLG_DAILY_TRANS records for SP_DC_TLG_UPDATE.');
      CLOSE cur_dc_tlg_daily;
      COMMIT;

      -- save the temp table data to the backup table
      BEGIN
        COMMIT;
      END;
      
    END;

END SP_DC_TLG_UPDATE;
/
