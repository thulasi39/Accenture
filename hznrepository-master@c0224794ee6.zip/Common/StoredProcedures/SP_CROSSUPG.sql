CREATE OR REPLACE PROCEDURE SP_CROSSUPG 
(
	p_year			IN INTEGER,
	p_month			IN INTEGER,
	p_day			IN INTEGER,
	p_errormessage	OUT VARCHAR2 
)
IS
	l_start_time	DATE;
	l_finish_time	DATE;
	l_minute_taken	NUMBER (8, 2);
      
BEGIN

	l_start_time := SYSDATE;

	dbms_output.put_line('SP_CROSSUPG: Deleting existing CMV records for  month: ' || p_month || ' day:  ' ||   p_day || ' year:  ' ||   p_year);

	/* delete CNV and CMR event for the given day */
	SP_CMV_DELETE(p_year => p_year, p_month => p_month, p_day => p_day);

	dbms_output.put_line('SP_CROSSUPG: Load new CMV records for  month: ' || p_month || ' day:  ' ||   p_day || ' year:  ' ||   p_year);

	/* Load new CMV and CMR events from tlg_daily_trans into the contract_moves table */
	SP_CMV_LOAD(p_year => p_year, p_month => p_month, p_day => p_day);

	dbms_output.put_line('SP_CROSSUPG: Process daily transactions using Cross Upgrade information: ' || p_month || ' day:  ' ||   p_day || ' year:  ' ||   p_year);

	/* Update the tlg_daily_trans with Cross Upgrade information for the given day. */
	SP_CMV_UPDATE_TRANS(p_year => p_year, p_month => p_month, p_day => p_day);

	COMMIT; 

	l_finish_time := sysdate;

	dbms_output.put_line('SP_CROSSUPG: processing completed for month: '|| p_month ||  ' day: ' || p_day || ' year: ' || p_year);
	l_minute_taken :=  (l_finish_time - l_start_time) *24*60 ;
	l_minute_taken :=  to_number(l_minute_taken , '9999.99') ;
	dbms_output.put_line('SP_CROSSUPG: Total time taken  =  '|| l_minute_taken ||' Minutes' );

END SP_CROSSUPG;
/
