CREATE OR REPLACE PROCEDURE SP_CMV_PRODUCT
(
    p_tran in out tlg_daily_trans%rowtype
)
IS
	cpc_rec cpc_product_catlg%rowtype;
	l_attrib_name VARCHAR2(50);
	CURSOR cpc_cur IS SELECT *   FROM cpc_product_catlg
	WHERE prod_id = p_tran.p_product_id
	and upper(attrib_name) in ('COMMISSIONCATEGORYID' , 'COMMISSIONCATEGORYNAME' , 'COMMISSIONSUBCATEGORYID' , 'COMMISSIONSUBCATEGORYNAME'  , 
	'PRODUCTCODE' ,'PRODUCTFAMILY','DESCRIPTION' ,'PRODUCTTYPE' ,'COMPREVENUE' ,'REVENUETYPE' , 'SECONDARYCOMPREVENUE' )
	AND p_tran.action_date between eff_date AND exp_date    ;
			 
BEGIN
	p_tran.product_id := p_tran.p_product_id;
    FOR cpc_rec in cpc_cur LOOP
        l_attrib_name := upper(cpc_rec.attrib_name);
        if(l_attrib_name = 'PRODUCTCODE' ) then
            p_tran.product_code := cpc_rec.attrib_value;
        ELSIF (l_attrib_name = 'COMMISSIONCATEGORYID' ) then
            p_tran.product_cat_id :=  trim(cpc_rec.attrib_value) ;
        ELSIF (l_attrib_name = 'COMMISSIONCATEGORYNAME' ) then
            p_tran.product_cat_name :=  trim(substr(cpc_rec.attrib_value,1,50)) ;
        ELSIF (l_attrib_name = 'COMMISSIONSUBCATEGORYID' ) then
            p_tran.product_subcat_id :=trim(cpc_rec.attrib_value) ;
        ELSIF (l_attrib_name = 'COMMISSIONSUBCATEGORYNAME' ) then
            p_tran.product_subcat_name := trim(substr(cpc_rec.attrib_value,1,50)) ;
        ELSIF (l_attrib_name = 'PRODUCTFAMILY' ) then
            p_tran.product_family := cpc_rec.attrib_value;
        ELSIF (l_attrib_name = 'DESCRIPTION' ) then
            p_tran.PRODUCT_NAME := trim(substr(cpc_rec.attrib_value,1,50)) ;
        ELSIF (l_attrib_name = 'PRODUCTTYPE' ) then
            p_tran.PRODUCT_TYPE := trim(substr(cpc_rec.attrib_value,1,50)) ;
        ELSIF (l_attrib_name = 'COMPREVENUE' ) then
            p_tran.COMP_REVENUE := cpc_rec.attrib_value ;
			
		ELSE
             NULL; 
        END IF  ;
    END LOOP;
END SP_CMV_PRODUCT;
/
