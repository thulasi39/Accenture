CREATE OR REPLACE PROCEDURE SP_SWEEP_TLG_SRVCHG_TRANS (
   p_year           IN     NUMBER,
   p_month          IN     NUMBER,
   p_day            IN     NUMBER)   
IS
   l_start_time         DATE;
   l_finish_time        DATE;
   l_minute_taken       NUMBER (8, 2);
   
BEGIN

   l_start_time := SYSDATE;

   DBMS_OUTPUT.put_line('Starting(SP_SWEEP_TLG_SRVCHG_TRANS) at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));

	UPDATE tlg_daily_trans 
	SET is_accepted ='N', mod_date = sysdate, mod_user = 'SRVCHG_SWEEP'
	WHERE tlg_daily_trans_key IN (
					SELECT rp2.tlg_daily_trans_key
					FROM tlg_daily_trans rp1, tlg_daily_trans rp2 
					WHERE rp1.month = p_month AND rp1.year = p_year AND rp1.day = p_day
					AND rp1.action_type = 'C16'
					AND rp2.month = rp1.month AND rp2.year = rp1.year AND rp2.day = rp1.day
					AND rp2.p_isd_mobile = rp1.p_isd_mobile AND rp2.p_mobile_isd = rp1.p_mobile_isd
					AND rp2.action_type IN ('SVC', 'SVD', 'GCI', 'GCO') 
					AND rp2.action_date = rp1.action_date AND rp1.p_seller_id = rp2.p_seller_id
					AND rp2.timestamp <= rp1.timestamp 
								);

   DBMS_OUTPUT.put_line (
      'Records updated in TLG_DAILY_TRANS for SP_SWEEP_TLG_SRVCHG_TRANS: ' || SQL%ROWCOUNT);

   COMMIT;
   
   l_finish_time := SYSDATE;
   l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
   l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');
	
   DBMS_OUTPUT.put_line('Finished (SP_SWEEP_TLG_SRVCHG_TRANS) at: ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

   DBMS_OUTPUT.put_line ('Start time (SP_SWEEP_TLG_SRVCHG_TRANS): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
   DBMS_OUTPUT.put_line ('End time (SP_SWEEP_TLG_SRVCHG_TRANS): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

   DBMS_OUTPUT.put_line('Total time taken (SP_SWEEP_TLG_SRVCHG_TRANS)  =  '
                           || l_minute_taken
                           || ' Minutes');	 
						   
END SP_SWEEP_TLG_SRVCHG_TRANS;
/
