CREATE OR REPLACE PROCEDURE SP_CMV_RECIPIENT_DISC
(
    p_tran in out tlg_daily_trans%rowtype
)
IS
    l_recipient_found integer;
    l_update boolean;
    cmv_rec contract_moves%rowtype;
BEGIN
    dbms_output.put_line('Entering SP_CMV_RECIPIENT_DISC: ' );
    /*
    1. Shared upgrade is the new name for cross upgrade.
    2. This stored procedure is called only for CAN transactions.
    3. it could be a rate plan disconnect or upgrade disconnect.
    4. if this is recipient rate plan disconnect, we unaccept the transaction. The contract responsibility lies with the donor.
    5. if this is CAN transaction for upgrade(generic feature), we leave it alone.    
    */
    l_update := false;    
    IF( UPPER(p_tran.product_type) = 'GENERIC FEATURE') THEN
        return;    
    END IF;
    
    
    SELECT COUNT(*) INTO l_recipient_found 
    FROM contract_moves WHERE recipient_mobile = p_tran.p_isd_mobile and recipient_isd = p_tran.p_mobile_isd 
    AND action_type = 'CMV' AND reversal_date is null;    
    
    /*If a mobile has ever been a recipient in a shared upgrade and the shared upgrade is not reversed yet, the rate plan CAN transaction for 
    that mobile is going to be unaccepted.*/
    
    IF(l_recipient_found > 0) THEN
        p_tran.is_accepted := 'N';
        l_update := true;
    END IF;
    

    /* if this is a recipient disconnect record, but the cross upgrade was reversed before the mobile disconnected. set the event reason=CUPGD*/
    BEGIN
        SELECT * INTO cmv_rec FROM (
        SELECT * FROM contract_moves WHERE recipient_mobile = p_tran.p_isd_mobile and recipient_isd = p_tran.p_mobile_isd 
        ORDER BY timestamp DESC)
		WHERE ROWNUM = 1;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('Mobile [' || p_tran.p_isd_mobile || '] Mobile isd [' ||  p_tran.p_mobile_isd || ']. No reversal found.' );
        WHEN OTHERS THEN NULL;
    END;
    
    IF(cmv_rec.action_type = 'CMR') THEN
        p_tran.agt_event_reason := 'CUPGD';
        l_update := true;
    END IF;

    /*if the update flag is not set, return */
    IF(l_update = FALSE) THEN
        RETURN;
    END IF;
    
    p_tran.mod_user := 'CMV_RECIPIENT_DISC';
    p_tran.mod_date := SYSDATE;
        
    UPDATE tlg_daily_trans 
    SET row = p_tran
    WHERE tlg_daily_trans_key = p_tran.tlg_daily_trans_key;    

END SP_CMV_RECIPIENT_DISC;
/