CREATE OR REPLACE PROCEDURE SP_ERICSSON_ML_LOAD_FROM_STAGE
(
    p_year IN integer,
    p_month IN integer,
    p_day IN integer,
    p_errormessage out varchar2
)
IS
BEGIN

    DECLARE
    
      staging_rec  ericsson_ml_snapshot_staging%ROWTYPE;

      l_delete_ctr INTEGER;
      l_insert_ctr INTEGER;
      l_mod_date DATE;
      l_start_time DATE;
      l_finish_time DATE;
      
      -- input cursor
      CURSOR input_cursor IS
      SELECT *
      FROM ericsson_ml_snapshot_staging
      WHERE rateplan_status = 'A' OR rateplan_status IS NULL;

    BEGIN

      DBMS_OUTPUT.put_line('PROCEDURE SP_ERICSSON_ML_LOAD_FROM_STAGE v1.0');
      DBMS_OUTPUT.put_line( 'p_year: ' || p_year || ', p_month: ' || p_month  || ', p_day: ' || p_day || '.');

      l_start_time := SYSDATE;
      l_mod_date := SYSDATE;
      
      l_delete_ctr := 0;
      l_insert_ctr := 0;
      
      BEGIN
      
        -- delete data from the table in case of a rerun
        DELETE 
        FROM ericsson_ml_snapshot
        WHERE year = p_year
          AND month = p_month
          AND day = p_day;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN NULL;
        WHEN OTHERS THEN
          ROLLBACK;
          p_errormessage := 'WARNING!!! DELETE Processing Unsuccessful: ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' );
          DBMS_OUTPUT.put_line ('Processing year: ' || p_year || ' month: ' || p_month || ' day: ' || p_day);
          DBMS_OUTPUT.put_line(p_errormessage);
          DBMS_OUTPUT.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
          RAISE_APPLICATION_ERROR( -20018, p_errormessage || ' SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM );
      END;

      l_delete_ctr := l_delete_ctr + SQL%ROWCOUNT;
      
      
      OPEN input_cursor;
      
      LOOP
        FETCH input_cursor into staging_rec;
               
        EXIT WHEN input_cursor%NOTFOUND;
      
        BEGIN
        
           -- Insert ericsson_ml_snapshot records from staging table ericsson_ml_snapshot_staging
           INSERT INTO ericsson_ml_snapshot
              (ERICSSON_ML_SNAPSHOT_KEY,
               YEAR,
               MONTH,
               DAY,
               RECORD_TYPE,
               SNAPSHOT_TIME,
               TIME_ZONE,
               SNAPSHOT_TIME_UTC,
               MOBILE,
               MASTER_MOBILE,
               CCBS_ACCOUNT_ID,
               CLASS_OF_SERVICE,
               RATE_PLAN,
               REGION_NAME,
               REGION_CODE,
               MARKET_NAME,
               MARKET_CODE,
               SUB_MARKET_NAME,
               SUB_MARKET_CODE,
               ACCOUNT_STATUS,
               BALANCE_STATUS,
               SRC_CUST_STATUS,
               SRC_SERV_STATUS,
               SRC_AIRTIME_STATUS,
               INITIAL_INSTALLATION_DATE,
               INITIAL_ACTIVATION_DATE,
               INSTALLATION_DATE,
               ACTIVATION_DATE,
               AIRTIME_EXP_DATE,
               SCHED_SERVICE_CANCEL_DATE,
               ACTUAL_SERVICE_CANCEL_DATE,
               MAIN_ACCOUNT_BALANCE,
               REFILL_PROMOTION_PLAN_ID,
               LANGUAGE_ID,
               RATEPLAN_STATUS,
               RATEPLAN_EXP_DATE,
               ML_INDICATOR,
               ML_PRIMARY_MOBILE,
               MOD_USER,
               MOD_DATE)
             VALUES
              (seq_ericsson_ml_snapshot.NEXTVAL,
               staging_rec.YEAR,
               staging_rec.MONTH,
               staging_rec.DAY,
               staging_rec.RECORD_TYPE,
               staging_rec.SNAPSHOT_TIME,
               staging_rec.TIME_ZONE,
               staging_rec.SNAPSHOT_TIME_UTC,
               staging_rec.MOBILE,
               staging_rec.MASTER_MOBILE,
               staging_rec.CCBS_ACCOUNT_ID,
               staging_rec.CLASS_OF_SERVICE,
               staging_rec.RATE_PLAN,
               staging_rec.REGION_NAME,
               staging_rec.REGION_CODE,
               staging_rec.MARKET_NAME,
               staging_rec.MARKET_CODE,
               staging_rec.SUB_MARKET_NAME,
               staging_rec.SUB_MARKET_CODE,
               staging_rec.ACCOUNT_STATUS,
               staging_rec.BALANCE_STATUS,
               staging_rec.SRC_CUST_STATUS,
               staging_rec.SRC_SERV_STATUS,
               staging_rec.SRC_AIRTIME_STATUS,
               staging_rec.INITIAL_INSTALLATION_DATE,
               staging_rec.INITIAL_ACTIVATION_DATE,
               staging_rec.INSTALLATION_DATE,
               staging_rec.ACTIVATION_DATE,
               staging_rec.AIRTIME_EXP_DATE,
               staging_rec.SCHED_SERVICE_CANCEL_DATE,
               staging_rec.ACTUAL_SERVICE_CANCEL_DATE,
               staging_rec.MAIN_ACCOUNT_BALANCE,
               staging_rec.REFILL_PROMOTION_PLAN_ID,
               staging_rec.LANGUAGE_ID,
               staging_rec.RATEPLAN_STATUS,
               staging_rec.RATEPLAN_EXP_DATE,
               staging_rec.ML_INDICATOR,
               staging_rec.ML_PRIMARY_MOBILE,
               'RepositoryLoad',
               l_mod_date); 

         EXCEPTION
           WHEN NO_DATA_FOUND THEN NULL;
           WHEN OTHERS THEN
             ROLLBACK;
             p_errormessage := 'WARNING!!! INSERT Processing Unsuccessful: ' || TO_CHAR( SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS' );
             DBMS_OUTPUT.put_line ('Processing year: ' || p_year || ' month: ' || p_month || ' day: ' || p_day);
             DBMS_OUTPUT.put_line(p_errormessage);
             DBMS_OUTPUT.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
             RAISE_APPLICATION_ERROR( -20019, p_errormessage || ' SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM );
         END;

         l_insert_ctr := l_insert_ctr + SQL%ROWCOUNT;
                  
         IF mod(l_insert_ctr,10000) = 0 THEN
            DBMS_OUTPUT.put_line ('Committed on ' || l_insert_ctr || ' records.');
            COMMIT;
         END IF;
      
      END LOOP;

      CLOSE input_cursor;
      
      DBMS_OUTPUT.put_line ('Deleted ' || l_delete_ctr || ' records for SP_ERICSSON_ML_LOAD_FROM_STAGE.');
      DBMS_OUTPUT.put_line ('Inserted ' || l_insert_ctr || ' records for SP_ERICSSON_ML_LOAD_FROM_STAGE.');

      l_finish_time := SYSDATE;
      DBMS_OUTPUT.put_line ('Start time (SP_ERICSSON_ML_LOAD_FROM_STAGE): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
      DBMS_OUTPUT.put_line ('End time (SP_ERICSSON_ML_LOAD_FROM_STAGE): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

      COMMIT;
      
    END;

END SP_ERICSSON_ML_LOAD_FROM_STAGE;
/
