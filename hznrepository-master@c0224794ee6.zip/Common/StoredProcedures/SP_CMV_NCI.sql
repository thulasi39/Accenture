CREATE OR REPLACE PROCEDURE SP_CMV_NCI
(
    p_donor_mobile IN VARCHAR2,
    p_donor_ban     IN VARCHAR2,
    p_donor_isd IN DATE,
    p_recipient_mobile IN VARCHAR2,
    p_recipient_ban IN VARCHAR2,
    p_recipient_isd IN DATE,
    p_recipient_prod_code IN VARCHAR2,
    p_recipient_product_type IN VARCHAR2,
    p_recipient_prod_sys_isd IN DATE,
    p_resultset           OUT      sys_refcursor
)
IS
    R_RESULTSET SYS_REFCURSOR;

    TYPE nci_activity_record IS RECORD (
      nci_activity_key   INTEGER,
      isd_mobile          VARCHAR2 (10),
      isd_date             DATE,
      isd_ban              VARCHAR2 (30),
      live_days            INTEGER,
      prod_sys_isd      DATE,
      app_err_msg      VARCHAR2 (32)
   );
    
   mobile_rec nci_activity_record;    
   
    TYPE nci_out_record IS RECORD (donor_mobile varchar2(10),
        donor_isd date, 
        donor_ban varchar2(30),
        donor_live_days integer, 
        recipient_mobile varchar2(10),
        recipient_isd date,
        recipient_ban varchar2(30),
        recipient_live_days integer,
        recipient_prod_isd date ,
        app_err_msg varchar2(32) );

    out_rec nci_out_record;

BEGIN

	dbms_output.put_line('SP_CMV_NCI:  for donor mobile : ' || p_donor_mobile || ' and recipient mobile ' || p_recipient_mobile );

	/* initialize the out record */
	out_rec.donor_mobile := p_donor_mobile;
	out_rec.donor_isd := p_donor_isd;
	out_rec.donor_ban := p_donor_ban;
	out_rec.donor_live_days := 0;
	out_rec.recipient_mobile := p_recipient_mobile;
	out_rec.recipient_isd := p_recipient_isd;
	out_rec.recipient_ban := p_recipient_ban;
	out_rec.recipient_live_days := 0;
	out_rec.recipient_prod_isd := p_recipient_prod_sys_isd;

	/* get the live days on the Donor rate plan at the time of the CMV or CMR event */
	dbms_output.put_line('sp_get_pre_nci_history for donor mobile : ' || p_donor_mobile );
	SP_GET_PRE_NCI_HISTORY(p_donor_mobile, p_donor_ban ,p_donor_isd, 'GENERIC RATE PLAN', null, R_RESULTSET);
	FETCH R_RESULTSET INTO mobile_rec;

	IF (mobile_rec.nci_activity_key = 0 OR mobile_rec.nci_activity_key IS NULL) THEN
		dbms_output.put_line ('No NCI history found for the donor rate plan' || p_donor_mobile);
	ELSE
		dbms_output.put_line('Found NCI History for the donor rate plan ' || p_donor_mobile);
		out_rec.donor_mobile := mobile_rec.isd_mobile;
		out_rec.donor_isd := mobile_rec.isd_date;
		out_rec.donor_ban := mobile_rec.isd_ban;
		out_rec.donor_live_days := mobile_rec.live_days;
	END IF;

	/* get the live days on the Recipient product (could be either a rate plan or UPGT */
	IF (p_recipient_product_type = 'GENERIC RATE PLAN') THEN
		dbms_output.put_line('sp_get_pre_nci_history for recipient mobile : ' || p_recipient_mobile );
		SP_GET_PRE_NCI_HISTORY(p_recipient_mobile, p_recipient_ban ,p_recipient_isd, 'GENERIC RATE PLAN', null, R_RESULTSET);
		FETCH R_RESULTSET INTO mobile_rec;

		IF (mobile_rec.nci_activity_key = 0 OR mobile_rec.nci_activity_key IS NULL) THEN
			dbms_output.put_line ('No NCI history found for the recipient rate plan ' ||p_recipient_mobile);
		ELSE
			dbms_output.put_line('Found NCI History for the recipient rate plan  ' ||p_recipient_mobile);
			out_rec.recipient_mobile := mobile_rec.isd_mobile;
			out_rec.recipient_isd := mobile_rec.isd_date;
			out_rec.recipient_ban := mobile_rec.isd_ban;
			out_rec.recipient_live_days := mobile_rec.live_days;
			out_rec.recipient_prod_isd := p_recipient_prod_sys_isd;
		END IF;
	ELSE
		dbms_output.put_line('sp_get_pre_nci_upgb_history for recipient mobile: ' || p_recipient_mobile );
		SP_GET_PRE_NCI_UPGB_HISTORY(p_recipient_mobile, p_recipient_ban ,p_recipient_isd, p_recipient_prod_code, p_recipient_prod_sys_isd, R_RESULTSET);
		FETCH R_RESULTSET INTO mobile_rec;

		IF (mobile_rec.nci_activity_key = 0 OR mobile_rec.nci_activity_key IS NULL) THEN
			dbms_output.put_line ('No NCI history found for the recipient upgt ' || p_recipient_mobile);
		ELSE
			dbms_output.put_line('Found NCI History for the recipient upgt  ' || p_recipient_mobile);
			out_rec.recipient_mobile := mobile_rec.isd_mobile;
			out_rec.recipient_isd := mobile_rec.isd_date;
			out_rec.recipient_ban := mobile_rec.isd_ban;
			out_rec.recipient_live_days := mobile_rec.live_days;
			out_rec.recipient_prod_isd := mobile_rec.prod_sys_isd;
		END IF;
	END IF;

	OPEN p_resultset FOR
		SELECT   
			out_rec.donor_mobile as donor_mobile, 
			out_rec.donor_isd AS donor_isd,
			out_rec.donor_ban AS donor_ban,
			out_rec.donor_live_days AS donor_live_days, 
			out_rec.recipient_mobile AS recipient_mobile,
			out_rec.recipient_isd AS recipient_isd,
			out_rec.recipient_ban AS recipient_ban,  
			out_rec.recipient_live_days  AS recipient_live_days,
			out_rec.recipient_prod_isd as recipient_prod_isd,
			out_rec.app_err_msg as app_err_msg
		FROM dual;

END SP_CMV_NCI;
/
