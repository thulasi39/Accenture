CREATE OR REPLACE PROCEDURE SP_GET_PRE_NCI_HISTORY(
    p_mobile         IN       varchar2,
    p_ban         IN       varchar2,
    p_isd_date        IN        DATE, 
    p_producttype          IN       VARCHAR2 default 'GENERIC RATE PLAN',
    p_productcode            in varchar2 default null,
    p_resultset           OUT      sys_refcursor
)
IS
    R_RESULTSET SYS_REFCURSOR;

 TYPE nci_out_record IS RECORD (  nci_activity_key integer, isd_mobile varchar2(10),  
	isd_date date, isd_ban varchar2(30),  
	live_days integer, prod_sys_isd date ,
	app_err_msg varchar2(32) );

   mobile_rec nci_out_record;

BEGIN

    SP_NCI_LOOKUP  (p_mobile => p_mobile , p_ban => p_ban , p_isd_date => p_isd_date, p_resultset => R_RESULTSET);
    FETCH R_RESULTSET INTO mobile_rec;
    
    OPEN p_resultset FOR
    SELECT   mobile_rec.nci_activity_key as nci_activity_key, mobile_rec.isd_mobile AS isd_mobile, 
	mobile_rec.isd_date AS mobile_isd_date, mobile_rec.isd_ban AS isd_ban, 
	mobile_rec.live_days AS live_days, mobile_rec.prod_sys_isd AS prod_sys_isd,
    mobile_rec.app_err_msg as app_err_msg
    FROM dual;

END SP_GET_PRE_NCI_HISTORY;
/