CREATE OR REPLACE PROCEDURE SP_PROCESS_NCI
(
	p_year           IN     NUMBER,
	p_month          IN     NUMBER,
	p_day            IN     NUMBER,   
	p_errormessage  OUT		VARCHAR2
)
IS
   l_errmsg   VARCHAR2 (100);
   l_start_time         DATE;
   l_finish_time        DATE;
   l_minute_taken       NUMBER (8, 2);
BEGIN

    l_start_time := SYSDATE;
	
    DBMS_OUTPUT.put_line('Starting(SP_PROCESS_NCI) at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));

	SP_LOAD_NCI_BASE(p_year => p_year, p_month => p_month, p_day => p_day, p_errormessage => l_errmsg);

	SP_LOAD_NCI_ACTIVITY(p_errormessage => l_errmsg);

	SP_UPDATE_DAILY_TRANS_FOR_NCI(p_year => p_year, p_month => p_month, p_day => p_day, p_errormessage => l_errmsg);

    DBMS_OUTPUT.put_line('Finished (SP_UPDATE_DAILY_TRANS_FOR_NCI) at: ' || to_char(SYSDATE, 'mm/dd/yyyy hh24:mi:ss'));

    l_finish_time := SYSDATE;
    l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
    l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');
	
    DBMS_OUTPUT.put_line('Finished (SP_PROCESS_NCI) at: ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line ('Start time (SP_PROCESS_NCI): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
    DBMS_OUTPUT.put_line ('End time (SP_PROCESS_NCI): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

    DBMS_OUTPUT.put_line('Total time taken (SP_PROCESS_NCI)  =  '
                           || l_minute_taken
                           || ' Minutes');	
						   
END SP_PROCESS_NCI;
/