CREATE OR REPLACE PROCEDURE SP_LOAD_NCI_ACTIVITY (
   p_errormessage OUT VARCHAR2)
IS
   l_errmsg   VARCHAR2 (100);
   l_start_time         DATE;
   l_finish_time        DATE;
   l_minute_taken       NUMBER (8, 2);
   
BEGIN

   l_start_time := SYSDATE;

   DBMS_OUTPUT.put_line('Starting(SP_LOAD_NCI_ACTIVITY) at: ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
   
   SP_NCI_MAP (l_errmsg);
   
   l_finish_time := SYSDATE;
   l_minute_taken := (l_finish_time - l_start_time) * 24 * 60;
   l_minute_taken := TO_NUMBER (l_minute_taken, '9999.99');
	
   DBMS_OUTPUT.put_line('Finished (SP_LOAD_NCI_ACTIVITY) at: ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

   DBMS_OUTPUT.put_line ('Start time (SP_LOAD_NCI_ACTIVITY): ' || to_char(l_start_time, 'mm/dd/yyyy hh24:mi:ss'));
   DBMS_OUTPUT.put_line ('End time (SP_LOAD_NCI_ACTIVITY): ' || to_char(l_finish_time, 'mm/dd/yyyy hh24:mi:ss'));

   DBMS_OUTPUT.put_line('Total time taken (SP_LOAD_NCI_ACTIVITY)  =  '
                           || l_minute_taken
                           || ' Minutes');	 
						   
END SP_LOAD_NCI_ACTIVITY;
/