CREATE OR REPLACE PROCEDURE SP_CMV_DELETE
(
    p_year    IN INTEGER,
    p_month IN INTEGER,
    p_day     IN INTEGER
)
IS
    /* Delete existing CMV and CMR entries for the month/day/year */
    CURSOR cmv_cur IS
    SELECT
        contract_moves_key, donor_mobile, donor_isd, eff_donor_mobile, eff_donor_isd, recipient_mobile, recipient_isd, action_type, action_date, is_active
    FROM contract_moves
        WHERE month = p_month AND day = p_day AND year = p_year AND action_type in ('CMV', 'CMR') ORDER BY timestamp desc;

BEGIN
  
    dbms_output.put_line('SP_CMV_DELETE: Deleting existing CMV records for  month: ' || p_month || ' day:  ' ||   p_day || ' year:  ' ||   p_year);
  
    /* reverse chain moves where last move was done on the given day */
    FOR cmv_rec in cmv_cur
    LOOP

        dbms_output.put_line('Deleting ' || cmv_rec.action_type || ' record for  donor: ' || cmv_rec.donor_mobile || ' recipient:  ' || cmv_rec.recipient_mobile);

        IF (cmv_rec.action_type = 'CMV') THEN

            /* If a contract move record is inactive, it may be part of a chain move of contracts.  If the donor is an effective donor on another unexpired record, update the effective donor info to remove the
                last part of the chain */
            IF (cmv_rec.is_active = 'N') THEN
                dbms_output.put_line('CMV Record was part of a contract move chain.  Donor was ' || cmv_rec.donor_mobile ||
                    'and is being updated to ' || cmv_rec.recipient_mobile);
                UPDATE contract_moves SET eff_donor_mobile = cmv_rec.recipient_mobile, eff_donor_isd = cmv_rec.recipient_isd,
					mod_user = 'CMV_DELETE', mod_date = SYSDATE 
                    WHERE is_active = 'Y' AND eff_donor_mobile = cmv_rec.donor_mobile AND eff_donor_isd = cmv_rec.donor_isd;

			END IF;
		END IF;

		IF (cmv_rec.action_type = 'CMR') THEN

             /* If a contract move record that was reversed is inactive, it may be part of a chain move of contracts.  Find the active CMV record that represents the chain and make the effective donor equal to the CMR recipient.
                 This will reverse the last contract move event */
			IF (cmv_rec.is_active = 'N') THEN
                dbms_output.put_line('Reversed CMV Record was part of a contract move chain.  Donor was ' || cmv_rec.recipient_mobile ||
                    'and is being updated to ' || cmv_rec.donor_mobile);
                UPDATE contract_moves SET eff_donor_mobile = cmv_rec.donor_mobile, eff_donor_isd = cmv_rec.donor_isd,
					mod_user = 'CMV_DELETE', mod_date = SYSDATE 
                    WHERE is_active = 'Y' AND eff_donor_mobile = cmv_rec.recipient_mobile AND eff_donor_isd = cmv_rec.recipient_isd;
			END IF;

            /* undo the reversal dates for CMV that were reversed for the given day */
            UPDATE contract_moves set reversal_date = NULL WHERE action_type = 'CMV' AND donor_mobile = cmv_rec.donor_mobile AND donor_isd = cmv_rec.donor_isd
                AND recipient_mobile = cmv_rec.recipient_mobile AND recipient_isd = cmv_rec.recipient_isd AND reversal_date = cmv_rec.action_date;

		END IF;

        /* Next delete the current record now that it has been handled */
		dbms_output.put_line('Deleting the record: ' || cmv_rec.contract_moves_key);
        DELETE contract_moves WHERE contract_moves_key = cmv_rec.contract_moves_key;

	END LOOP;

END SP_CMV_DELETE;
/
