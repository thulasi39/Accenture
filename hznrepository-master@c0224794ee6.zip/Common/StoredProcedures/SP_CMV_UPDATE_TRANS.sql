CREATE OR REPLACE PROCEDURE SP_CMV_UPDATE_TRANS
(
    p_year    IN INTEGER,
    p_month    IN INTEGER,
    p_day    IN INTEGER
)
IS
    tran_rec tlg_daily_trans%rowtype;
    DailyTransCounter INTEGER;
    
    /* get Rate Plan Disconnect, SVC, SVD, UPGT add, and UPGT backout records for the given day */
    CURSOR tran_cur IS
        SELECT *
        FROM tlg_daily_trans
         WHERE month = p_month AND day = p_day AND year = p_year
         AND action_type in  ('CAN', 'SVC', 'SVD', 'C17', 'C16', 'MVC', 'MVD')
         AND is_valid = 'Y' 
         AND nvl(event_reason,' ') != 'DUP'
         ORDER BY TIMESTAMP asc;

BEGIN

    DailyTransCounter := 0;
    dbms_output.put_line('SP_CMV_UPDATE_TRANS v2.1: Process daily transactions using Cross Upgrade information: ' || p_month || ' day:  ' ||   p_day || ' year:  ' ||   p_year);

    /* Process each record from tlg_daily_trans */
    FOR tran_rec in tran_cur LOOP

        DailyTransCounter := DailyTransCounter + 1;

        /* For a 'C16', if the UPGT add is for a Cross Upgrade UPGT, find the donor mobile from the contract moves table and store it in the p_info field of the transaction. */
        IF (tran_rec.action_type = 'C16') THEN
            SP_CMV_UPGT_ADD(tran_rec);
        END IF;
        
        /* For a 'C17', this can be the case of either the backout of a UPGT that was on the Recipient before a Cross Upgrade event, or the backout of a Cross Upgrade UPGT in the case of a CMR event. */
        IF ( tran_rec.action_type = 'C17') THEN
            SP_CMV_UPGT_BACKOUT(tran_rec);
        END IF;
        
        
        /* Check all Disconnects to see if they are involved in a Cross Upgrade A 'CAN' record could be for a UPGT rather than a Rate Plan.  Only handle Rate Plan Disconnects here. */
        IF (tran_rec.action_type = 'CAN' ) THEN
            /* Handle a Recipient Disconnect. using the p_* fields because they have the NCI logic applied to them.  */
            SP_CMV_RECIPIENT_DISC(tran_rec);

            /* Handle a Donor Disconnect */
            SP_CMV_DONOR_DISC( tran_rec);
        END IF;
        
        IF (tran_rec.action_type IN ('SVC', 'SVD', 'MVC', 'MVD') ) THEN
            SP_CMV_SVC(tran_rec);
        END IF;

        /* If the resulting live_days are greater than 365, mark the record as unaccepted */  
	/* Commented below code out as Arun and Raj discussed as the quick and dirty fix by Retail on 09/05/2014 for August project.*/
	/*
        IF ( tran_rec.p_active_days > 365 ) THEN
            UPDATE tlg_daily_trans set is_accepted = 'N', mod_user = 'CMV_UPDATE_TRANS', mod_date = SYSDATE where tlg_daily_trans_key = tran_rec.tlg_daily_trans_key ;
            IF (SQL%ROWCOUNT > 0) THEN
                dbms_output.put_line('Unaccept Transaction because resulting live days are > 365: ' || tran_rec.tlg_daily_trans_key);
            END IF;        
        END IF;
        */
    END LOOP;

    DBMS_OUTPUT.PUT_LINE( 'tlg_daily_trans records read: ' || DailyTransCounter );

END SP_CMV_UPDATE_TRANS;
/
