CREATE OR REPLACE PROCEDURE SP_CMV_DONOR_DISC 
(
    p_tran in out tlg_daily_trans%rowtype
)
IS
    /*
    1. Shared upgrade is the new name for cross upgrade.
    2. This stored procedure is called only for CAN transactions for a rate plan.
    3. If a mobile is an effective donor in a shared upgrade and the shared upgrade is still active, the rate plan CAN transaction for 
    that mobile is going to be unaccepted.
    4. we should not get generic feature for donor
    */
    cmv_rec contract_moves%rowtype;

   /* See if this is a Donor Disconnect.  This will either look like an active contract move event where this mobile is the effective donor, or when there is
   a contract move reversal (for a rate plan only) then the recipient looks like a donor. */
       
        cnt NUMBER;

BEGIN
    dbms_output.put_line('SP_CMV_DONOR_DISC: ');
    /*get the contract move history */
    BEGIN
        SELECT * INTO cmv_rec FROM (
        SELECT * FROM contract_moves cm
        WHERE cm.eff_donor_mobile = p_tran.p_isd_mobile AND cm.eff_donor_isd = p_tran.p_mobile_isd AND cm.action_type = 'CMV' AND is_active = 'Y'
        AND (p_tran.timestamp - timestamp) < 365 -- no need to look beyond 365 days
        ORDER BY timestamp DESC)
		WHERE ROWNUM = 1;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('Mobile [' || p_tran.p_isd_mobile || '] Mobile isd [' ||  p_tran.p_mobile_isd || '] is not an effective donor.' );
        WHEN OTHERS THEN
            dbms_output.put_line('Exception occured' );
    END;
    
    IF ( cmv_rec.contract_moves_key IS NULL) THEN
        return;
    END IF;

    --update common fields
    p_tran.p_isd_mobile := cmv_rec.recipient_mobile;
    p_tran.p_mobile_isd := cmv_rec.recipient_isd;
    p_tran.p_seller_id := cmv_rec.recipient_seller_id;
    p_tran.p_product_id := cmv_rec.recipient_product_id;
    p_tran.p_product_code_isd := cmv_rec.timestamp;            /*Here the p_product_code_isd has the contract_move date for HorizonMap to use.*/
   --- p_tran.p_info := cmv_rec.eff_donor_mobile;-----put recipient mobile?????????
    p_tran.p_info := cmv_rec.recipient_mobile;-----put recipient mobile
	p_tran.agt_event_reason := 'CUPG';
    p_tran.mod_user := 'CROSSUPG'; 
    p_tran.mod_date := SYSDATE;

    SP_CMV_PRODUCT(p_tran);
        
    p_tran.PRODUCT_CODE_ISD := p_tran.p_product_code_isd ;
    p_tran.PRODUCT_CODE_DCD := p_tran.action_date;
    p_tran.P_PRODUCT_CODE_ISD2 := cmv_rec.recipient_product_code_isd; --RETAIL team needs it for chargeback
    
    --update the transaction
    UPDATE tlg_daily_trans
    SET ROW = p_tran
    WHERE tlg_daily_trans_key = p_tran.tlg_daily_trans_key;        

    /* If a Donor disconnects (or the Recipient with a Reversal), make the CMV record for this move inactive */
    DBMS_OUTPUT.put_line ('Setting is_active to N in contract_moves');
    UPDATE contract_moves
        SET is_active = 'N', mod_user = 'CMV_DONOR_DISC', mod_date = SYSDATE
    WHERE eff_donor_mobile = cmv_rec.eff_donor_mobile AND eff_donor_isd = cmv_rec.eff_donor_isd; 


END SP_CMV_DONOR_DISC;
/
