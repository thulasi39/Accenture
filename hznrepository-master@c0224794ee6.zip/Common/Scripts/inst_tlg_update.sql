set serveroutput on

DECLARE
ERRORMSG VARCHAR2(1000);
--*     1-        p_year IN integer,
--*     2-        p_month IN integer,
--*     4-        p_errormessage out varchar2

--*	Feed Type: inst_tlg_update
BEGIN
SP_INST_INFO_TLG_UPDATE ( &&1, &&2, ERRORMSG );
COMMIT;
END;
/
quit;
