set serveroutput on;

-- &&1 is month
-- &&2 is day
-- &&3 is year


-- ONLY use to reset
--update tlg_daily_trans set is_washed='N', mod_user='RepositoryLoad' where month=&&1 and year=&&3 and is_washed='Y';

-------------------------------------------------------------
-- Get Total count for same isd_mobile, same day, 
-- product_type=generic rate plan.  
-------------------------------------------------------------
begin
  execute immediate 'drop table wash_generic_rp';
  exception when others then null;
end;
/

create table wash_generic_rp as select  day, isd_mobile, product_type, count(*) cnt, mod(count(*),2) oddeven from tlg_daily_trans 
where month=&&1 and day=&&2 and year=&&3 and action_type IN ('NAC','RCL','CAN') 
and upper(PRODUCT_TYPE)='GENERIC RATE PLAN'
group by day, isd_mobile, product_type having count(*) > 1;

-------------------------------------------------------------
-- If even, wash everything
-------------------------------------------------------------
update tlg_daily_trans set is_washed='Y', mod_user='wash rp even',mod_date=sysdate
where day||isd_mobile IN (select day||isd_mobile from wash_generic_rp where oddeven=0) and upper(product_type)='GENERIC RATE PLAN' and month=&&1 and day=&&2 and year=&&3;

-------------------------------------------------------------
-- If odd, wash everything except the 1st transaction.
-------------------------------------------------------------
begin
  execute immediate 'drop table wash_minimum_odd';
  exception when others then null;
end;
/

create table wash_minimum_odd as
select a.tlg_daily_trans_key, a.timestamp, a.day, a.isd_mobile from tlg_daily_trans a
where a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_generic_rp w where oddeven=1) 
and upper(a.product_type)='GENERIC RATE PLAN' and month=&&1 and day=&&2 and year=&&3;

update tlg_daily_trans a set is_washed='Y', mod_user='wash rp odd',mod_date=sysdate
where a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_minimum_odd w) and  
a.timestamp not in (select min(v.timestamp) from wash_minimum_odd v where v.day||v.isd_mobile=a.day||a.isd_mobile) 
and upper(a.product_type)='GENERIC RATE PLAN' and month=&&1 and day=&&2 and year=&&3;
commit;

-------------------------------------------------------------
-- COLLECT ALL  action_type IN ('C16','NAC','C17','CAN','BUG') 
-------------------------------------------------------------
begin
  execute immediate 'drop table wash_bug';
  exception when others then null;
end;
/

create table wash_bug as
select day, bill_mkt_code, action_type, event_reason, isd_mobile, tlg_daily_trans_key, product_type, product_id 
from tlg_daily_trans where month=&&1 and day=&&2 and year=&&3
and action_type IN ('C16','NAC','C17','CAN','BUG') 
and day||isd_mobile in (select day||isd_mobile from tlg_daily_trans where month=&&1 and day=&&2 and year=&&3 and action_type ='BUG')
order by day, isd_mobile, tlg_daily_trans_key, product_type, product_id;

-------------------------------------------------------------
-- With BRE on same day. Keep the BUG/BRE and wash every pair
-- of non-BRE C16 followed by a C17. Keep BUG as it is the off 
-- part following a new activation of NEXT. 
-------------------------------------------------------------
update tlg_daily_trans a set is_washed='Y', a.mod_user='wash bug',a.mod_date=sysdate
where a.month=&&1 and a.day=&&2 and a.year=&&3 and a.action_type!='BUG' and 
a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_bug w where w.action_type='BUG' and w.event_reason IN ('CDBRE','CBRE')) and
a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_bug w where w.action_type='C16' and 
    (w.event_reason IS NULL OR w.event_reason NOT IN ('CDBRE','CBRE')) and upper(a.product_type)='GENERIC FEATURE') and
a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_bug w where w.action_type='C17' and upper(a.product_type)='GENERIC FEATURE');

-------------------------------------------------------------
-- Without BRE on same day: Wash every pair of C16/C17 
-- (same ban,  current_mobile/same productId)
-------------------------------------------------------------
update tlg_daily_trans a set is_washed='Y', a.mod_user='wash bug',a.mod_date=sysdate
where a.month=&&1 and a.day=&&2 and a.year=&&3 and a.action_type!='BUG' and 
a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_bug w where w.action_type='BUG' and (w.event_reason IS NULL OR w.event_reason NOT IN ('CDBRE','CBRE'))) and
a.day||a.isd_mobile||a.product_id IN (select w.day||w.isd_mobile||w.product_id from wash_bug w where w.action_type='C16') and
a.day||a.isd_mobile||a.product_id IN (select w.day||w.isd_mobile||w.product_id from wash_bug w where w.action_type='C17');

-------------------------------------------------------------
-- Without BRE on same day: Wash every pair of NAC/C17 
-- (same ban,  current_mobile/same productId)
-------------------------------------------------------------
update tlg_daily_trans a set is_washed='Y', a.mod_user='wash bug',a.mod_date=sysdate
where a.month=&&1 and a.day=&&2 and a.year=&&3 and a.action_type!='BUG' and 
a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_bug w where w.action_type='BUG' and (w.event_reason IS NULL OR w.event_reason NOT IN ('CDBRE','CBRE'))) and
a.day||a.isd_mobile||a.product_id IN (select w.day||w.isd_mobile||w.product_id from wash_bug w where w.action_type='NAC') and
a.day||a.isd_mobile||a.product_id IN (select w.day||w.isd_mobile||w.product_id from wash_bug w where w.action_type='C17');

-------------------------------------------------------------
-- Without BRE on same day: Wash every pair ofC16/CAN 
-- (same ban,  current_mobile/same productId)
-------------------------------------------------------------
update tlg_daily_trans a set is_washed='Y', a.mod_user='wash bug',a.mod_date=sysdate
where a.month=&&1 and a.day=&&2 and a.year=&&3 and a.action_type!='BUG' and 
a.day||a.isd_mobile IN (select w.day||w.isd_mobile from wash_bug w where w.action_type='BUG' and (w.event_reason IS NULL OR w.event_reason NOT IN ('CDBRE','CBRE'))) and
a.day||a.isd_mobile||a.product_id IN (select w.day||w.isd_mobile||w.product_id from wash_bug w where w.action_type='C16') and
a.day||a.isd_mobile||a.product_id IN (select w.day||w.isd_mobile||w.product_id from wash_bug w where w.action_type='CAN');

commit;
quit;
/

