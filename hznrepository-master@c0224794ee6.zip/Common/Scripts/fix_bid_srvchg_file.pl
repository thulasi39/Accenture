#!/usr/local/bin/perl -w

################################################################################
# For use with BID_SRVCHG files
# Adjust the file so record legth is correct for bad CUSTOMER_NAME
# Bad records are written to the badfile.
################################################################################

$inputfile = shift;
($inputfile) || die "Usage: $0 <transfile>";
$goodfile = "$inputfile.good";
$badfile = "$inputfile.custname.bad";

open(INPUTFILE, "$inputfile") || die "Can't open $inputfile";
open(GOODFILE, ">$goodfile") || die "Can't open $goodfile";
open(BADFILE, ">$badfile") || die "Can't open $badfile";

$correct_length = 775;

while (<INPUTFILE>) {

        chomp;
        $line_length = length;
        if ($line_length != $correct_length) { # Bad record
                $spaces_needed = $correct_length - $line_length;
                $pad = " " x $spaces_needed;
                
                print BADFILE "$_\n";
                 s/^(.{259})(.*)$/$1$pad$2/;
                print GOODFILE "$_\n";

                #### printf "%s\n", GOODFILE;
        }
        else { # Good record
                print GOODFILE "$_\n";
        }

}

close(INPUTFILE) || die "Can't close $inputfile";
close(GOODFILE) || die "Can't close $goodfile";
close(BADFILE) || die "Can't close $badfile";

# Remove badfile if it is empty
unlink $badfile unless (-s $badfile);

# Rename goodfile to original inputfile
@cmdargs = ("/bin/mv", "$goodfile", "$inputfile");
print "@cmdargs\n";
system(@cmdargs);
