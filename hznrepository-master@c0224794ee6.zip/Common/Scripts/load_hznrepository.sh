#!/bin/ksh
#load_hznrepository.sh
#----------include------------------
. ${HORIZON_BIN}/HznRep_common.inc
#------------------------------------
. ${HORIZON_BIN}/file_send.inc
#------------------------------------
. /opt/app/retailcommon/DataRouter/bin/env
###########################################################################
# Function: LOOK_BY_FEEDTYPE
# Purpose : Search and wait for the FEEDTYPE file indicating the Extract file is here.
# Usage   : LOOK_BY_FEEDTYPE
###########################################################################
function LOOK_BY_FEEDTYPE
{
IN_FEEDTYPE=`echo $1|tr '[A-Z]' '[a-z]'`
echo " Entered LOOK_BY_FEEDTYPE for IN_FEEDTYPE: $1 -----------------------------------------------------" | tee -a ${HznLOG}

if [[ "$IN_FEEDTYPE" = "calc_ban" ]]; then
        if [[ -z $PROCESSDAY ]]; then
                TMPDAYSTR=""
        else
                TMPDAYSTR=" and day=$PROCESSDAY "
        fi
else
        TMPDAYSTR=" and day=$PROCESSDAY "
fi

if [[ "$IN_FEEDTYPE" = "global_tlg_inst_info" ]]; then
	TMPDAYSTR=""
fi 

if [[ "$IN_FEEDTYPE" = "inst_tlg_update" ]]; then
	TMPDAYSTR=""
fi 

if [[ "$IN_FEEDTYPE" = "ccpm_inst_tlg_catchup" ]]; then
	TMPDAYSTR=""
fi 

SQL_CMD="set heading off pagesize 0 feedback off
SELECT count(*) FROM LOAD_STATUS WHERE  feed_type = '$IN_FEEDTYPE' $TMPDAYSTR and month = $PROCESSMONTH and year = $PROCESSYEAR and re_process is null;
exit;"

echo -e $SQL_CMD | tee -a ${HznLOG}
echo  "$SQL_CMD" | $SQLSTART |read LOADSTATUS_COUNT

echo -e "LOADSTATUS_COUNT=$LOADSTATUS_COUNT"| tee -a ${HznLOG}

until [[ "$LOADSTATUS_COUNT" = "1" ]]
do
	# Wait a minute
	echo -e "`date` Waiting for LOAD_STATUS for $IN_FEEDTYPE  status complete ..."| tee -a ${HznLOG}
	sleep 300
	echo -e "$SQL_CMD" | $SQLSTART |read LOADSTATUS_COUNT
	echo -e "LOADSTATUS_COUNT=$LOADSTATUS_COUNT" | tee -a ${HznLOG}
done
echo -e "`date` LOAD_STATUS $IN_FEEDTYPE COMPLETE STATUS FOUND... Continuing..."| tee -a ${HznLOG}
}

###########################################################################
# Function: LOOK
# Purpose : Search and wait for the file indicating the Extract file is here.
# Usage   : LOOK
###########################################################################
function LOOK
{
echo " Entered LOOK-----------------------------------------------------" | tee -a ${HznLOG}
echo "The LOOK section" | tee -a ${HznLOG}
EndFile=`basename ${HznDATAEND}`
DatFile=`basename ${HznDATAINP}`
export JOB_INFO="LOOK - ~/data/${FEED_TYPE}/${EndFile}"
export STARTTIME=`dtx`
export ENDTIME=
JobStage "STARTING"
# Set max to 20 hours
typeset -i MAXCOUNT=1200
typeset -i MAXCOUNTDAT=1200
typeset -i LookCount=0
typeset -i LookCountdat=0

if [[ "$SKIP_PREV_COMPLETE_CHECK" != "Y" ]]; then
	#---------------------------------------------------------------------
	#	Check for previous day load.
	#---------------------------------------------------------------------
	CHECK_PREVDAY
	#---------------------------------------------------------------------
fi

if [[ "$FEED_TYPE" = "product_upgrade" ]]; then
	LOOK_BY_FEEDTYPE dc_tlg_update
elif [[ "$FEED_TYPE" = "cross_upgrade" ]]; then
	LOOK_BY_FEEDTYPE dc_tlg_update
elif [[ "$FEED_TYPE" = "nci" ]]; then
	LOOK_BY_FEEDTYPE dc_tlg_update
elif [[ "$FEED_TYPE" = "hznrep_daily_upd" ]]; then
	LOOK_BY_FEEDTYPE global_tlg_dealer_chg
	LOOK_BY_FEEDTYPE global_tlg_daily
	LOOK_BY_FEEDTYPE ccpm_inst
	LOOK_BY_FEEDTYPE ccpm_inst_hist
	LOOK_BY_FEEDTYPE ericsson
	LOOK_BY_FEEDTYPE ericsson_ml
elif [[ "$FEED_TYPE" = "hznrep_ccpm_wireless" ]]; then
	LOOK_BY_FEEDTYPE tlg_daily_final
	LOOK_BY_FEEDTYPE bid_srvchg_final
elif [[ "$FEED_TYPE" = "cpc_to_tlg" ]]; then
	LOOK_BY_FEEDTYPE cpc
elif [[ "$FEED_TYPE" = "rc_tlg_update" ]]; then
	LOOK_BY_FEEDTYPE global_tlg_daily
	LOOK_BY_FEEDTYPE edm_referral_chg
elif [[ "$FEED_TYPE" = "pos_tlg_update" ]]; then
	LOOK_BY_FEEDTYPE dc_tlg_update
	LOOK_BY_FEEDTYPE nci
	LOOK_BY_FEEDTYPE cross_upgrade
elif [[ "$FEED_TYPE" = "sweep_tlg_srvchg" ]]; then
	LOOK_BY_FEEDTYPE dc_tlg_update
	LOOK_BY_FEEDTYPE nci
	LOOK_BY_FEEDTYPE cross_upgrade
elif [[ "$FEED_TYPE" = "dc_tlg_update" ]]; then
	LOOK_BY_FEEDTYPE global_tlg_dealer_chg
	LOOK_BY_FEEDTYPE global_tlg_daily
elif [[ "$FEED_TYPE" = "ccpm_inst_tlg_update" ]]; then
	LOOK_BY_FEEDTYPE ccpm_inst
	LOOK_BY_FEEDTYPE ccpm_inst_hist
	LOOK_BY_FEEDTYPE global_tlg_dealer_chg
	LOOK_BY_FEEDTYPE global_tlg_daily
elif [[ "$FEED_TYPE" = "tlg_daily_device_id_upd" ]]; then
	LOOK_BY_FEEDTYPE ccpm_inst_tlg_update
elif [[ "$FEED_TYPE" = "ccpm_wline_trans_process" ]]; then
	LOOK_BY_FEEDTYPE ccpm_wl
	LOOK_BY_FEEDTYPE ccpm_contract_trans
	LOOK_BY_FEEDTYPE ccpm_contract_ref_trans
elif [[ "$FEED_TYPE" = "dc_bid_update" ]]; then
	LOOK_BY_FEEDTYPE global_tlg_dealer_chg
	LOOK_BY_FEEDTYPE bid_srvchg
elif [[ "$FEED_TYPE" = "calc_ban" ]]; then
	LOOK_BY_FEEDTYPE bid_srvchg_final
	LOOK_BY_FEEDTYPE bid_cancels
	LOOK_BY_FEEDTYPE cpc
elif [[ "$FEED_TYPE" = "ericsson_tlg_update" ]]; then
	LOOK_BY_FEEDTYPE global_tlg_daily
	LOOK_BY_FEEDTYPE ericsson
elif [[ "$FEED_TYPE" = "inst_tlg_update" ]]; then
	$HORIZON_BIN/preveom.pl -o 0 $PROCESSMONTH $PROCESSYEAR |read TMP_BIDWL_MNTH TMP_BIDWL_DAY TMP_BIDWL_YEAR
	export PROCESSDAY=$TMP_BIDWL_DAY
	LOOK_BY_FEEDTYPE global_tlg_daily
	export PROCESSDAY=
	LOOK_BY_FEEDTYPE global_tlg_inst_info
        LOOK_BY_FEEDTYPE ccpm_inst_tlg_catchup
elif [[ "$FEED_TYPE" = "ccpm_inst_tlg_catchup" ]]; then
	$HORIZON_BIN/preveom.pl -o 0 $PROCESSMONTH $PROCESSYEAR |read TMP_BIDWL_MNTH TMP_BIDWL_DAY TMP_BIDWL_YEAR
	export PROCESSDAY=$TMP_BIDWL_DAY
	LOOK_BY_FEEDTYPE global_tlg_daily
	export PROCESSDAY=
	LOOK_BY_FEEDTYPE global_tlg_inst_info
else
	case ${FEED_TYPE} in
		ericsson)
			ERICSSON_FILES;
			;;
		ericsson_ml)
			ERICSSON_SNAPSHOT;
			;;
		*)
		;;
	esac

	WAITING_FILE="${HznDATAEND}"
	echo "`dtx` Looking for ${WAITING_FILE}" | tee -a ${HznLOG}

	until [ -f ${WAITING_FILE} ]
	do
		# Wait 1 minutes
		echo "`dtx` Waiting for ${WAITING_FILE}" | tee -a ${HznLOG}
		sleep 60
		LookCount=LookCount+1
		if (( LookCount > MAXCOUNT )); then
			echo "${WAITING_FILE} Not Found After ${LookCount} waits" | tee -a ${HznLOG}
			export JOB_INFO="LOOK - ${EndFile} HAS NOT ARRIVED!"
			# add 12 hrs
			MAXCOUNT=MAXCOUNT+720
		fi
	done
	echo "`dtx` ${WAITING_FILE} - FILE FOUND... Continuing..." | tee -a ${HznLOG}

	WAITING_FILE_DAT="${HznDATAINP}"
	echo "`dtx` Looking for ${WAITING_FILE_DAT}" | tee -a ${HznLOG}

	until [ -f ${WAITING_FILE_DAT} ]
	do
		# Wait 1 minutes
		echo "`dtx` Waiting for ${WAITING_FILE_DAT}" | tee -a ${HznLOG}
		sleep 60
		LookCountdat=LookCountdat+1
		if (( LookCountdat > MAXCOUNTDAT )); then
			echo "${WAITING_FILE_DAT} Not Found After ${LookCountdat} waits" | tee -a ${HznLOG}
			export JOB_INFO="LOOK - ${DatFile} HAS NOT ARRIVED!"
			# add 12 hrs
		  	MAXCOUNTDAT=MAXCOUNTDAT+720
		fi
	done
	echo "`dtx` ${WAITING_FILE_DAT} - FILE FOUND... Continuing..." | tee -a ${HznLOG}
fi

	MAXCOUNT=1200
	LookCount=0


	echo "`dtx` PROCESS ($$) REGISTERED... Continuing to next stage..." | tee -a ${HznLOG}

	export ENDTIME=`dtx`
	JobStage "COMPLETE"
	echo " End LOOK-----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: CHECK_PREVDAY
# Purpose : Search and wait for the file indicating the Extract file is here.
# Usage   : CHECK_PREVDAY
###########################################################################
function CHECK_PREVDAY
{
	echo " Entered CHECK-----------------------------------------------------" | tee -a ${HznLOG}

	YESTERDAY=`TZ=GMT+24 date +%Y%m%d`
	echo "Unix Yesterday: ${YESTERDAY}	also see pYYYYMMDD: ${pYYYYMMDD}"

	echo "The CHECK section" | tee -a ${HznLOG}
	ChkFile=`basename ${PREVIOUS_LOAD}`
	export JOB_INFO="CHECK - ~/data/${FEED_TYPE}/${ChkFile}"
	export STARTTIME=`dtx`
	export ENDTIME=
	JobStage "CHECKING"
	# Set max to 20 hours
	typeset -i MAXCOUNT=1200
	typeset -i CheckCount=0

	WAITING_FILE="${PREVIOUS_LOAD}"
	echo "`dtx` Checking Previous day run: ${WAITING_FILE}" | tee -a ${HznLOG}

	until [ -f ${WAITING_FILE} ]
	do
		# Wait 1 minutes
		echo "`dtx` Still Waiting for Previous day file:  ${WAITING_FILE}" | tee -a ${HznLOG}
		sleep 60
		CheckCount=CheckCount+1
		if (( CheckCount > MAXCOUNT )); then
			echo "${WAITING_FILE} Not Found After ${CheckCount} waits" | tee -a ${HznLOG}
			export JOB_INFO="CHECK - Previous day's job (${PREVIOUS_LOAD}) is still incomplete!!"
			# add 12 hrs
			MAXCOUNT=MAXCOUNT+720
		fi
	done
	echo "`dtx` ${WAITING_FILE} - FILE FOUND... Moving on..." | tee -a ${HznLOG}

	MAXCOUNT=1200
	CheckCount=0
	echo " End CHECK_PREVDAY-----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: LoadTable
# Purpose : Load the Host Extract file into the Database.
# Usage   : LoadTable <datafile> <tablename> <bad file> <discard file>
###########################################################################
function LoadTable
{
	echo " Entered LoadTable-----------------------------------------------------" | tee -a ${HznLOG}
	Datafile=`basename ${1}`
	DatafileOnly=`echo ${Datafile} | cut -f 1 -d . `
	Tablename=${2}
	export JOB_INFO="LoadTable"

	#DATA_FILE=${HZN_DATA}/${DatafileOnly}.dat
	#BAD_FILE=${HZN_DATA}/${DatafileOnly}.bad
	#DISCARD_FILE=${HZN_DATA}/${DatafileOnly}.dis
        DATA_FILE=$1
        BAD_FILE=$3
        DISCARD_FILE=$4
	IN_FNUM=$5

	JobStage "LOADING RECORDS." $IN_FNUM

	CTLFILE="${HORIZON_CTL}/${HznCTL}"

	#export Bcplog=${LOGDIR}/bcp_${Tablename}${MKT}_$$.log
	if [[ "$IN_FNUM" = "" ]]; then
		typeset Bcplog=${LOGDIR}/bcp_${DatafileOnly}.log
		typeset Lsflog=${LOGDIR}/lsf_${DatafileOnly}.log
	else
		typeset Bcplog=${LOGDIR}/bcp_${DatafileOnly}_$5.log
		typeset Lsflog=${LOGDIR}/lsf_${DatafileOnly}_$5.log
	fi
	echo " Entered LoadTable--Datafile: ${1} ------------------" | tee -a ${HznLOG}
	echo " Entered LoadTable--Tablename: ${Tablename} ------------------" | tee -a ${HznLOG}
	echo " LoadTable--DatafileOnly: ${DatafileOnly} ------------------" | tee -a ${HznLOG}
	echo " LoadTable--BadFile: ${BAD_FILE} ------------------" | tee -a ${HznLOG}
	echo " LoadTable--DiscardFile: ${DISCARD_FILE} ------------------" | tee -a ${HznLOG}
	echo " LoadTable--Bcplog: ${Bcplog} ------------------" | tee -a ${HznLOG}
	echo " LoadTable--CTLFILE: ${CTLFILE} ------------------" | tee -a ${HznLOG}
	echo "LoadTable - HORIZON_CTL: ${HORIZON_CTL} " |tee -a ${HznLOG}


	echo "LoadTable - HZN_CTL: ${HZN_CTL} " |tee -a ${HznLOG}


	echo "`dtx` LOADING ${Datafile} into ${COMM_DBASE}..${Tablename}" | tee -a ${HznLOG}
	until [ -s ${CTLDIR}/${HznCTL} ]
	do
		echo -e "`dtx` Waiting for file ${CTLDIR}/${HznCTL} to flush...." | tee -a ${HznLOG}
		sleep 5
	done
	until [ -s ${DATA_FILE} ]
	do
		echo -e "`dtx` Waiting for file $DATA_FILE to flush...." | tee -a ${HznLOG}
		sleep 5
	done

	SQLLOADCMD="sqlldr userid=${COMM_DBUSER}@${COMM_SERVER}/${COMM_DBPASS} "
	SQLLOADCMD="${SQLLOADCMD} control=${CTLFILE} data=${DATA_FILE} "
	SQLLOADCMD="${SQLLOADCMD} log=${Bcplog} bad=${BAD_FILE} discard=${DISCARD_FILE}"
	SQLLOADCMD="${SQLLOADCMD}  rows=1000 bindsize=12000000 readsize=12000000 "

        SECURE_STR=" control=${CTLFILE} data=${DATA_FILE} "
        SECURE_STR="${SECURE_STR} log=${Bcplog} bad=${BAD_FILE} discard=${DISCARD_FILE}"
        SECURE_STR="${SECURE_STR}  rows=1000 bindsize=12000000 readsize=12000000 "

	SECURE_STR="sqlldr [userid/password not shown] ${SECURE_STR}"

	echo "--------------------SQL loader command------------------" | tee -a ${HznLOG}
		echo "${SECURE_STR}" | tee -a ${HznLOG}
	echo "--------------------end SQL loader command------------------" | tee -a ${HznLOG}

        $SQLLOADCMD  | tee -a ${HznLOG}

	if [[ "$IN_FNUM" = "" ]]; then
               echo "Line 316 take out lsfwait"  | tee -a ${HznLOG}
               ##lsfwait "LOAD_$Tablename"
		until [ -s ${Bcplog} ]
		do
			echo -e "`dtx` Waiting for file $Bcplog to flush...." | tee -a ${HznLOG}
			sleep 5
		done
		CheckBcpLog $Bcplog
	else
		sleep 1
	fi

	#--------------Change permissions on the bad files so sebsequent users can remove & create new
	#	------------ bad & error files:
	#chmod 755 "$HORIZON_DATA/$FEED_TYPE/${Tablename}*"

	#CheckBcpExit
	#rm -f ${LOADINPROGRESS}
	echo " End LoadTable-----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: DELETETRANS
# Purpose : Deletes all rows from the agent transactions table.
#         : We have to use market code also since the data that we'll be reloading
#         : will be all data for a market code (even if it's locations_key has
#         : been changed to a different location because of cross-market activity).
#         : Since we're using market code to delete direct_transactions, we have to
#         : include the market specification in the maps table because of referential
#         : integrity between the two tables.
# Usage   : DELETETRANS
###########################################################################
function DELETETRANS
{
	echo " Entered DELETETRANS-----------------------------------------------------" | tee -a ${HznLOG}
	echo "The DELETETRANS section" | tee -a ${HznLOG}
	export JOB_INFO="DELETETRANS - ${1}"
	export STARTTIME=`dtx`
	export ENDTIME=
        RetNbrOfRecsDeleted=0
	JobStage "DELETING RECORDS."
	SQLCMD=${DATADIR}/sqlcommanddel${MKT}${FEED_TYPE}_${SERVER}_$$.sql
	rm -f ${DELDONE}
	#touch ${LOADINPROGRESS}

	TRANTABLE=${1}
	FEED=${2}
	echo "`dtx` DELETING from ${COMM_SERVER} ${COMM_DBASE}..${TRANTABLE} for Month ${PROCESSMONTH} Year ${PROCESSYEAR} " | tee -a ${HznLOG}



          export MARKET_PARTITION="N"
          export MARKET_FIELD=
          export MARKET_DATAFILE="N"

          if [[ "$FEED_TYPE" = "tlg_srvarea" || "$FEED_TYPE" = "tlg_srvarea_mob" ]]; then
               export MARKET_PARTITION="Y"

             if [[ "$FEED_TYPE" = "tlg_srvarea" ]]; then
                export MARKET_FIELD="MARKET"
             else
                export MARKET_FIELD="BILL_MKT_CODE"
             fi

             if [[ -s "$DATA_FILE" ]]; then
               export MARKET_DATAFILE="Y"
             else
               echo "FILE IS EMPTY FOR MARKET TABLE WON'T BE TRUNACTED"
             fi

          fi


	if [[ "$TRUNC_TABLE" = "N" ]]; then
		echo "${DELETE_CLAUSE} ; " | tee -a ${HznLOG}
		echo "${DELETE_CLAUSE} ; " > ${SQLCMD}
		echo "exit; " >> ${SQLCMD}
		until [ -s ${SQLCMD} ]
		do
			echo -e "`dtx` Waiting for file $SQLCMD to flush...." | tee -a ${HznLOG}
			sleep 5
		done
		echo "---------------SQLCMD---------------" | tee -a ${HznLOG}
		cat ${SQLCMD} | tee -a ${HznLOG}
		echo "---------------end SQLCMD---------------" | tee -a ${HznLOG}
		${SQLSTART} @${SQLCMD} > ${SQLLOG}
		rm -f ${SQLCMD}

	else
             if [[ "$MARKET_PARTITION" = "N" ]]; then
		typeset -i TMPMONTHSTR=$PROCESSMONTH

                echo "CHECKING FOR PROCESSMONTH AND PROCESSYEAR THEY ARE GONE"
                echo $PROCESSMONTH
                echo $PROCESSYEAR

		SQLSTR="set heading off pagesize 0 verify off feedback off
		select count(*) from $TABLENAME where month=$PROCESSMONTH and year=$PROCESSYEAR;
		exit;"

		echo -e "$SQLSTR" | tee -a ${HznLOG}

		TBLCOUNT=$(echo -e "$SQLSTR" | $SQLSTART )
		echo -e "$TBLCOUNT rows deleted" > $SQLLOG

		SQL="alter table ${TABLENAME} truncate partition P${PROCESSYEAR}_${TMPMONTHSTR} update indexes;
		commit;
		exit; "
		echo -e "$SQL" | tee -a ${HznLOG}
		echo -e "${SQL}" | ${SQLSTART} >> $SQLLOG
             else

		SQLSTR="set heading off pagesize 0 verify off feedback off
		select count(*) from $TABLENAME where $MARKET_FIELD = '${MKT}';
		exit;"

		echo -e "$SQLSTR" | tee -a ${HznLOG}

		TBLCOUNT=$(echo -e "$SQLSTR" | $SQLSTART )
		echo -e "$TBLCOUNT rows deleted" > $SQLLOG
 
                if [[ "$MARKET_DATAFILE" = "Y" ]] then 

		SQL="alter table ${TABLENAME} truncate partition ${MKT}  update indexes;
		commit;
		exit; "
		echo -e "$SQL" | tee -a ${HznLOG}
		echo -e "${SQL}" | ${SQLSTART} >> $SQLLOG
               
                fi                

             fi

	fi

        if [[ "$FEED_TYPE" = "ericsson_ml" && -n ${RETENTION_CLAUSE} ]]; then
                echo "${RETENTION_CLAUSE} ; " > ${SQLCMD}
                echo "exit; " >> ${SQLCMD}
                until [ -s ${SQLCMD} ]
                  do
                    echo -e "`dtx` Waiting for file $SQLCMD to flush...." | tee -a ${HznLOG}
                    sleep 5
                  done
                echo "---------------SQLCMD---------------" | tee -a ${HznLOG}
                cat ${SQLCMD} | tee -a ${HznLOG}
                echo "---------------end SQLCMD---------------" | tee -a ${HznLOG}
                ${SQLSTART} @${SQLCMD} > ${RETENSQLLOG}
                rm -f ${SQLCMD}
		RecsDelete=`egrep "row[s]* deleted" ${RETENSQLLOG}`
		export RetNbrOfRecsDeleted=`echo ${RecsDelete} | cut -f1 -d" " -s`
	        echo "Retention NbrOfRecsDeleted: ${RetNbrOfRecsDeleted}" | tee -a ${HznLOG}
	fi

	if [[ "$FEED_TYPE" = "cpc" || "$FEED_TYPE" = "tlg_ip_definition" || "$FEED_TYPE" = "ccpm_contract_ref_trans" ]]; then
		echo "NbrOfRecsDeleted: Table truncated" | tee -a ${HznLOG}
		NbrOfRecsDeleted=0
	else
		RecsDelete=`egrep "row[s]* deleted" ${SQLLOG}`
		export NbrOfRecsDeleted=`echo ${RecsDelete} | cut -f1 -d" " -s`
	fi
	echo "NbrOfRecsDeleted: ${NbrOfRecsDeleted}" | tee -a ${HznLOG}

        NbrOfRecsDeleted=$(($NbrOfRecsDeleted+$RetNbrOfRecsDeleted))


	CheckSqlLog $SQLLOG

	touch ${DELDONE}

	echo " End DELETETRANS-----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: RetentionCleanup 
# Purpose : Deletes records older than a certain date.
# Usage   : RetentionCleanup 
###########################################################################
function RetentionCleanup 
{
	echo " Entered RetentionCleanup-----------------------------------------------------" | tee -a ${HznLOG}
	export STARTTIME=`dtx`
	export ENDTIME=
	JobStage "RETENTION CLEANUP."
	SQLCMD=${DATADIR}/sqlcommandreten${MKT}${FEED_TYPE}_${SERVER}_$$.sql
	rm -f ${DELDONE}

	TRANTABLE=${1}
	FEED=${2}
	echo "`dtx` DELETING from ${COMM_SERVER} ${COMM_DBASE}..${TRANTABLE} for Month ${PROCESSMONTH} Year ${PROCESSYEAR} " | tee -a ${HznLOG}

        if [[ "$FEED_TYPE" = "product_upgrade" ]]; then
           echo "${DELETE_CLAUSE} ; " > ${SQLCMD}
           echo "exit; " >> ${SQLCMD}
           until [ -s ${SQLCMD} ]
             do
               echo -e "`dtx` Waiting for file $SQLCMD to flush...." | tee -a ${HznLOG}
               sleep 5
             done
           echo "---------------SQLCMD---------------" | tee -a ${HznLOG}
           cat ${SQLCMD} | tee -a ${HznLOG}
           echo "---------------end SQLCMD---------------" | tee -a ${HznLOG}
           ${SQLSTART} @${SQLCMD} > ${SQLLOG}
           rm -f ${SQLCMD}
	fi

        RecsDelete=`egrep "row[s]* deleted" ${SQLLOG}`
        export NbrOfRecsDeleted=`echo ${RecsDelete} | cut -f1 -d" " -s`
	echo "NbrOfRecsDeleted: ${NbrOfRecsDeleted}" | tee -a ${HznLOG}

	CheckSqlLog $SQLLOG

	touch ${DELDONE}

	echo " End RetentionCleanup-----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: CheckLoadInProgress
# Purpose : Checks to see if a process is running which could cause deadlocks.
# Usage   : CheckLoadInProgress
###########################################################################
function CheckLoadInProgress
{
	echo " Entered CheckLoadInProgress-----------------------------------------------------" | tee -a ${HznLOG}
	JobStage "QUEUED"
	#----------------------------------------------------------------------------------------------------
	#   Make sure other markets are not currently loading.
	#   Determine which processes to wait for. (to prevent table locking)
	#----------------------------------------------------------------------------------------------------
	echo "`dtx` Looking for ${LOADINPROGRESS} files" | tee -a ${HznLOG}
	until [ ! -f ${LOADINPROGRESS} ]
	do
		# Wait 1 minutes
		echo "`dtx` ${MKT} is being loaded. Waiting for ${LOADINPROGRESS} to finish loading ..." | tee -a ${HznLOG}
		sleep 60
	done
	echo "`dtx` NO LOADINPROGRESS INDICATOR FILES FOUND... Continuing to next section..." | tee -a ${HznLOG}
	#----------------------------------------------------------------------------------------------------

	JobStage "RUNNING"
	echo " End CheckLoadInProgress-----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: LOAD
# Purpose : Executes functions to load data into the database table(s).
# Usage   : LOAD
###########################################################################
function LOAD
{
if [[ "$FEED_TYPE" = "dc_tlg_update" || "$FEED_TYPE" = "ccpm_inst_tlg_update" || "$FEED_TYPE" = "rc_tlg_update" || "$FEED_TYPE" = "dc_bid_update"
|| "$FEED_TYPE" = "nci" || "$FEED_TYPE" = "hznrep_daily_upd"  || "$FEED_TYPE" = "cross_upgrade" || "$FEED_TYPE" = "product_upgrade"
|| "$FEED_TYPE" = "pos_tlg_update" || "$FEED_TYPE" = "sweep_tlg_srvchg"
||"$FEED_TYPE" = "ericsson_tlg_update" ||"$FEED_TYPE" = "inst_tlg_update" ||"$FEED_TYPE" = "ccpm_inst_tlg_catchup" ||"$FEED_TYPE" = "tlg_daily_device_id_upd" ||"$FEED_TYPE" = "ccpm_wline_trans_process"
||"$FEED_TYPE" = "hznrep_ccpm_wireless" ]]; then
        echo " Entered LOAD $FEED_TYPE -----------------------------------------------------" | tee -a ${HznLOG}
        echo "The LOAD $FEED_TYPE section" | tee -a ${HznLOG}
        export JOB_INFO="LOAD- Load $FEED_TYPE"
        typeset -i DELETED_COUNT=0
        typeset -i ADDED_COUNT=0

        export STARTTIME=`dtx`
        export HznDATAINP="DATA from $FEED_TYPE"

	if [ -f ${LOADCOMPLETE} ]; then
		rm -f ${LOADCOMPLETE}
	fi

        JobStage "STARTING"
#---------------DataReady-------------
        DataReady "STARTING"
#---------------end DataReady-------------

	case ${FEED_TYPE} in
	  dc_tlg_update)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting dc_tlg_update.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/dc_tlg_update.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR | tee -a ${HznLOG}
       		echo "nohup $HZN_BIN/analyze_table.sh -tDC_TLG_DAILY_HIST -e$RUNENV > ${HZN_LOG}/analyze_DC_TLG_DAILY_HIST.log 2>&1" | tee -a ${HznLOG}
       		nohup $HZN_BIN/analyze_table.sh -tDC_TLG_DAILY_HIST -e$RUNENV > ${HZN_LOG}/analyze_DC_TLG_DAILY_HIST.log 2>&1
		;;
	  ccpm_inst_tlg_update)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting ccpm_inst_tlg_update.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/ccpm_inst_tlg_update.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR | tee -a ${HznLOG}
       		echo "nohup $HZN_BIN/analyze_table.sh -tCCPM_ENB_TLG_DAILY_UPD_HIST -e$RUNENV > ${HZN_LOG}/analyze_CCPM_ENB_TLG_DAILY_UPD_HIST.log 2>&1" | tee -a ${HznLOG}
       		nohup $HZN_BIN/analyze_table.sh -tCCPM_ENB_TLG_DAILY_UPD_HIST -e$RUNENV > ${HZN_LOG}/analyze_CCPM_ENB_TLG_DAILY_UPD_HIST.log 2>&1
		;;
	  tlg_daily_device_id_upd)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting tlg_daily_device_id_upd.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/tlg_daily_device_id_upd.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR | tee -a ${HznLOG}
		;;
	  ccpm_wline_trans_process)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting ccpm_wline_trans_process.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/ccpm_wline_trans_process.sql $PROCESSYEAR $PROCESSMONTH  | tee -a ${HznLOG}
		;;
	  rc_tlg_update)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting rc_tlg_update.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/rc_tlg_update.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR | tee -a ${HznLOG}
		;;
	  dc_bid_update)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting dc_bid_update.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/dc_bid_update.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR | tee -a ${HznLOG}
       		echo "nohup $HZN_BIN/analyze_table.sh -tDC_BID_SRVCHG_HIST -e$RUNENV > ${HZN_LOG}/analyze_DC_BID_SRVCHG_HIST.log 2>&1" | tee -a ${HznLOG}
       		nohup $HZN_BIN/analyze_table.sh -tDC_BID_SRVCHG_HIST -e$RUNENV > ${HZN_LOG}/analyze_DC_BID_SRVCHG_HIST.log 2>&1
		;;
	  nci)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_PROCESS_NCI.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/nci.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		;;
	  hznrep_daily_upd)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_HZNREP_DAILY_UPD.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/hznrep_daily_upd.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
       		echo "nohup $HZN_BIN/analyze_table.sh -tERICSSON_ML_SNAPSHOT_HIST -e$RUNENV > ${HZN_LOG}/analyze_ERICSSON_ML_SNAPSHOT_HIST.log 2>&1" | tee -a ${HznLOG}
       		nohup $HZN_BIN/analyze_table.sh -tERICSSON_ML_SNAPSHOT_HIST -e$RUNENV > ${HZN_LOG}/analyze_ERICSSON_ML_SNAPSHOT_HIST.log 2>&1
		;;
	  hznrep_ccpm_wireless)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_HZNREP_CCPM_WIRELESS.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/hznrep_ccpm_wireless.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		echo "$HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$TABLENAME_$FEED_TYPE.log 2>&1" | tee -a ${HznLOG}
		$HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$TABLENAME_$FEED_TYPE.log 2>&1
		;;
	  cross_upgrade)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_CROSSUPG.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/cross_upg.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		;;
	  pos_tlg_update)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_POS_TLG_UPDATE.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/pos_tlg_update.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		;;
	  ericsson_tlg_update)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_ERICSSON_TLG_UPDATE.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/ericsson_tlg_update.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		;;

	  inst_tlg_update)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_INST_INFO_TLG_UPDATE.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/inst_tlg_update.sql $PROCESSYEAR $PROCESSMONTH | tee -a ${HznLOG}
		;;
	  ccpm_inst_tlg_catchup)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting ccpm_inst_tlg_catchup.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/ccpm_inst_tlg_catchup.sql $PROCESSYEAR $PROCESSMONTH | tee -a ${HznLOG}
		;;
	  sweep_tlg_srvchg)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_SWEEP_TLG_SRVCHG_TRANS.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/sweep_tlg_srvchg.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		;;
	  product_upgrade)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_PRODUCT_UPG.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/product_upg.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		;;
        esac

	CheckBcpLog ${HznLOG}

       export JOB_INFO="LOAD $FEED_TYPE SUCCESSFULLY COMPLETED - process id# ${PROCESSID}"
        export ENDTIME=`dtx`
        JobStage "COMPLETE"
#---------------DataReady-------------
        DataReady "COMPLETE"
#---------------end DataReady-------------
	if [ -z ${LOADCOMPLETE} ]; then
		echo "`dtx` LOADCOMPLETE not set (${LOADCOMPLETE})." | tee -a ${HznLOG}
	else
		echo "`dtx` Creating complete file - ${LOADCOMPLETE}" | tee -a ${HznLOG}
		touch ${LOADCOMPLETE}
	fi

        echo " End LOAD $FEED_TYPE -----------------------------------------------------" | tee -a ${HznLOG}

elif [[ "$FEED_TYPE" = "calc_ban" ]]; then
        echo " Entered LOAD BAN-----------------------------------------------------" | tee -a ${HznLOG}
        echo "The LOAD BAN section" | tee -a ${HznLOG}
        export JOB_INFO="LOAD- Load BAN daily Trans"
        typeset -i DELETED_COUNT=0
        typeset -i ADDED_COUNT=0

        export STARTTIME=`dtx`
        export TABLENAME="ban_daily_trans"
        export HznDATAINP="DATA from BID srvchg/cancels AND MANUAL Trans tables"

        JobStage "STARTING"
#---------------DataReady-------------
        DataReady "STARTING"
#---------------end DataReady-------------

	if [[ -z $PROCESSDAY ]]; then
		BANDAY=0
	else
		BANDAY=$PROCESSDAY
	fi
        SQLRESULT=`sqlplus -S $COMM_DBUSER/$COMM_DBPASS@$COMM_DBASE <<EOF

        set serveroutput on

        DECLARE
          YEAR_IN NUMBER;
          MONTH_IN NUMBER;
          DAY_IN NUMBER;
          ATTUID_IN VARCHAR2(30);
          MKT_CODE_IN VARCHAR2(50);
          ACTION_TYPE_IN VARCHAR2(3);
          RESULT_OUT VARCHAR2(1000);

        BEGIN
          YEAR_IN := $PROCESSYEAR;
          MONTH_IN := $PROCESSMONTH;
          DAY_IN := $BANDAY;
          ATTUID_IN := NULL;
          MKT_CODE_IN := NULL;
          ACTION_TYPE_IN := NULL;
          RESULT_OUT := NULL;
          HZNREP.BAN_DAILY_TRANS_CALC ( YEAR_IN, MONTH_IN, DAY_IN, ATTUID_IN, MKT_CODE_IN, ACTION_TYPE_IN, RESULT_OUT );
          COMMIT;
        END;
        /
       exit;
       EOF`


       echo "THE RESULT for LOAD BAN_DAILY_TRANS is $SQLRESULT" |  tee -a ${HznLOG}

       SQLCMD="set sqlblanklines on heading off pagesize 0 feedback off
        select substr(REGEXP_SUBSTR('$SQLRESULT','DELETED TOTAL=[[:digit:]]+'),15) as total_deleted from dual;
        exit;"
        echo -e $SQLCMD
        echo  "$SQLCMD" | $SQLSTART |read DELETED_COUNT
        echo -e "Daily Ban Trans:DELETED_COUNT=$DELETED_COUNT" |  tee -a ${HznLOG}
        export  NbrOfRecsDeleted=$DELETED_COUNT

       SQLCMD1="set  sqlblanklines on heading off pagesize 0 feedback off
        select substr(REGEXP_SUBSTR('$SQLRESULT','ADDED TOTAL=[[:digit:]]+'),13) as total_added from dual;
        exit;"
        echo -e $SQLCMD1
        echo  "$SQLCMD1" | $SQLSTART |read ADDED_COUNT
        echo -e "Daily Ban Trans:ADDED_COUNT=$ADDED_COUNT" | tee -a ${HznLOG}
        export  RecLoaded=$ADDED_COUNT

	CheckBcpLog ${HznLOG}

       echo "nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$TABLENAME_$FEED_TYPE.log 2>&1" | tee -a ${HznLOG}
       nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$TABLENAME_$FEED_TYPE.log 2>&1

       export JOB_INFO="LOAD BAN TRANS SUCCESSFULLY COMPLETED - process id# ${PROCESSID}"
        export ENDTIME=`dtx`
        JobStage "COMPLETE"
#---------------DataReady-------------
        DataReady "COMPLETE"
#---------------end DataReady-------------
	if [ -z ${LOADCOMPLETE} ]; then
		echo "`dtx` LOADCOMPLETE not set (${LOADCOMPLETE})." | tee -a ${HznLOG}
	else
		echo "`dtx` Creating complete file - ${LOADCOMPLETE}" | tee -a ${HznLOG}
		touch ${LOADCOMPLETE}
	fi

        echo " End LOAD BAN -----------------------------------------------------" | tee -a ${HznLOG}
else
	echo "Entered LOAD-----------------------------------------------------" | tee -a ${HznLOG}
	echo "The LOAD section" | tee -a ${HznLOG}
	export JOB_INFO="LOAD - ${HznDATAINP}"
	EndFile=`basename ${HznDATAINP}`
	export JOB_INFO="LOOK - ~/data/${FEED_TYPE}/${EndFile}"
	export STARTTIME=`dtx`
	export ENDTIME=
	JobStage "STARTING"
#---------------DataReady-------------
	DataReady "STARTING"
#---------------end DataReady-------------

	if [ -f ${LOADCOMPLETE} ]; then
		rm -f ${LOADCOMPLETE}
	fi

	CheckLoadInProgress
	touch ${LOADINPROGRESS}
	echo "Performing the MONTHLY load..." | tee -a ${HznLOG}

	if [ ! -z ${DELETE_CLAUSE} ]; then
		echo "About to delete Transactions..." | tee -a ${HznLOG}
		DELETETRANS ${TABLENAME}
	fi

	if [[ "$FEED_TYPE" = "oracle" ]]; then
		echo "==> UPDATE_SEQ: " ${UPDATE_SEQ} | tee -a ${HznLOG}
        	if [[ "$UPDATE_SEQ" = "Y" ]]; then
			echo "`dtx` Altering SEQ_ORA_SALES_ORDERS for oracle Feed Type after DELETETRANS before LoadTable..." | tee -a ${HznLOG}

			export EXTRACTSQLCMD=${DATADIR}/extractSqlCommand${FEED_TYPE}_${SERVER}_$$.sql
			export EXTRACTSPOOLFILE=${DATADIR}/extractSpoolFile${FEED_TYPE}_${SERVER}_$$.lst

			export ExtractHznSql=ext_seq_ora_sales_orders.sql
			echo "spool ${EXTRACTSPOOLFILE} ; " > ${EXTRACTSQLCMD}
			echo "cat $HORIZON_BIN/$ExtractHznSql >> ${EXTRACTSQLCMD}" | tee -a ${HznLOG}
			cat $HORIZON_BIN/$ExtractHznSql >> ${EXTRACTSQLCMD}
			echo -e "======== EXTRACTSQLCMD ========" | tee -a ${HznLOG}
			cat ${EXTRACTSQLCMD} | tee -a ${HznLOG}
			echo -e "======== END EXTRACTSQLCMD ========" | tee -a ${HznLOG}

			echo -e "" | tee -a ${HznLOG}
			echo -e "=================================================================================" | tee -a ${HznLOG}
			echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting Max Extract .... " | tee -a ${HznLOG}
			echo -e "=================================================================================" | tee -a ${HznLOG}
			echo -e "" | tee -a ${HznLOG}

			$SQLSTART @${EXTRACTSQLCMD}

			echo "=================================================================================" | tee -a ${HznLOG}
			echo "Extract Max Output: " | tee -a ${HznLOG}
			cat ${EXTRACTSPOOLFILE} | tee -a ${HznLOG}
			echo "=================================================================================" | tee -a ${HznLOG}

			typeset -i NextSeqNbr
			export ExtractROW=`head -1 ${EXTRACTSPOOLFILE}`
			echo "==> ExtractROW: " $ExtractROW | tee -a ${HznLOG}
			export NextSeqNbr=`echo $ExtractROW| cut -f1`
			echo "==> NextSeqNbr: " $NextSeqNbr | tee -a ${HznLOG}

			export RESETSQLCMD=${DATADIR}/resetSqlCommand${FEED_TYPE}_${SERVER}_$$.sql
			export RESETSPOOLFILE=${DATADIR}/resetSpoolFile${FEED_TYPE}_${SERVER}_$$.lst
			export ResetHznSql=reset_seq_ora_sales_orders.sql
			echo "spool ${RESETSPOOLFILE} ; " > ${RESETSQLCMD}
			echo "cat $HORIZON_BIN/$ResetHznSql >> ${RESETSQLCMD}" | tee -a ${HznLOG}
			cat $HORIZON_BIN/$ResetHznSql >> ${RESETSQLCMD}
			echo -e "======== RESETSQLCMD ========" | tee -a ${HznLOG}
			cat ${RESETSQLCMD} | tee -a ${HznLOG}
			echo -e "======== END RESETSQLCMD ========" | tee -a ${HznLOG}

			echo -e "" | tee -a ${HznLOG}
			echo -e "=================================================================================" | tee -a ${HznLOG}
			echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting Alter Sequence Reset .... " | tee -a ${HznLOG}
			echo -e "=================================================================================" | tee -a ${HznLOG}
			echo -e "" | tee -a ${HznLOG}

			$SQLSTART @$RESETSQLCMD $NextSeqNbr

			echo "=================================================================================" | tee -a ${HznLOG}
			echo "Alter Sequence Output: " | tee -a ${HznLOG}
			cat ${RESETSPOOLFILE} | tee -a ${HznLOG}
			echo "=================================================================================" | tee -a ${HznLOG}
		fi
	fi

	if [ -f $HznDATAINP ]
	then
		echo "$HznDATAINP file found"
		if [ -s $HznDATAINP ]
		then
			echo "$HznDATAINP file has data"|tee -a ${HznLOG}

        		if [[ "$FEED_TYPE" = "crft_care" || "$FEED_TYPE" = "crft_retail" || "$FEED_TYPE" = "tacrft_cust_survey" ]]; then
           			# Handle CRFT file pre-processing...
           			# Input file name: $HznDATAINP

           			# If I only have 3 records (i.e. two HEADER records, plus one TRAILER record... then the file has no data to load...
           			# ensure that the file has UNIX line-endings...
           			echo "`dtx` CRFT File - Ensure that the input file ( ${HznDATAINP} ) has UNIX line-endings..." | tee -a ${HznLOG}
           			dos2unix $HznDATAINP

           			# validate the CRFT Header & Trailer records...
           			export HznDATAINP_unvalidated=$HznDATAINP
           			CRFT_File_Validation.pl $HznDATAINP $HznDATAWrk
           			RtnCode=$?
           			if [[ $RtnCode -ne 0 ]]; then
              				echo "`dtx` CRFT File - ERROR validating file ( ${HznDATAINP} )..." | tee -a ${HznLOG}
              				# What do I need to do here to abort the load processing...
                            echo "Problem during TACRFT Header and Trailer Validation" | tee -a ${HznLOG}
                            echo "ERROR Loading ${TABLENAME} for F:${FEED_TYPE}, Y:${PROCESSYEAR}, M:${PROCESSMONTH}, D:${PROCESSDAY}, -D${DELETE_TRAN}." |tee -a ${HznLOG}
                            Error_Exit 99
           			else
              				export HznDATAINP=$HznDATAWrk
              				echo "`dtx` CRFT File - The work file becomes the input file ( ${HznDATAINP} )..." | tee -a ${HznLOG}
           			fi
				if [ -s $HznDATAINP ]
				then
              				echo "`dtx` CRFT File - ${HznDATAINP} is NOT EMPTY..." | tee -a ${HznLOG}
					FILE_EMPTY=N
				else
              				echo "`dtx` CRFT File - ${HznDATAINP} IS EMPTY..." | tee -a ${HznLOG}
					FILE_EMPTY=Y
				fi
			else
				FILE_EMPTY=N
        		fi
        		if [[ "$FEED_TYPE" = "ccpm_contract_trans" || "$FEED_TYPE" = "ccpm_contract_ref_trans" ]]; then
           			# Handle Contract file pre-processing...
           			# Input file name: $HznDATAINP

           			# If I only have 2 records (i.e. one HEADER records, plus one TRAILER record... then the file has no data to load...
           			# ensure that the file has UNIX line-endings...
           			echo "`dtx` Contract File - Ensure that the input file ( ${HznDATAINP} ) has UNIX line-endings..." | tee -a ${HznLOG}
           			dos2unix $HznDATAINP

           			# validate the Contract Header & Trailer records...
           			export HznDATAINP_unvalidated=$HznDATAINP
           			Contract_File_Validation.pl $HznDATAINP $HznDATAWrk
           			RtnCode=$?
           			if [[ $RtnCode -ne 0 ]]; then
              				echo "`dtx` Contract File - ERROR validating file ( ${HznDATAINP} )..." | tee -a ${HznLOG}
              				# What do I need to do here to abort the load processing...
                                        echo "Problem during Contract Header and Trailer Validation" | tee -a ${HznLOG}
                                        echo "ERROR Loading ${TABLENAME} for F:${FEED_TYPE}, Y:${PROCESSYEAR}, M:${PROCESSMONTH}, D:${PROCESSDAY}, -D${DELETE_TRAN}." |tee -a ${HznLOG}
                                        Error_Exit 99
           			else
              				export HznDATAINP=$HznDATAWrk
              				echo "`dtx` Contract File - The work file becomes the input file ( ${HznDATAINP} )..." | tee -a ${HznLOG}
           			fi
				if [ -s $HznDATAINP ]
				then
              				echo "`dtx` Contract File - ${HznDATAINP} is NOT EMPTY..." | tee -a ${HznLOG}
					FILE_EMPTY=N
				else
              				echo "`dtx` Contract File - ${HznDATAINP} IS EMPTY..." | tee -a ${HznLOG}
					FILE_EMPTY=Y
				fi
        		fi
				
			if [[ "$FEED_TYPE" = "biz_ipbb_flipping" ]]; then
				# Handle IPBB Flipping file header and footer validation...
				# Input file name: $HznDATAINP

				# If I only have 2 records (i.e. one HEADER records, plus one TRAILER record... then the file has no data to load...
				# ensure that the file has UNIX line-endings...
				echo "`dtx` IPBB Filipping File - Ensure that the input file ( ${HznDATAINP} ) has UNIX line-endings..." | tee -a ${HznLOG}
				dos2unix $HznDATAINP

				# validate the IPBB Flipping Header & Trailer records...
				export HznDATAINP_unvalidated=$HznDATAINP
				Biz_IPBB_Flipping_File_Validation.pl $HznDATAINP $HznDATAWrk
				RtnCode=$?
				if [[ $RtnCode -ne 0 ]]; then
					echo "`dtx` IPBB Flipping File - ERROR validating file ( ${HznDATAINP} )..." | tee -a ${HznLOG}
					# What do I need to do here to abort the load processing...
					echo "Problem during IPBB Flipping Header and Trailer Validation" | tee -a ${HznLOG}
					echo "ERROR Loading ${TABLENAME} for F:${FEED_TYPE}, Y:${PROCESSYEAR}, M:${PROCESSMONTH}, D:${PROCESSDAY}, -D${DELETE_TRAN}." |tee -a ${HznLOG}
					Error_Exit 99
				else
					export HznDATAINP=$HznDATAWrk
					echo "`dtx` IPBB Flipping File - The work file becomes the input file ( ${HznDATAINP} )..." | tee -a ${HznLOG}
				fi
				if [ -s $HznDATAINP ]
				then
					echo "`dtx` IPBB Flipping File - ${HznDATAINP} is NOT EMPTY..." | tee -a ${HznLOG}
					FILE_EMPTY=N
				else
					echo "`dtx` IPBB Flipping File - ${HznDATAINP} IS EMPTY..." | tee -a ${HznLOG}
					FILE_EMPTY=Y
				fi
			fi
		else
			echo "$HznDATAINP file is empty!" | tee -a ${HznLOG}
			FILE_EMPTY=Y

		fi
	fi

	if [[ "$FILE_EMPTY" = "N" ]]; then
        export ROWCOUNTINFILE=$(cat $HznDATAINP | wc -l)
        echo -e "COUNT IS $ROWCOUNTINFILE"

        if [[ "$FEED_TYPE" = "bid_srvchg" ]]; then
                echo "`dtx` Fix customer name from ${HznDATAINP}..." | tee -a ${HznLOG}
                $HORIZON_BIN/fix_bid_srvchg_file.pl ${HznDATAINP}
                echo "`dtx` Done Fixing customer name from ${HznDATAINP}..." | tee -a ${HznLOG}
        	export CHECKCOUNTINFILECN=$(cat $HznDATAINP | wc -l)
		while [[ $ROWCOUNTINFILE != $CHECKCOUNTINFILECN ]]
		do
                	echo "`dtx` Waiting customer name for ${HznDATAINP} to flush..." | tee -a ${HznLOG}
                	sleep 30
        		export CHECKCOUNTINFILECN=$(cat $HznDATAINP | wc -l)
		done
        fi

        if [[ "$FEED_TYPE" = "bid_srvchg" || "$FEED_TYPE" = "bid_wl" || "$FEED_TYPE" = "ccpm_wl" ]]; then
                echo "`dtx` Removing any TABs from ${HznDATAINP}..." | tee -a ${HznLOG}
                $HORIZON_BIN/fix_tabs.pl ${HznDATAINP}
                echo "`dtx` Done removing TABs from ${HznDATAINP}..." | tee -a ${HznLOG}
        	export CHECKCOUNTINFILE=$(cat $HznDATAINP | wc -l)
		while [[ $ROWCOUNTINFILE != $CHECKCOUNTINFILE ]]
		do
                	echo "`dtx` Waiting for ${HznDATAINP} to flush..." | tee -a ${HznLOG}
                	sleep 30
        		export CHECKCOUNTINFILE=$(cat $HznDATAINP | wc -l)
		done
        fi

        if [[ "$FEED_TYPE" = "srs_call_summ" ]]; then
           echo "`dtx` Converting with DOS2UNIX on SRS PAR Call Summary file File ${HznDATAINP}..." | tee -a ${HznLOG}
           dos2unix $HznDATAINP
	fi



        if [[ $ROWCOUNTINFILE -ge 10000 && "$FORCE_NO_SPLIT" = "N" ]]; then
                if [[ "$FEED_TYPE" = "bid_srvchg" || "$FEED_TYPE" = "bid_wl" || "$FEED_TYPE" = "ccpm_wl" || "$FEED_TYPE" = "oracle" ]]; then
                        NUMFILES=10
                        FILE_NUMBERS="a b c d e f g h i j"
                        DESTFILES=${HznDATAINP}
                        TCNT=`cat $HznDATAINP |wc -l`
                        SPLITCNT=`expr $TCNT / $NUMFILES + 1`
                        echo -e "`date '+%m/%d/%Y %H:%M:%S'` CNT=$TCNT"
                        echo -e "`date '+%m/%d/%Y %H:%M:%S'` SPLITCNT=$SPLITCNT"
                        echo -e "`date '+%m/%d/%Y %H:%M:%S'` split -l $SPLITCNT -a 1 $HznDATAINP $DESTFILES"
                        time split -l $SPLITCNT -a 1 $HznDATAINP $DESTFILES
                        #Let us limit to 26 files
                        for FNUM in $FILE_NUMBERS
                        do
                                INPUTFILE=${DESTFILES}${FNUM}
                                LoadTable ${INPUTFILE} ${TABLENAME} ${BAD_FILE}${FNUM} ${DISCARD_FILE}${FNUM} $FNUM  &
                                sleep 1
                        done

                        echo "Line 1097 replace lsfwait with wait"  | tee -a ${HznLOG}
                        wait
                   #####lsfwait "LOAD_$TABLENAME"

                        for FNUM in $FILE_NUMBERS
                        do
				tmpDatafile=`basename ${DESTFILES}${FNUM}`
				tmpDatafileOnly=`echo ${tmpDatafile} | cut -f 1 -d . `
				CheckLogName=${LOGDIR}/bcp_${tmpDatafileOnly}_$FNUM.log
                                echo "CheckBcpLog $CheckLogName"
                                CheckBcpLog $CheckLogName
				rm -rf ${DESTFILES}${FNUM}*
                        done
        	else
                	LoadTable ${HznDATAINP} ${TABLENAME} ${BAD_FILE} ${DISCARD_FILE} $NEWJOBNAME
                         echo "Line 1112 took out lsfwait" | tee -a ${HznLOG}
                         ##lsfwait "LOAD_$TABLENAME"
                fi
        else
                LoadTable ${HznDATAINP} ${TABLENAME} ${BAD_FILE} ${DISCARD_FILE} $NEWJOBNAME
               echo "Line 1117 took out lsfwait"  | tee -a ${HznLOG}
        ########lsfwait "LOAD_$TABLENAME"
        fi

	fi

	rm -f ${LOADINPROGRESS}
	echo "******Removed LOADINPROGRESS: $LOADINPROGRESS"
	#----------------------------------------
	#----------------------------------------

	if [[ "$DO_ANALYZE" = "Y" ]]; then
		if [[ "$FEED_TYPE" = "cpc" || "$FEED_TYPE" = "tlg_ip_definition" || "$FEED_TYPE" = "ccpm_contract_ref_trans" ]]; then
			echo "nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -e$RUNENV > ${HZN_LOG}/analyze_$FEED_TYPE.log 2>&1" | tee -a ${HznLOG}
			nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -e$RUNENV > ${HZN_LOG}/analyze_$FEED_TYPE.log 2>&1
		else
			echo "nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$FEED_TYPE.log 2>&1" | tee -a ${HznLOG}
			nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$FEED_TYPE.log 2>&1
		fi
	fi


	if [[ "$FEED_TYPE" = "bid_srvchg" ]]; then
		if [[ -s $HORIZON_UTILS/update_mdpp_ins.sql ]]; then
       			echo -e "Updating MDPP/Insurance for BID..." |  tee -a ${HznLOG}
			$SQLSTART @$HORIZON_UTILS/update_mdpp_ins.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR < /dev/null | tee -a ${HznLOG}
       			echo -e "Complete..." |  tee -a ${HznLOG}
		fi
		if [[ -s $HORIZON_BIN/bid_prod_family_custname_upd.sql ]]; then
       			echo -e "Updating SPI CUSTOMER_NAME in Bid Family Started..." |  tee -a ${HznLOG}
		    $SQLSTART @$HORIZON_BIN/bid_prod_family_custname_upd.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
       			echo -e "Updating SPI CUSTOMER_NAME in Bid Family Completed..." |  tee -a ${HznLOG}
		fi
	elif [[ "$FEED_TYPE" = "ccpm_wl" ]]; then
		echo "Identify and mark duplicate orders Started..." | tee -a ${HznLOG}
		$SQLSTART @$HORIZON_BIN/ccpm_dup_cleanup.sql $PROCESSYEAR $PROCESSMONTH | tee -a ${HznLOG}
		echo "Identify and mark duplicate orders Completed..." | tee -a ${HznLOG}
       			echo -e "Updating SPI CUSTOMER_NAME in Datapipe 2.0 Started..." |  tee -a ${HznLOG}
		$SQLSTART @$HORIZON_BIN/ccpm_wline_trans_custname_upd.sql $PROCESSYEAR $PROCESSMONTH | tee -a ${HznLOG}
       			echo -e "Updating SPI CUSTOMER_NAME in Datapipe 2.0 Completed..." |  tee -a ${HznLOG}
        elif [[ "$FEED_TYPE" = "tlg_daily" ]]; then
                echo "Fix DST values ..." | tee -a ${HznLOG}
                $SQLSTART @$HORIZON_BIN/sweep_dst.sql $PROCESSMONTH $PROCESSYEAR $TABLENAME $MKT | tee -a ${HznLOG}
        elif [[ "$FEED_TYPE" = "crft_retail" || "$FEED_TYPE" = "tacrft_cust_survey" ]]; then
                echo "Fix DST values ..." | tee -a ${HznLOG}
                $SQLSTART @$HORIZON_BIN/sweep_dst.sql $PROCESSMONTH $PROCESSYEAR $TABLENAME DUMMYMKT | tee -a ${HznLOG}
        elif [[ "$FEED_TYPE" = "oracle" ]]; then
                echo "Updating SPI CUSTOMER_NAME in Oracle Started ..." | tee -a ${HznLOG}
                $SQLSTART @$HORIZON_BIN/ora_sales_orders_custname_upd.sql $PROCESSYEAR $PROCESSMONTH | tee -a ${HznLOG}
                echo "Updating SPI CUSTOMER_NAME in Oracle Completed ..." | tee -a ${HznLOG}
	fi

	export JOB_INFO="LOAD SUCCESSFULLY COMPLETED - process id# ${PROCESSID}"
	export ENDTIME=`dtx`
	JobStage "COMPLETE"

#---------------DataReady-------------
	DataReady "COMPLETE"
#------------end DataReady-------------

	if [ -z ${LOADCOMPLETE} ]; then
		echo "`dtx` LOADCOMPLETE not set (${LOADCOMPLETE})." | tee -a ${HznLOG}
	else
		echo "`dtx` Creating complete file - ${LOADCOMPLETE}" | tee -a ${HznLOG}
		touch ${LOADCOMPLETE}
	fi

	echo " End LOAD-----------------------------------------------------" | tee -a ${HznLOG}
fi
}

###########################################################################
# Function: LOADFROMSTAGE
# Purpose : Executes functions to process and load data into the database table(s).
# Usage   : LOADFROMSTAGE
###########################################################################
function LOADFROMSTAGE
{
if [[ "$FEED_TYPE" = "ericsson_ml" ]]; then
        echo " Entered LOADFROMSTAGE $FEED_TYPE -----------------------------------------------------" | tee -a ${HznLOG}
        echo "The LOADFROMSTAGE $FEED_TYPE section" | tee -a ${HznLOG}
        export JOB_INFO="LOADFROMSTAGE- LoadFromStage $FEED_TYPE"
        typeset -i DELETED_COUNT=0
        typeset -i ADDED_COUNT=0

        export STARTTIME=`dtx`

	if [ -f ${LOADCOMPLETE} ]; then
		rm -f ${LOADCOMPLETE}
	fi

        JobStage "STARTING"
#---------------DataReady-------------
        DataReady "STARTING"
#---------------end DataReady-------------

	case ${FEED_TYPE} in
	  ericsson_ml)
		echo -e "" | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting SP_ERICSSON_ML_LOAD_FROM_STAGE.... " | tee -a ${HznLOG}
		echo -e "=================================================================================" | tee -a ${HznLOG}
		echo -e "" | tee -a ${HznLOG}

		$SQLSTART @$HORIZON_BIN/ericsson_ml_load_from_stage.sql $PROCESSYEAR $PROCESSMONTH $PROCESSDAY | tee -a ${HznLOG}
		;;
        esac

	CheckBcpLog ${HznLOG}

       export JOB_INFO="LOADFROMSTAGE $FEED_TYPE SUCCESSFULLY COMPLETED - process id# ${PROCESSID}"
        export ENDTIME=`dtx`
        JobStage "COMPLETE"
#---------------DataReady-------------
        DataReady "COMPLETE"
#---------------end DataReady-------------
	if [ -z ${LOADCOMPLETE} ]; then
		echo "`dtx` LOADCOMPLETE not set (${LOADCOMPLETE})." | tee -a ${HznLOG}
	else
		echo "`dtx` Creating complete file - ${LOADCOMPLETE}" | tee -a ${HznLOG}
		touch ${LOADCOMPLETE}
	fi

        echo " End LOADFROMSTAGE $FEED_TYPE -----------------------------------------------------" | tee -a ${HznLOG}
else
	echo "Invalid feed type [${FEED_TYPE}] not supported in LOADFROMSTAGE"| tee -a ${HznLOG}
	exit 10
fi
}

###########################################################################
# Function: CALC
# Purpose : Summary all the ban daily trans.
# Usage   :
###########################################################################
function CALC_BAN
{
        echo " Entered CALC BAN -----------------------------------------------------" | tee -a ${HznLOG}
        echo "The CALC BAN section" | tee -a ${HznLOG}
        export JOB_INFO="CALC - Summary Daily Ban Trans"
        export TABLENAME="ban_daily_summary"
        export HznDATAINP="DATA From TABLE:ban_daily_trans Table"
        typeset -i DELETED_COUNT=0
        typeset -i ADDED_COUNT=0

        export STARTTIME=`dtx`
        JobStage "STARTING"
#---------------DataReady-------------
        DataReady "STARTING"
#---------------end DataReady-------------
	if [[ -z $PROCESSDAY ]]; then
		BANDAY=0
	else
		BANDAY=$PROCESSDAY
	fi

        SQLRESULT=`sqlplus -s $COMM_DBUSER/$COMM_DBPASS@$COMM_DBASE <<EOF

        set serveroutput on

        DECLARE
          YEAR_IN NUMBER;
          MONTH_IN NUMBER;
          DAY_IN NUMBER;
          ATTUID_IN VARCHAR2(30);
          MKT_CODE_IN VARCHAR2(50);
          RESULT_OUT VARCHAR2(1000);

        BEGIN
          YEAR_IN := $PROCESSYEAR;
          MONTH_IN := $PROCESSMONTH;
          DAY_IN := $BANDAY;
          ATTUID_IN := NULL;
          MKT_CODE_IN := NULL;
          RESULT_OUT := NULL;
          HZNREP.BAN_DAILY_SUMMARY_CALC ( YEAR_IN, MONTH_IN, DAY_IN, ATTUID_IN, MKT_CODE_IN, RESULT_OUT );
          COMMIT;
        END;
        /
       exit;
       EOF`

       echo "THE RESULT for BAN_DAILY_SUMMARY_CALC is $SQLRESULT" |  tee -a ${HznLOG}

       SQLCMD="set  sqlblanklines on heading off pagesize 0 feedback off
        select substr(REGEXP_SUBSTR('$SQLRESULT','DELETED TOTAL=[[:digit:]]+'),15) as total_deleted from dual;
        exit;"
        echo -e $SQLCMD
        echo  "$SQLCMD" | $SQLSTART |read DELETED_COUNT
        echo -e "Daily Ban summary:DELETED_COUNT=$DELETED_COUNT" |  tee -a ${HznLOG}
        export  NbrOfRecsDeleted=$DELETED_COUNT

       SQLCMD1="set  sqlblanklines on heading off pagesize 0 feedback off
        select substr(REGEXP_SUBSTR('$SQLRESULT','ADDED TOTAL=[[:digit:]]+'),13) as total_added from dual;
        exit;"
        echo -e $SQLCMD1
        echo  "$SQLCMD1" | $SQLSTART |read ADDED_COUNT
        echo -e "Daily Ban summary:ADDED_COUNT=$ADDED_COUNT" | tee -a ${HznLOG}
        export  RecLoaded=$ADDED_COUNT

	CheckBcpLog ${HznLOG}

       echo "nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$TABLENAME_$FEED_TYPE.log 2>&1" | tee -a ${HznLOG}
       nohup $HZN_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV > ${HZN_LOG}/analyze_$TABLENAME_$FEED_TYPE.log 2>&1

        export JOB_INFO="CALC BAN TRANS SUCCESSFULLY COMPLETED - process id# ${PROCESSID}"
        export ENDTIME=`dtx`
        JobStage "COMPLETE"

	if [ -z ${LOADCOMPLETE} ]; then
		echo "`dtx` LOADCOMPLETE not set (${LOADCOMPLETE})." | tee -a ${HznLOG}
	else
		echo "`dtx` Creating complete file - ${LOADCOMPLETE}" | tee -a ${HznLOG}
		touch ${LOADCOMPLETE}
	fi
#---------------DataReady-------------
        DataReady "COMPLETE"
#---------------end DataReady-------------

        echo " End CALC BAN -----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: EXTRACT
# Purpose : Executes functions to extract data from the database table(s).
# Usage   : EXTRACT
###########################################################################
function EXTRACT
{
    echo " Entered EXTRACT $FEED_TYPE -----------------------------------------------------" | tee -a ${HznLOG}
    echo "The EXTRACT $FEED_TYPE section" | tee -a ${HznLOG}
    export JOB_INFO="EXTRACT- Extract $FEED_TYPE"
    
    export STARTTIME=`dtx`
    export HznDATAINP="DATA from $FEED_TYPE"

    if [ -f ${LOADCOMPLETE} ]; then
       rm -f ${LOADCOMPLETE}
    fi

    JobStage "STARTING"
#---------------DataReady-------------
    DataReady "STARTING"
#---------------end DataReady-------------

    case ${FEED_TYPE} in
      cpc_to_tlg)
	export EXTRACTSQLCMD=${DATADIR}/extractSqlCommand${FEED_TYPE}_${SERVER}_$$.sql
	export EXTRACTSPOOLFILE=${DATADIR}/extractSpoolFile${FEED_TYPE}_${SERVER}_$$.lst
	
	export ExtractHznSql=cpc_to_tlg.sql
	echo "spool ${EXTRACTSPOOLFILE} ; " > ${EXTRACTSQLCMD}
	echo "sed -e 's/--EFFDATE/'$YYYYMMDD'/' $HORIZON_BIN/$ExtractHznSql >> ${EXTRACTSQLCMD}" | tee -a ${HznLOG}
	sed -e 's/--EFFDATE/'$YYYYMMDD'/' $HORIZON_BIN/$ExtractHznSql >> ${EXTRACTSQLCMD}
	echo -e "======== EXTRACTSQLCMD ========" | tee -a ${HznLOG}
	cat ${EXTRACTSQLCMD} | tee -a ${HznLOG}
	echo -e "======== END EXTRACTSQLCMD ========" | tee -a ${HznLOG}

	echo -e "" | tee -a ${HznLOG}
	echo -e "=================================================================================" | tee -a ${HznLOG}
	echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting CPC Extract .... " | tee -a ${HznLOG}
	echo -e "=================================================================================" | tee -a ${HznLOG}
	echo -e "" | tee -a ${HznLOG}

	$SQLSTART @${EXTRACTSQLCMD}
	;;
      hznrep_ccpm_wireless)
	export EXTRACTSQLCMD=${DATADIR}/extractSqlCommand${FEED_TYPE}_${SERVER}_$$.sql
	export EXTRACTSPOOLFILE=${DATADIR}/extractSpoolFile${FEED_TYPE}_${SERVER}_$$.lst
	
	export ExtractHznSql=hznrep_ccpm_wireless_ext.sql
	echo "spool ${EXTRACTSPOOLFILE} ; " > ${EXTRACTSQLCMD}
	echo "sed -e 's/--PROCESSYEAR/'${PROCESSYEAR}'/' -e 's/--PROCESSMONTH/'${PROCESSMONTH}'/' -e 's/--PROCESSDAY/'${PROCESSDAY}'/' $HORIZON_BIN/$ExtractHznSql >> ${EXTRACTSQLCMD}" | tee -a ${HznLOG}
	sed -e 's/--PROCESSYEAR/'${PROCESSYEAR}'/' -e 's/--PROCESSMONTH/'${PROCESSMONTH}'/' -e 's/--PROCESSDAY/'${PROCESSDAY}'/' $HORIZON_BIN/$ExtractHznSql >> ${EXTRACTSQLCMD}
	echo -e "======== EXTRACTSQLCMD ========" | tee -a ${HznLOG}
	cat ${EXTRACTSQLCMD} | tee -a ${HznLOG}
	echo -e "======== END EXTRACTSQLCMD ========" | tee -a ${HznLOG}

	echo -e "" | tee -a ${HznLOG}
	echo -e "=================================================================================" | tee -a ${HznLOG}
	echo -e "`date '+%m/%d/%Y %H:%M:%S'` Starting HZNREP CPC Wireless Extract .... " | tee -a ${HznLOG}
	echo -e "=================================================================================" | tee -a ${HznLOG}
	echo -e "" | tee -a ${HznLOG}

	$SQLSTART @${EXTRACTSQLCMD}
	;;
      *)
        echo "Invalid feed type [${FEED_TYPE}] not supported" | tee -a ${HznLOG}
        exit 10
        ;;
    esac

    CheckBcpLog ${HznLOG}

    export ExtractFileDateTime=`date '+%Y%m%d%H%M%S'`
    GetExtractFilename

    typeset -i ExtractActualNbrOfRec
    ExtractROW=`tail -4 ${EXTRACTSPOOLFILE}|grep "row.*selected"`
    export ExtractActualNbrOfRec=`echo $ExtractROW| cut -f1 -d" " -s`
    ExtractLength=`wc -l ${EXTRACTSPOOLFILE} `
    ExtractNbrOfRec=`echo $ExtractLength |cut -f1 -d"/" `
    ExtractTotalNbrOfRec=$ExtractNbrOfRec
    TotalRecLoaded=$ExtractActualNbrOfRec
    echo "***===========================================***" | tee -a ${HznLOG}
    echo "***Extract Total number of lines: $ExtractTotalNbrOfRec " | tee -a ${HznLOG}
    echo "***Extract Actual number of records: $ExtractActualNbrOfRec " | tee -a ${HznLOG}
    echo "***===========================================***" | tee -a ${HznLOG}
    head -${ExtractActualNbrOfRec} ${EXTRACTSPOOLFILE} > ${ExtractDirFile}

    if [[ "$FEED_TYPE" = "hznrep_ccpm_wireless" ]]; then
       echo "TRL|"$PROCESSYEAR$PROCESSMONTH$PROCESSDAY"|"$ExtractActualNbrOfRec >> ${ExtractDirFile}
       echo "TRAILER ADDED = ""TRL|"$PROCESSYEAR$PROCESSMONTH$PROCESSDAY"|"$ExtractActualNbrOfRec | tee -a ${HznLOG}
    fi

    export JOB_INFO="EXTRACT $FEED_TYPE SUCCESSFULLY COMPLETED - process id# ${PROCESSID}"
    export ENDTIME=`dtx`
    JobStage "COMPLETE"
#---------------DataReady-------------
    DataReady "COMPLETE"
#---------------end DataReady-------------
    if [ -z ${LOADCOMPLETE} ]; then
       echo "`dtx` LOADCOMPLETE not set (${LOADCOMPLETE})." | tee -a ${HznLOG}
    else
       echo "`dtx` Creating complete file - ${LOADCOMPLETE}" | tee -a ${HznLOG}
       touch ${LOADCOMPLETE}
    fi

    echo " End EXTRACT $FEED_TYPE -----------------------------------------------------" | tee -a ${HznLOG}
}

###########################################################################
# Function: GetExtractFilename
# Purpose : Determines extract file.
# Usage   : GetExtractFilename
###########################################################################
function GetExtractFilename
{
    case ${FEED_TYPE} in 
      cpc_to_tlg)
        export ExtractFile=CpcToTlg${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}.dat
        export ExtractDirFile=$HZN_DATA/$ExtractFile
        ;;
      hznrep_ccpm_wireless)
        export ExtractFile=${FEED_TYPE}${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}_${ExtractFileDateTime}.dat
        export ExtractDirFile=$HZN_DATA/$ExtractFile
        ;;
      *)
        echo "Invalid feed type [${FEED_TYPE}] not supported" | tee -a ${HznLOG}
        exit 10
        ;;
      esac

    echo "========" | tee -a ${HznLOG}
    echo "ExtractFile=$ExtractFile" | tee -a ${HznLOG}
    echo "ExtractDirFile=$ExtractDirFile" | tee -a ${HznLOG}
    echo "========" | tee -a ${HznLOG}
}

###########################################################################
# Function: SEND
# Purpose : Send file via Connect:Direct or DataRouter.
# Usage   : SEND
###########################################################################
function SEND
{
    echo " Entered SEND-----------------------------------------------------" | tee -a ${HznLOG}
    echo "The SEND section" | tee -a ${HznLOG}

    GetExtractFilename

    export SendFile=$ExtractFile
    export SendDirFile=$ExtractDirFile

    echo "========" | tee -a ${HznLOG}
    echo "SendFile=$SendFile" | tee -a ${HznLOG}
    echo "SendDirFile=$SendDirFile" | tee -a ${HznLOG}
    echo "========" | tee -a ${HznLOG}

    export JOB_INFO="SEND - ~/data/${FEED_TYPE}/${SendFile}"
    export STARTTIME=`dtx`
    export ENDTIME=
    JobStage "STARTING"

    SENDALLMKTS="ALH ARK AUS BOS COR DLS FLP GAC GLF GLR GPL HCL ILL IND LAR MNY MTZ MWR NBI NCA NWS NYR OKC PAC PHI RGV SAN SNE STL TNK TUL WAS WTX"
    echo "SENDALLMKTS=$SENDALLMKTS" | tee -a ${HznLOG}

    # Copy to remote applications.
    case $FEED_TYPE in
      cpc_to_tlg)
        for sendMkt in $SENDALLMKTS; do
          TLGDATFILEOUT=teldircelsec${sendMkt}.dat
          echo "Calling RemoveEnd_SendDat_TouchEnd for ${sendMkt}" | tee -a ${HznLOG}
          RemoveEnd_SendDat_TouchEnd $SendDirFile $TLGDATFILEOUT TELEGENCE $sendMkt
          echo "TLGDATFILEOUT=$TLGDATFILEOUT Sent" | tee -a ${HznLOG}
        done
      ;;
      hznrep_ccpm_wireless)
          if [[ "$DO_NOT_SEND" = "N" ]]; then
             echo "*** Publishing file using DataRouter ***" | tee -a ${HznLOG}
             export SendFileSize=`ls -l $SendDirFile | cut -f5 -d" " -s`
             echo "*** SendFileSize: ${SendFileSize}" | tee -a ${HznLOG}
             export SendFileRecCount=`cat $SendDirFile | wc -l`
             echo "*** SendFileRecCount: ${SendFileRecCount}" | tee -a ${HznLOG}
             export SendPublishDate=`date '+%Y-%m-%d %H:%M:%S'`
             echo "*** SendPublishDate: ${SendPublishDate}" | tee -a ${HznLOG}

	     CURLTempLogFile="${HZN_LOG}/CurlTempLogFile_hznrep_ccpm_wireless.log"

              echo "curl -v -X PUT --user masked user/pass compliance -H X-ATT-DR-META:{\"file_type\":\"txt\",\"feed_type\":\"Full-data-set\",\"compression\":\"N\",\"delimiter\":\"|\",\"record_count\":\"$SendFileRecCount\",\"publish_date\":\"$SendPublishDate\",\"file_size\":\"$SendFileSize\",\"splits\":\"1\",\"feed_id\":\"18296\",\"version\":\"1.0\"} --data-binary @$SendDirFile --post301 --location-trusted $PUBURLCCPMWIRELESS/$SendFile --connect-timeout $PUBMAXTIME --max-time $PUBMAXTIME" | tee -a ${HznLOG}


             curl -v -X  PUT --user $PUBHZNUSER:$PUBHZNPASS -H X-ATT-DR-META:"{\"file_type\":\"txt\",\"feed_type\":\"Full-data-set\",\"compression\":\"N\",\"delimiter\":\"|\",\"record_count\":\"$SendFileRecCount\",\"publish_date\":\"$SendPublishDate\",\"file_size\":\"$SendFileSize\",\"splits\":\"1\",\"feed_id\":\"18296\",\"version\":\"1.0\"}" --data-binary @$SendDirFile --post301 --location-trusted $PUBURLCCPMWIRELESS/$SendFile --connect-timeout $PUBMAXTIME --max-time $PUBMAXTIME  > ${CURLTempLogFile} 2>&1	     
	     RtnCode=$?
	     dos2unix ${CURLTempLogFile}
	     cat ${CURLTempLogFile} | tee -a ${HznLOG}
	     rm ${CURLTempLogFile}
	     if [[ $RtnCode -ne 0 ]]; then
		echo "`dtx` curl - ERROR (exit code=$RtnCode )Publishing Files (hznrep_ccpm_wireless)..." | tee -a ${HznLOG}
                Error_Exit 99
	     fi

	  else
             echo "*** Skipping publishing file ***" | tee -a ${HznLOG}
          fi
      ;;
      *)
        echo "Invalid feed type [${FEED_TYPE}] not supported" | tee -a ${HznLOG}
        exit 10
        ;;
    esac

    export JOB_INFO="SEND $FEED_TYPE SUCCESSFULLY COMPLETED - process id# ${PROCESSID}"
    export ENDTIME=`dtx`
    JobStage "COMPLETE"
}

###########################################################################
# Function: USAGE
# Purpose : Executes functions todisplay usage.
# Usage   : USAGE
###########################################################################
function USAGE
{
	echo "-------------------------------------Usage----------------------------------" |tee -a ${HznLOG}
	echo "${BaseScriptname}  [-S<Stage> / -s<Stage>] -e<Env> -m<month> -y<year> " |tee -a ${HznLOG}
	echo "-f<feed_type>	 [-d<DayOfMonth> -M<MKT>] " |tee -a ${HznLOG}
	echo "-S<stage> (Process only this stage: look/load/cleanup) " |tee -a ${HznLOG}
	echo "-s<stage> (Start from this stage: look/load/cleanup)" |tee -a ${HznLOG}
	echo "-e<env>   (Run in the specified environment - dev |sys |qc " |tee -a ${HznLOG}
	echo "    		|uat | tst | prod )" |tee -a ${HznLOG}
	echo "-v<verbose level> More messages printed in the log." |tee -a ${HznLOG}
	echo "-a<analyze table after load> " |tee -a ${HznLOG}
	echo "-r<retain this many days worth of data, delete anything prior # days> " |tee -a ${HznLOG}
	echo "-N<FORCE_NO_SPLIT Do not split large sqlldr files> " |tee -a ${HznLOG}
	echo "-D<Delete Transactions> M for monthly, D for daily else no delete just append" |tee -a ${HznLOG}
	echo "-f<feed_type> translates to table name." |tee -a ${HznLOG}
	echo "	Feed_Type: bid_srvchg	Table: bid_prod_family_svc_chgs" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_ffsc	Table: tlg_ffsc" |tee -a ${HznLOG}
	echo "	Feed_Type: bid_cancel	Table: bid_cancellations" |tee -a ${HznLOG}
	echo "	Feed_Type: bid_cf	Table: bid_customer_feedback" |tee -a ${HznLOG}
	echo "	Feed_Type: bid_wl	Table: bid_wline_datapipe_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_wl	Table: ccpm_wline_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: biz_ipbb_flipping	Table: biz_ipbb_flipping" |tee -a ${HznLOG}
	echo "	Feed_Type: cpc	Table: cpc_product_catlg" |tee -a ${HznLOG}
	echo "	Feed_Type: crft_care	Table: crft_care_surveys" |tee -a ${HznLOG}
	echo "	Feed_Type: crft_retail	Table: crft_retail_surveys" |tee -a ${HznLOG}
	echo "	Feed_Type: tacrft_cust_survey	Table: tacrft_cust_survey" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_contract_trans  Table: ccpm_contract_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_contract_ref_trans  Table: ccpm_contract_ref_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_ip_definition	Table: tlg_ip_definition" |tee -a ${HznLOG}
	echo "	Feed_Type: opus	Table: opus_sales_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: oracle	Table: ora_sales_orders" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_daily	Table: tlg_daily_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_imei_catchup	Table: tlg_imei_catchup" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_inst	Table: ccpm_enb_inst" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_inst_hist	Table: ccpm_enb_inst_hist" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_true	Table: tlg_true_up_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_inst_info 	Table: tlg_inst_info_catchup" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_mult_imei        Table: tlg_mult_imei" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_ccnmcn_chg       Table: tlg_ccnmcn_chg" |tee -a ${HznLOG} 
        echo "  Feed_Type: tlg_srvarea          Table: tlg_srvarea" |tee -a ${HznLOG}
        echo "  Feed_Type: tlg_srvarea_mob      Table: tlg_srvarea_mob" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_tablet       Table: tlg_tablet" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_smf_allmobs_agt       Table: tlg_smf_allmobs" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_smf_allmobs_nat       Table: tlg_smf_allmobs" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_smf_billhistory_agt       Table: tlg_smf_billhistory" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_smf_billhistory_nat       Table: tlg_smf_billhistory" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_smf_customer_agt       Table: tlg_smf_customer" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_smf_customer_nat       Table: tlg_smf_customer" |tee -a ${HznLOG} 
	echo "	Feed_Type: tlg_dealer_chg	Table: tlg_dealer_code_changes" |tee -a ${HznLOG}
	echo "	Feed_Type: ban_daily_sum	Table: ban_daily_sum" |tee -a ${HznLOG}
	echo "	Feed_Type: ban_daily_trans	Table: ban_daily_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_monthly_dealer	Table: tlg_monthly_dealer" |tee -a ${HznLOG}
	echo "	Feed_Type: edm_referral_chg	Table: edm_referral_code_trans" |tee -a ${HznLOG}
	echo "	Feed_Type: dc_tlg_update	" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_inst_tlg_update	" |tee -a ${HznLOG}
	echo "	Feed_Type: tlg_daily_device_id_upd	" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_wline_trans_process	" |tee -a ${HznLOG}
	echo "	Feed_Type: rc_tlg_update	" |tee -a ${HznLOG}
	echo "	Feed_Type: dc_bid_update	" |tee -a ${HznLOG}
	echo "	Feed_Type: nci	" |tee -a ${HznLOG}
	echo "	Feed_Type: hznrep_daily_upd	" |tee -a ${HznLOG}
	echo "	Feed_Type: hznrep_ccpm_wireless	" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_contract_trans	" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_contract_ref_trans	" |tee -a ${HznLOG}
	echo "	Feed_Type: cpc_to_tlg	" |tee -a ${HznLOG}
	echo "	Feed_Type: cross_upgrade	" |tee -a ${HznLOG}
	echo "	Feed_Type: product_upgrade	" |tee -a ${HznLOG}
	echo "	Feed_Type: sweep_tlg_srvchg	" |tee -a ${HznLOG}
	echo "	Feed_Type: calc_ban	" |tee -a ${HznLOG}
	echo "	Feed_Type: pos_tlg_update	" |tee -a ${HznLOG}
	echo "	Feed_Type: ericsson	" |tee -a ${HznLOG}
	echo "	Feed_Type: ericsson_tlg_update	" |tee -a ${HznLOG}
	echo "	Feed_Type: ericsson_ml	" |tee -a ${HznLOG}
	echo "	Feed_Type: inst_tlg_update	" |tee -a ${HznLOG}
	echo "	Feed_Type: ccpm_inst_tlg_catchup	" |tee -a ${HznLOG}
	echo "  Feed_Type: srs_call_summ  Table: srs_call_summary" |tee -a ${HznLOG}
	echo "	*****EXPECTATION ALERT**** " |tee -a ${HznLOG}
	echo "	DATA & END file must be located in the following directory: " |tee -a ${HznLOG}
	echo "		${HORIZON_DATA}/<feed_type>" |tee -a ${HznLOG}
	echo "		& File name must be: <Table_Name>[<MKT>]<YYYYMM>[<DD>].dat or .end" |tee -a ${HznLOG}
	echo "	*****end EXPECTATION ALERT****  " |tee -a ${HznLOG}
	echo "  e.g.  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: bid_srvchg	are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fbid_srvchg  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_ffsc are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -ftlg_ffsc  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: bid_cf are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fbid_cf  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: bid_wl are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fbid_wl  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_wl are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m9 -d23 -slook -edev -fccpm_wl  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: biz_ipbb_flipping are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m9 -d23 -slook -edev -fbiz_ipbb_flipping  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: crft_care are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m9 -d23 -slook -edev -fcrft_care  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: crft_retail are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m9 -d23 -slook -edev -fcrft_retail  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tacrft_cust_survey are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m9 -d23 -slook -edev -ftacrft_cust_survey  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_contract_trans are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m9 -d23 -slook -edev -fccpm_contract_trans  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_contract_ref_trans are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m9 -d23 -slook -edev -fccpm_contract_ref_trans  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: bid_cancels are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -slook -edev -fbid_cancels  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_ip_definition are Year, Month, Environment, MKT " |tee -a ${HznLOG}
	echo "feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -slook -edev -MNBI -ftlg_ip_definition  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: cpc are Year, Month, Day, Environment, " |tee -a ${HznLOG}
	echo "feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fcpc  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: oracle are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -foracle  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_daily are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC-ftlg_daily  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_imei_catchup are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC-ftlg_imei_catchup  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_inst are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type, & delete." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m10 -d31 -edev -fccpm_inst -DD  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_inst_hist are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type, & delete." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m10 -d31 -edev -fccpm_inst_hist -DD  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_mult_imei are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC -ftlg_mult_imei  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_ccnmcn_chg are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC -ftlg_ccnmcn_chg  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_srvarea    are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC -ftlg_srvarea     " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_srvarea_mob are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC -ftlg_srvarea_mob  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_tablet are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2019 -m4 -d10 -slook -edev -MDLS -ftlg_tablet  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_smf_allmobs_agt are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2019 -m4 -slook -edev -MDLS -ftlg_smf_allmobs_agt  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_smf_allmobs_nat are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2019 -m4 -slook -edev -MDLS -ftlg_smf_allmobs_nat  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_smf_billhistory_agt are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2019 -m4 -slook -edev -MDLS -ftlg_smf_billhistory_agt  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_smf_billhistory_nat are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2019 -m4 -slook -edev -MDLS -ftlg_smf_billhistory_nat  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_smf_customer_agt are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2019 -m4 -slook -edev -MDLS -ftlg_smf_customer_agt  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_smf_customer_nat are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "  ${BaseScriptname}  -y2019 -m4 -slook -edev -MDLS -ftlg_smf_customer_nat  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_true are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -slook -edev -MGAC -ftlg_true  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_inst_info are Year, Month, MKT, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -slook -edev -MGAC -ftlg_inst_info  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_srvchg 	are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC -ftlg_srvchg " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_dealer_chg 	are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -MGAC -ftlg_dealer_chg  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: dc_tlg_update are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fdc_tlg_update  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_inst_tlg_update are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fccpm_inst_tlg_update  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: tlg_daily_device_id_upd are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -ftlg_daily_device_id_upd  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_wline_trans_process are Year, Month, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -slook -edev -fccpm_wline_trans_process  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: rc_tlg_update are Year, Month,Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -frc_tlg_update  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: dc_bid_update are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fdc_bid_update  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: nci are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fnci  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: hznrep_daily_upd are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2017 -m6 -d12 -slook -edev -fhznrep_daily_upd " |tee -a ${HznLOG}
	echo "Required parameters for feed type: hznrep_ccpm_wireless are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2018 -m8 -d24 -slook -edev -fhznrep_ccpm_wireless " |tee -a ${HznLOG}
	echo "Required parameters for feed type: cpc_to_tlg are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2017 -m6 -d12 -slook -edev -fcpc_to_tlg " |tee -a ${HznLOG}
	echo "Required parameters for feed type: cross_upgrade are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fcross_upgrade  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: pos_tlg_update are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fpos_tlg_update  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ericsson are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fericsson -DD  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ericsson_tlg_update are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fericsson_tlg_update  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ericsson_ml are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fericsson_ml -DD  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: sweep_tlg_srvchg are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fsweep_tlg_srvchg  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: product_upgrade are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fproduct_upgrade  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: edm are Year, Month, Day, " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2015 -m5 -d12 -slook -edev -fedm_referral_chg -DD " |tee -a ${HznLOG}
	echo "Required parameters for feed type: inst_tlg_update are Year & Month. " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m10 -slook -edev -finst_tlg_update  " |tee -a ${HznLOG}
	echo "Required parameters for feed type: ccpm_inst_tlg_catchup are Year & Month. " |tee -a ${HznLOG}
	echo "Environment, feed_type & stage." |tee -a ${HznLOG}
	echo "	${BaseScriptname}  -y2016 -m10 -slook -edev -fccpm_inst_tlg_catchup  " |tee -a ${HznLOG}
        echo "Required parameters for feed type: srs_call_summ are Year, Month, Day, " |tee -a ${HznLOG}
        echo "Environment, feed_type & stage." |tee -a ${HznLOG}
        echo "  ${BaseScriptname}  -y2013 -m3 -d9 -slook -edev -fsrs_call_summ -DD " |tee -a ${HznLOG}
	echo "-------------------------------end Usage--------------------------" |tee -a ${HznLOG}

	exit 97
}

###########################################################################
# Function: CLEANUP
# Purpose : Executes functions to clean up & backup data files.
# Usage   : CLEANUP
###########################################################################
function CLEANUP
{
	echo " `dtx`	Starting CLEANUP stage-----${FEED_TYPE}-------------------" |tee -a ${HznLOG}

	echo "The CLEANUP section" | tee -a ${HznLOG}
	export JOB_INFO="CLEANUP - ${FEED_TYPE}"
	export STARTTIME=`dtx`
	export ENDTIME=
	JobStage "STARTING"

	echo "HznDATAINP=${HznDATAINP}" |tee -a $HznLOG
	echo "ExtractDirFile=${ExtractDirFile}" |tee -a $HznLOG

	if [[ -f ${HznDATAINP} && "$SKIP_PREV_COMPLETE_CHECK" != "Y" ]]; then
		echo "Backing up OLD DATA file:" | tee -a ${templog}
        	if [[ "$FEED_TYPE" = "crft_care" || "$FEED_TYPE" = "crft_retail" || "$FEED_TYPE" = "tacrft_cust_survey" || "$FEED_TYPE" = "ccpm_contract_trans" || "$FEED_TYPE" = "ccpm_contract_ref_trans" || "$FEED_TYPE" = "biz_ipbb_flipping" ]]; then
			mv ${HznDATAINP_unvalidated} ${HZN_DATA}/backup/${HznDATAINPFILE}.dat
			gzip -f ${HZN_DATA}/backup/${HznDATAINPFILE}.dat
			rm ${HznDATAINP}
			ls -l ${HZN_DATA}/backup/${HznDATAINPFILE}* |tee -a $HznLOG
 	                if [ -f ${DELDONE} ]; then
		           rm -f ${DELDONE}
	                fi
		else
			mv ${HznDATAINP} ${HZN_DATA}/backup/${HznDATAINPFILE}.dat
			gzip -f ${HZN_DATA}/backup/${HznDATAINPFILE}.dat
			ls -l ${HZN_DATA}/backup/${HznDATAINPFILE}* |tee -a $HznLOG
		fi
	fi
    
    if [[ -f ${HznDATAINP} ]]; then
        mv ${HznDATAINP} ${HZN_DATA}/backup/${HznDATAINPFILE}.dat
        gzip -f ${HZN_DATA}/backup/${HznDATAINPFILE}.dat
		ls -l ${HZN_DATA}/backup/${HznDATAINPFILE}* |tee -a $HznLOG
    fi

	if [[ -f ${ExtractDirFile} && "$SKIP_PREV_COMPLETE_CHECK" != "Y" ]]; then
		echo "Backing up EXTRACT DATA file:" | tee -a $HznLOG
		mv ${ExtractDirFile} ${HZN_DATA}/backup/${ExtractFile}
		gzip -f ${HZN_DATA}/backup/${ExtractFile}
		ls -l ${HZN_DATA}/backup/${ExtractFile}* |tee -a $HznLOG
	fi

	if [ -f ${LOADINPROGRESS} ]; then
		rm -f ${LOADINPROGRESS}
	fi

#	if [ -f ${FILELOADED} ]; then
#		rm -f ${FILELOADED}
#	fi
#
# 	if [ -f ${LOADCOMPLETE} ]; then
#		rm -f ${LOADCOMPLETE}
#	fi
#
# 	if [ -f ${DELDONE} ]; then
#		rm -f ${DELDONE}
#	fi

	if [ -f ${SQLLOG} ]; then
 		rm -f ${SQLLOG}
 	fi

	if [ -f ${RETENSQLLOG} ]; then
 		rm -f ${RETENSQLLOG}
 	fi

	if [ -f ${HznDATAEND} ]; then
		rm -f ${HznDATAEND}
	fi

	if [ -f ${EXTRACTSQLCMD} ]; then
		rm -f ${EXTRACTSQLCMD}
	fi

	if [ -f ${EXTRACTSPOOLFILE} ]; then
		rm -f ${EXTRACTSPOOLFILE}
	fi

	if [ -f ${RESETSQLCMD} ]; then
		rm -f ${RESETSQLCMD}
	fi

	if [ -f ${RESETSPOOLFILE} ]; then
		rm -f ${RESETSPOOLFILE}
	fi

	export ENDTIME=`dtx`
	JobStage "COMPLETE"
}	#end cleanup

###############################################################################
# Function: MAIN FUNCTION                                                     #
# Purpose : Controls the flow of the entire extract process.                  #
# Usage   : extract_agents.sh -M<market code> -P<process> -A<agent type A/N>  #
###############################################################################
#
# Parameters:	Non-Optional
# Defaults:
#       Default to run in PRODUCTION environment.
#       Process Month defaults to last month.
#       Process Year defaults to last month's year.
#       Report type defaults to no report.
#
###############################################################################
clear

#-----------------------------------------------------------
export BINDIR=${HORIZON_BIN}
export ALLARGS="$*"
Init
typeset -i TotalRecLoaded=0
typeset -i PosTlgUpdated=0
typeset -i EricTlgUpdated=0
typeset -i EricSnpTlgUpdated=0
typeset -i InstTlgUpdated=0
typeset -i CCPMInstTlgCatchupUpdated=0
typeset -i TlgSrvchgUpdated=0
typeset -i TlgDailyUpdated=0
typeset -i TlgDailyInstUpdated=0
typeset -i TlgDailyDevIdUpdated=0
typeset -i CCPMDailyContIdUpdated=0
typeset -i TlgReferralUpdated=0
typeset -i BidSrvchgUpdated=0
typeset -i ProductUpgUpdated=0
typeset -i NCIUpdated=0
typeset -i NCIDeleted=0
typeset -i HznRepDailyUpdated=0
export ScriptTimeStart=`dtx`
#----------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------
	export zMSG=ErrorMsgEmailList
	export cMSG=
	export DELETE_CLAUSE=
	export DELETE_TRAN=
        export RETENTION_CLAUSE=
	export RETENTIONDAYS=0
	export NbrOfRecsDeleted=0
	export RecLoaded=0
	export TSUpdated=0
	export PTUpdated=0
	export TDUpdated=0
	export TDIUpdated=0
	export CCPMICUpdated=0
	export TDDevIdUpdated=0
	export BSUpdated=0
	export PRUpdated=0
	export NUpdated=0
	export NDeleted=0
	export ErrorData=0
	export ErrorWhen=0
	export ErrorNull=0
	export DO_ANALYZE="N"
	export DO_NOT_SEND="N"
	export UPDATE_SEQ="N"

	while getopts m:M:y:f:e:d:D:s:S:v:c:z:r:aXNEWu OPT ; do
	case ${OPT} in
		D) export DELETE_TRAN=`echo ${OPTARG} | tr '[a-z]' '[A-Z]'`;;
		M) export MKT=`echo ${OPTARG} | tr '[a-z]' '[A-Z]'`;;
		r) export RETENTIONDAYS=${OPTARG};;
		m) export PROCESSMONTH=$(printf "%02d" ${OPTARG});;
		d) export PROCESSDAY=$(printf "%02d" ${OPTARG});;
		y) export PROCESSYEAR=${OPTARG};;
		f) export FEED_TYPE=`echo ${OPTARG} | tr '[A-Z]' '[a-z]'`;;
		S) export DOSTAGE=`echo ${OPTARG} | tr '[a-z]' '[A-Z]'`;;
		s) export STARTSTAGE=`echo ${OPTARG} | tr '[a-z]' '[A-Z]'`;;
		v) export VERBOSE=${OPTARG};;
		a) export DO_ANALYZE="Y";;
		E) export EMAIL_IGNORE="Y";;
		W) export DO_NOT_SEND="Y";;
		X) export SKIP_PREV_COMPLETE_CHECK="Y";;
		N) export FORCE_NO_SPLIT="Y";;
		e) export RUNENV=`echo ${OPTARG} | tr '[A-Z]' '[a-z]'`;;
		c) export cMSG=`echo ${OPTARG} | tr '[A-Z]' '[a-z]'`;;
		z) export zMSG=`echo ${OPTARG} | tr '[A-Z]' '[a-z]'`;;
		u) export UPDATE_SEQ="Y";;
		*)
			echo "Check Options other than m:M:y:f:e:d:D:s:S:v:c:z:a:r:W "
			echo "OPT is ${OPT}"
			USAGE
			;;
	esac
	done

#-------------------
CmdLine
#-------------------
#-----------------------------------------------------------------------------
#	This is where all input variable are checked & variables are set
#	The heart of the main
#-----------------------------------------------------------------------------
	case ${RUNENV} in
		dev |sys |qc |uat | tst | prod)
			echo "Running for valid environment: ${RUNENV} " |tee -a ${templog}
			;;
		*)
			echo "Environment is a required parameter ! " |tee -a ${templog}
			echo "Please provide environment (e.g. -edev)." |tee -a ${templog}
			USAGE
			;;
	esac

#-----------------------------------------------------------------------
. ${HORIZON_BIN}/setupenv.sh
export SQLSTART="sqlplus -s ${COMM_DBUSER}/${COMM_DBPASS}@${COMM_SERVER}"

if [[ ! -d $HORIZON_DATA/$FEED_TYPE ]]; then
	mkdir $HORIZON_DATA/$FEED_TYPE
fi
if [[ ! -d $HORIZON_LOG/$FEED_TYPE ]]; then
	mkdir -p $HORIZON_LOG/$FEED_TYPE
fi
if [[ ! -d $HORIZON_DATA/$FEED_TYPE/backup ]]; then
	mkdir -p $HORIZON_DATA/$FEED_TYPE/backup
fi
#-----------------------------------------------------------
	export YYYYMMDD=${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}
	if [ -z ${VERBOSE} ]; then
		export VERBOSE=2
	fi
	if [ -z ${EMAIL_IGNORE} ]; then
		export EMAIL_IGNORE=N
	fi
	if [ -z ${FEED_TYPE} ]; then
		echo "FEED_TYPE is a required parameter ! " |tee -a ${templog}
		echo "Please provide feed type (e.g. -fcpc)." |tee -a ${templog}
		USAGE
	else
		WriteLn "****b4 GetTable FEED_TYPE: $FEED_TYPE";
		GetTable
	fi
#----------------------------------------------------------------
	export HZN_DATA="${HORIZON_DATA}/${FEED_TYPE}"
	export HZN_LOG="${HORIZON_LOG}/${FEED_TYPE}"
	export HZN_CTL="${HORIZON_HOME}/ctl"
	export HZN_BIN="${HORIZON_BIN}"
	export CTLDIR="${HZN_CTL}"
	export DATADIR="${HZN_DATA}"
	export LOGDIR="${HZN_LOG}"
#---------------
#	echo "SQLSTART: ${SQLSTART}" |tee -a ${templog}
#---------------------------------------------------------------
	echo "	HZN_DATA: ${HZN_DATA}" |tee -a ${templog}
	echo "	HZN_LOG: ${HZN_LOG}" |tee -a ${templog}
	echo "	HZN_CTL: ${HZN_CTL}" |tee -a ${templog}
	echo "	HZN_BIN: ${HZN_BIN}" |tee -a ${templog}
	echo "-------------------------------------------------" |tee -a ${templog}
	echo "	CTLDIR=${CTLDIR}" |tee -a ${templog}
	echo "	DATADIR=${DATADIR}" |tee -a ${templog}
	echo "	LOGDIR=${LOGDIR}" |tee -a ${templog}
	echo "-------------------------------------------------" |tee -a ${templog}
#---------------------------------------------------------------
#	Bring the log home to proper log directory
#---------------------------------------------------------------
	echo "BEFORE moving ${HznLOG} " | tee -a ${templog}
	echo "	templog: ${templog}" | tee -a ${templog}
	echo "	templogn: ${templogn}" | tee -a ${templog}
	export templog=${HZN_LOG}/${templogn}
	echo "Now moving ${HznLOG}" | tee -a ${templog}
	echo "	To ${templog}" | tee -a ${templog}
	mv ${HznLOG} ${templog}
	export HznLOG=${templog}
	echo "Now log is ${HznLOG} " | tee -a ${templog}
#--------------------------------------------------------------
	if [[ -z ${SKIP_PREV_COMPLETE_CHECK} ]]; then
		SKIP_PREV_COMPLETE_CHECK=N
	fi
	if [[ -z ${FORCE_NO_SPLIT} ]]; then
		FORCE_NO_SPLIT=N
	fi
	if [[ -z ${RUNENV} ]]; then
		echo "Missing required parameter - env !" | tee -a ${HznLOG}
		USAGE
	fi
	#-------------------------------------------
	if [[ -z ${PROCESSYEAR} ]]; then
		echo "Missing required parameter - year !" | tee -a ${HznLOG}
		USAGE
	fi
	#-------------------------------------------
	if [[ -z ${PROCESSMONTH} ]]; then
		echo "Missing required parameter -  month !" | tee -a ${HznLOG}
		USAGE
	fi
	#-------------------------------------------
	case ${FEED_TYPE} in
		calc_ban| bid_cancels |tlg_true| bid_cf | bid_wl | tlg_smf_allmobs_agt | tlg_smf_allmobs_nat | tlg_smf_billhistory_agt | tlg_smf_billhistory_nat| tlg_smf_customer_agt | tlg_smf_customer_nat | ccpm_wl | tlg_ip_definition | inst_tlg_update | ccpm_inst_tlg_catchup | tlg_inst_info | biz_ipbb_flipping)
			echo "Day is Not a required parameter !" | tee -a ${HznLOG}
			;;
		*)
			if [[ -z ${PROCESSDAY} ]]; then
				echo "Day is a required parameter!"
				echo "Missing required parameter - day !" | tee -a ${HznLOG}
				USAGE
			fi
			;;
	esac
	case ${FEED_TYPE} in
		tlg_ccnmcn_chg | tlg_tablet | tlg_smf_allmobs_agt | tlg_smf_allmobs_nat | tlg_smf_billhistory_agt | tlg_smf_billhistory_nat | tlg_smf_customer_agt | tlg_smf_customer_nat  | tlg_mult_imei | tlg_daily | tlg_true | tlg_srvchg | tlg_dealer_chg | tlg_ffsc | tlg_ip_definition | tlg_inst_info | tlg_srvarea | tlg_srvarea_mob | tlg_imei_catchup)
				if [[ -z ${MKT} ]]; then
					echo "Market is a required parameter for this feed (${FEED_TYPE})." |tee -a ${HznLOG}
					exit 12
				fi
				;;
			*)
				;;
	esac
#-----------------------------------------------------------
#-----------------------------------------------------------
#   SETUP DELETE_CLAUSE
#-----------------------------------------------------------
if [[ "$FEED_TYPE" = "cpc" || "$FEED_TYPE" = "tlg_ip_definition" || "$FEED_TYPE" = "ccpm_contract_ref_trans" ]]; then
		DELETE_CLAUSE="truncate table ${TABLENAME}"
		export DELETE_CLAUSE="${DELETE_CLAUSE}"
		export TRUNC_TABLE=N
else

case ${DELETE_TRAN} in
	M)
		if [[ "$FEED_TYPE" = "oracle" || "$FEED_TYPE" = "bid_srvchg" || "$FEED_TYPE" = "tlg_ffsc" || "$FEED_TYPE" = "bid_wl" ||  "$FEED_TYPE" = "ccpm_wl" || "$FEED_TYPE" = "biz_ipbb_flipping" ]]; then
			export TRUNC_TABLE=Y
		else
			export TRUNC_TABLE=N
		fi
        if [[ "$FEED_TYPE" = "tlg_smf_allmobs_agt" || "$FEED_TYPE" = "tlg_smf_allmobs_nat" || "$FEED_TYPE" = "tlg_smf_billhistory_agt" || "$FEED_TYPE" = "tlg_smf_billhistory_nat" || "$FEED_TYPE" = "tlg_smf_customer_agt" || "$FEED_TYPE" = "tlg_smf_customer_nat" ]]; then
		    DELETE_CLAUSE="DELETE ${TABLENAME} WHERE month=${PROCESSMONTH} and year=${PROCESSYEAR} and type ='${SMF_TYPE}'"
        else
		    DELETE_CLAUSE="DELETE ${TABLENAME} WHERE month=${PROCESSMONTH} and year=${PROCESSYEAR}"
        fi
		export DELETE_CLAUSE="${DELETE_CLAUSE}"
		;;
	D)
		export TRUNC_TABLE=N
		DELETE_CLAUSE="DELETE ${TABLENAME} WHERE month=${PROCESSMONTH} and year=${PROCESSYEAR} and day = ${PROCESSDAY}"
		export DELETE_CLAUSE="${DELETE_CLAUSE}"

                if [[ "$FEED_TYPE" = "tlg_srvarea" || "$FEED_TYPE" = "tlg_srvarea_mob" ]]; then
                 export TRUNC_TABLE=Y
                fi
		;;
	*)
		export DELETE_CLAUSE=
		export TRUNC_TABLE=N
#		if [[ "$FEED_TYPE" != "calc_ban" && "$FEED_TYPE" != "dc_tlg_update" && "$FEED_TYPE" != #"dc_bid_update" && "$FEED_TYPE" != "rc_tlg_update" && "$FEED_TYPE" != "nci" && "$FEED_TYPE" != #"cross_upgrade" && "$FEED_TYPE" != "pos_tlg_update" && "$FEED_TYPE" != "sweep_tlg_srvchg" && #"$FEED_TYPE" != "product_upgrade" ]]; then
#			echo "Invalid delete option (${DELETE_TRAN}). Can only be M for monthly and D for daily." |tee -a #${HznLOG}
#			exit 12
#		fi
		case "$FEED_TYPE" in
			calc_ban|dc_tlg_update|ccpm_inst_tlg_update|tlg_daily_device_id_upd|ccpm_wline_trans_process|dc_bid_update|dc_bid_update|\
			rc_tlg_update|cross_upgrade|pos_tlg_update|\
			nci|hznrep_daily_upd|sweep_tlg_srvchg|product_upgrade|\
			ericsson_tlg_update|inst_tlg_update|ccpm_inst_tlg_catchup|cpc_to_tlg|hznrep_ccpm_wireless)
				;;
			*)
				echo "Invalid delete option (${DELETE_TRAN}). Can only be M for monthly and D for daily." |tee -a ${HznLOG}
				exit 12
				;;
		esac
		;;
esac
fi

if [ ${RETENTIONDAYS} -gt 0 ]; then
  ret_date=$(date -d "-${RETENTIONDAYS} days" +"%Y%m%d")
  ret_year=$(echo $ret_date | cut -c 1-4)
  ret_month=$(echo $ret_date | cut -c 5-6)
  ret_day=$(echo $ret_date | cut -c 7-8)

  RETENTION_CLAUSE="DELETE ${TABLENAME} WHERE month=${ret_month} and year=${ret_year} and day < ${ret_day}"

fi


if [ -z ${DELETE_CLAUSE} ]; then
	echo "DELETE_CLAUSE is NULL so NO deletes Only Append load!!!"| tee -a ${HznLOG}
else
        
	if [[ "$FEED_TYPE" != "tlg_ip_definition" ]]; then
		if [ ! -z ${MKT} ]; then
        	if [[ "$FEED_TYPE" = "tlg_smf_allmobs_agt" || "$FEED_TYPE" = "tlg_smf_allmobs_nat" || "$FEED_TYPE" = "tlg_smf_billhistory_agt" || "$FEED_TYPE" = "tlg_smf_billhistory_nat" || "$FEED_TYPE" = "tlg_smf_customer_agt" || "$FEED_TYPE" = "tlg_smf_customer_nat" ]]; then
				export DELETE_CLAUSE="${DELETE_CLAUSE} and TLG_MKT = '${MKT}'"
        	else
				export DELETE_CLAUSE="${DELETE_CLAUSE} and bill_mkt_code = '${MKT}'"
        	fi
		fi
	fi


fi
echo "----------DELETE_CLAUSE----------------"| tee -a ${HznLOG}
echo "IS TRUNC_TABLE??? $TRUNC_TABLE"| tee -a ${HznLOG}
echo "${DELETE_CLAUSE} "| tee -a ${HznLOG}
echo "MKT: ${MKT} also DELETE_TRAN: ${DELETE_TRAN}"| tee -a ${HznLOG}
echo "RETENTION_CLAUSE: ${RETENTION_CLAUSE} "| tee -a ${HznLOG}
echo "----------end DELETE_CLAUSE----------------"| tee -a ${HznLOG}
#-----------------------------------------------------------
#   SETUP QUE FILE NAMES
#-----------------------------------------------------------
	export HznLOG=${HZN_LOG}/${SCRIPTNAME}_${TABLENAME}_${MKT}${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}_$$.log
	export OldHznLOG=${SCRIPTNAME}_${TABLENAME}_${MKT}${PROCESSYEAR}${PROCESSMONTH}*.log
	export YYYYMMDD=${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}
#-----------------------------------------------------------
	get_previous ${PROCESSYEAR} ${PROCESSMONTH} ${PROCESSDAY}
	echo "pYYYYMMDD: ${pYYYYMMDD}"| tee -a ${HznLOG}
#-----------------------------------------------------------
	echo "OldHznLOG: ${OldHznLOG}"| tee -a ${HznLOG}
	if [ -f ${OldHznLOG} ]; then
		echo "--------------Backup old log-----------------------" | tee -a ${templog}
		if [ ! -d ${HZN_LOG}/backup ];then
			echo "Createing backup directory! - ${HZN_LOG}/backup"| tee -a ${templog}
			mkdir ${HZN_LOG}/backup
		fi
		mv ${HZN_LOG}/${OldHznLOG} ${HZN_LOG}/backup
		gzip -f ${HZN_LOG}/backup/${OldHznLOG}
		ls -l ${HZN_LOG}/backup/${OldHznLOG}* |tee -a ${HznLOG}
	else
		echo "--------------No logs to Backup-----------------------" | tee -a ${templog}
	fi
#---------------------------------------------------------------
#	Finalize logfile name in proper log directory
#---------------------------------------------------------------
	echo "Now moving ${templog} " | tee -a ${templog}
	echo "	To ${HznLOG}" | tee -a ${templog}
	mv ${templog} ${HznLOG}
	export templog=${HznLOG}
	echo "Final log is ${HznLOG} " | tee -a ${HznLOG}

#---------------------------------------------------------------------#
#   Check for the stage file and begin log to db                      #
#---------------------------------------------------------------------#
	echo "Checking for existing stage file ...Src=${HORIZON_BIN}   Build=${BUILDPROG}" | tee -a ${HznLOG}
	export CURRENT_STAGE=Init
	export ENDTIME=
	export REC_COUNT=
	export STARTTIME=`dtx`

	#<TableName><MKT><PROCESSYEAR><PROCESSMONTH><PROCESSDAY>.dat
	if [[ -z ${HznInputData1} ]]
	then
		export HznDATAINPFILE=${TABLENAME}${MKT}${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}
		export HznDATAINP=$DATADIR/${HznDATAINPFILE}.dat
	else
		export HznDATAINP="${DATADIR}/${HznInputData1}"
		export HznDATAINPFILE=`echo ${HznInputData1} | cut -f 1 -d . `
	fi
	export HznDATAEND=${DATADIR}/${HznDATAINPFILE}.end

	case ${FEED_TYPE} in
		ericsson|ericsson_ml)
			export HznDATAINPFILE=${TABLENAME}_${YYYYMMDD}
			export HznDATAINP=$DATADIR/${HznDATAINPFILE}.dat
			export HznDATAEND="${DATADIR}/${HznDATAINPFILE}.end"
			WriteLn "---------------WLn feed type check succeeded !!!--------------------"
			WriteLn "HznDATAINPFILE is $HznDATAINPFILE"
			WriteLn "HznDATAINP is $HznDATAINP"
			WriteLn "HznDATAEND is $HznDATAEND"
			WriteLn "---------------end WLn feed type check--------------------"
			;;

		crft_care)
			export HznDATAINPFILE=tcrft_mobility_survey_results.${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}
			export HznDATAINP=$DATADIR/${HznDATAINPFILE}.dat
			export HznDATAEND="${DATADIR}/${HznDATAINPFILE}.end"
			export HznDATAWrk=$DATADIR/${HznDATAINPFILE}_DATA.dat
			WriteLn "---------------CRFT File Name Check !!!--------------------"
			WriteLn "HznDATAINPFILE is $HznDATAINPFILE"
			WriteLn "HznDATAINP is $HznDATAINP"
			WriteLn "HznDATAEND is $HznDATAEND"
			WriteLn "HznDATAWrk is $HznDATAWrk"
			WriteLn "---------------end CRFT File Name Check--------------------"
			;;

		crft_retail)
			export HznDATAINPFILE=tacrift_survey_results.${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}
			export HznDATAINP=$DATADIR/${HznDATAINPFILE}.dat
			export HznDATAEND="${DATADIR}/${HznDATAINPFILE}.end"
			export HznDATAWrk=$DATADIR/${HznDATAINPFILE}_DATA.dat
			WriteLn "---------------CRFT File Name Check !!!--------------------"
			WriteLn "HznDATAINPFILE is $HznDATAINPFILE"
			WriteLn "HznDATAINP is $HznDATAINP"
			WriteLn "HznDATAEND is $HznDATAEND"
			WriteLn "HznDATAWrk is $HznDATAWrk"
			WriteLn "---------------end CRFT File Name Check--------------------"
			;;

		tacrft_cust_survey)
			export HznDATAINPFILE=V1_tacrift_survey_results.${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}
			export HznDATAINP=$DATADIR/${HznDATAINPFILE}.dat
			export HznDATAEND="${DATADIR}/${HznDATAINPFILE}.end"
			export HznDATAWrk=$DATADIR/${HznDATAINPFILE}_DATA.dat
			WriteLn "---------------CRFT File Name Check !!!--------------------"
			WriteLn "HznDATAINPFILE is $HznDATAINPFILE"
			WriteLn "HznDATAINP is $HznDATAINP"
			WriteLn "HznDATAEND is $HznDATAEND"
			WriteLn "HznDATAWrk is $HznDATAWrk"
			WriteLn "---------------end CRFT File Name Check--------------------"
			;;
		ccpm_contract_trans)
			export HznDATAINPFILE=contract${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}_daily
			export HznDATAINP=$DATADIR/${HznDATAINPFILE}.dat
			export HznDATAEND="${DATADIR}/${HznDATAINPFILE}.end"
			export HznDATAWrk=$DATADIR/${HznDATAINPFILE}_DATA.dat
			WriteLn "---------------ccpm Contract File Name Check !!!--------------------"
			WriteLn "HznDATAINPFILE is $HznDATAINPFILE"
			WriteLn "HznDATAINP is $HznDATAINP"
			WriteLn "HznDATAEND is $HznDATAEND"
			WriteLn "HznDATAWrk is $HznDATAWrk"
			WriteLn "---------------end ccpm Contract File Name Check--------------------"
			;;
		ccpm_contract_ref_trans)
			export HznDATAINPFILE=contractref${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}_daily
			export HznDATAINP=$DATADIR/${HznDATAINPFILE}.dat
			export HznDATAEND="${DATADIR}/${HznDATAINPFILE}.end"
			export HznDATAWrk=$DATADIR/${HznDATAINPFILE}_DATA.dat
			WriteLn "---------------ccpm Contract Ref File Name Check !!!--------------------"
			WriteLn "HznDATAINPFILE is $HznDATAINPFILE"
			WriteLn "HznDATAINP is $HznDATAINP"
			WriteLn "HznDATAEND is $HznDATAEND"
			WriteLn "HznDATAWrk is $HznDATAWrk"
			WriteLn "---------------end ccpm Contract Ref File Name Check--------------------"
			;;
		biz_ipbb_flipping)
			export HznDATAWrk=$DATADIR/${HznDATAINPFILE}_DATA.dat
			WriteLn "---------------biz_ipbb_flipping File Name Check !!!--------------------"
			WriteLn "HznDATAINPFILE is $HznDATAINPFILE"
			WriteLn "HznDATAINP is $HznDATAINP"
			WriteLn "HznDATAEND is $HznDATAEND"
			WriteLn "HznDATAWrk is $HznDATAWrk"
			WriteLn "---------------end biz_ipbb_flipping File Name Check--------------------"
			;;

		*)
			;;
	esac

	export BAD_FILE=${DATADIR}/${HznDATAINPFILE}.bad
	export DISCARD_FILE=${DATADIR}/${HznDATAINPFILE}.dis

	export LOADINPROGRESS=${DATADIR}/${HznDATAINPFILE}.loadInProgress
	export SQLLOG=${LOGDIR}/${HznDATAINPFILE}_$$.sqllog
	export RETENSQLLOG=${LOGDIR}/${HznDATAINPFILE}_$$.retensqllog

	export DELDONE=${DATADIR}/${HznDATAINPFILE}.deletedone
#	export FILELOADED=${DATADIR}/${HznDATAINPFILE}.loaddone
#-----------------------------May need------------------


	echo "****LOADINPROGRESS is ${LOADINPROGRESS}" | tee -a ${HznLOG}
	export JOBCOMPLETE=${DATADIR}/${HznDATAINPFILE}.complete
#-----------------------------------------------------------------------
#	set_StageComplete
#-----------------------------------------------------------------------
	export LOADCOMPLETE=${DATADIR}/${FEED_TYPE}${MKT}${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}.complete
	YESTERDAY=`TZ=GMT+24 date +%Y%m%d`
	echo "Unix Yesterday: ${YESTERDAY}"
	export PREVIOUS_LOAD=${DATADIR}/${FEED_TYPE}${MKT}${pYYYYMMDD}.complete
	case ${FEED_TYPE} in
		ericsson|ericsson_ml)
			export LOADCOMPLETE="${DATADIR}/${FEED_TYPE}${YYYYMMDD}.complete"
			export PREVIOUS_LOAD="${DATADIR}/${FEED_TYPE}${pYYYYMMDD}.complete"
			;;
		*)
			;;
	esac

#-----------------------------------------------------------------------

	rm -f ${DELDONE}
	rm -f ${LOADCOMPLETE}
#	rm -f ${JOBCOMPLETE}

export StageFile1=${DATADIR}/run_${FEED_TYPE}_${MKT}${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}.currstage
export TempStageFile1=$DATADIR/run_${FEED_TYPE}_${MKT}${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}.tempstage
export StageFile2=${DATADIR}/run_${FEED_TYPE}_${MKT}_${PROCESSYEAR}${PROCESSMONTH}${PROCESSDAY}.readstage

echo "-----------------Stage Files----------------------------"|tee -a ${HznLOG}
echo "StageFile1: ${StageFile1}"|tee -a ${HznLOG}
echo "StageFile2: ${StageFile2}"|tee -a ${HznLOG}
echo "TempStageFile1: ${TempStageFile1}"|tee -a ${HznLOG}
echo "------------------------------------------------------------------"|tee -a ${HznLOG}
export ENDTIME=

if [ -s ${StageFile1} ]
then
	echo "WARNING, the stage file ${StageFile1} exists!" | tee -a ${HznLOG}
	echo "Thus, starting at section indicated by this file!" | tee -a ${HznLOG}
	export JOB_INFO="ReRUNNING: ${ALLARGS}"
	JobStage "ReRUNNING"
	echo "**********Continue Existing RUN PLAN*********" | tee -a ${HznLOG}
	cat ${StageFile1} | tee -a ${HznLOG}
	echo "**************end Existing RUN PLAN***********" | tee -a ${HznLOG}
else
	export STARTTIME=`dtx`
	LSTAGE="STARTING"
	if [ ${DOSTAGE} ] || [ $STARTSTAGE ]
	then
		if [ ${DOSTAGE} ]
		then
		 echo "You have requested to perform stage: ${DOSTAGE} ..." | tee -a ${HznLOG}
		 if [[ "$FEED_TYPE" = "cpc_to_tlg" ]]; then
			 case ${DOSTAGE} in
				LOOK)                           # LOOK STAGE
				   echo "LOOK"     > ${StageFile1} ;;
				EXTRACT)                        # EXTRACCT STAGE
				   echo "EXTRACT"  > ${StageFile1} ;;
				SEND)                           # SEND STAGE
				   echo "SEND"     > ${StageFile1} ;;
				CLEANUP)                        # CLEANUP STAGE
				   echo "CLEANUP"  > ${StageFile1} ;;
				*) echo "Invalid Do Stage!  Must be look, extract, send or cleanup."  | tee -a ${HznLOG}
					USAGE
					;;
			 esac
		 elif [[ "$FEED_TYPE" = "hznrep_ccpm_wireless" ]]; then
			 case ${DOSTAGE} in
				LOOK)                           # LOOK STAGE
				   echo "LOOK"     > ${StageFile1} ;;
				LOAD)                               # LOAD STAGE
				   echo "LOAD"     > ${StageFile1} ;;
				EXTRACT)                        # EXTRACCT STAGE
				   echo "EXTRACT"  > ${StageFile1} ;;
				SEND)                           # SEND STAGE
				   echo "SEND"     > ${StageFile1} ;;
				CLEANUP)                        # CLEANUP STAGE
				   echo "CLEANUP"  > ${StageFile1} ;;
				*) echo "Invalid Do Stage!  Must be look, load, extract, send or cleanup."  | tee -a ${HznLOG}
					USAGE
					;;
			 esac
		  else
			 case ${DOSTAGE} in
				LOOK)                           # LOOK STAGE
				   echo "LOOK"     > ${StageFile1} ;;
				LOAD)                               # LOAD STAGE
				   echo "LOAD"       > ${StageFile1} ;;
				#CALC)                               # CALC (BAN) STAGE
				#  echo "CALC_BAN"       > ${StageFile1} ;;
				CLEANUP)                               # LOAD STAGE
				   echo "CLEANUP"       > ${StageFile1} ;;
				*) echo "Invalid Start Stage!  Must be look, load or cleanup."  | tee -a ${HznLOG}
					USAGE
					;;
			 esac
		  fi
		else
		 echo "You have requested to begin at stage: ${STARTSTAGE} ..." | tee -a ${HznLOG}
		 if [[ "$FEED_TYPE" = "cpc_to_tlg" ]]; then
			 case ${STARTSTAGE} in
				LOOK)                           # LOOK STAGE
					echo "LOOK"      > ${StageFile1}
					echo "EXTRACT"  >> ${StageFile1}
					echo "SEND"     >> ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				EXTRACT)                        # EXTRACT STAGE
					echo "EXTRACT"   > ${StageFile1}
					echo "SEND"     >> ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				SEND)                           # SEND STAGE
					echo "SEND"      > ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				CLEANUP)                        # CLEANUP STAGE
					echo "CLEANUP"   > ${StageFile1}
					;;
				*) echo "Invalid Start Stage!  Must be look, extract, send or cleanup."  | tee -a ${HznLOG}
					USAGE
					;;
			 esac
		 elif [[ "$FEED_TYPE" = "hznrep_ccpm_wireless" ]]; then
			 case ${STARTSTAGE} in
				LOOK)                           # LOOK STAGE
					echo "LOOK"      > ${StageFile1}
					echo "LOAD"     >> ${StageFile1}
					echo "EXTRACT"  >> ${StageFile1}
					echo "SEND"     >> ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				LOAD)                           # LOAD STAGE
					echo "LOAD"      > ${StageFile1}
					echo "EXTRACT"  >> ${StageFile1}
					echo "SEND"     >> ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				EXTRACT)                        # EXTRACT STAGE
					echo "EXTRACT"   > ${StageFile1}
					echo "SEND"     >> ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				SEND)                           # SEND STAGE
					echo "SEND"      > ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				CLEANUP)                        # CLEANUP STAGE
					echo "CLEANUP"   > ${StageFile1}
					;;
				*) echo "Invalid Start Stage!  Must be look, extract, send or cleanup."  | tee -a ${HznLOG}
					USAGE
					;;
			 esac
		  else
			 case ${STARTSTAGE} in

				LOOK)                           # FILTER STAGE
					echo "LOOK"      > ${StageFile1}
					echo "LOAD"     >> ${StageFile1}
					#if [[ "$FEED_TYPE" = "calc_ban" ]]; then
					#	echo "CALC_BAN"     >> ${StageFile1}
					#fi
					echo "CLEANUP"  >> ${StageFile1}
					;;
				LOAD)                               # LOAD STAGE
					echo "LOAD"      > ${StageFile1}
					#if [[ "$FEED_TYPE" = "calc_ban" ]]; then
					#	echo "CALC_BAN"     >> ${StageFile1}
					#fi
					echo "CLEANUP"     >> ${StageFile1}
					;;
				#CALC_BAN)                               # LOAD STAGE
					#if [[ "$FEED_TYPE" = "calc_ban" ]]; then
					#	echo "CALC_BAN"     >> ${StageFile1}
					#fi
				#	echo "CLEANUP"     >> ${StageFile1}
				#	;;
				CLEANUP)                               # LOAD STAGE
					echo "CLEANUP"     > ${StageFile1}
					;;
				*) echo "Invalid Start Stage!  Must be look, load or cleanup."  | tee -a ${HznLOG}
					USAGE
					;;
			esac
		  fi
		fi
	else
		echo "Creating stage file ${StageFile1}" | tee -a ${HznLOG}
		echo "LOOK"      > ${StageFile1}
		if [[ "$FEED_TYPE" = "cpc_to_tlg" ]]; then
			echo "EXTRACT"  >> ${StageFile1}
			echo "SEND"     >> ${StageFile1}
		elif [[ "$FEED_TYPE" = "hznrep_ccpm_wireless" ]]; then
			echo "LOAD"     >> ${StageFile1}
			echo "EXTRACT"  >> ${StageFile1}
			echo "SEND"     >> ${StageFile1}
		else
			echo "LOAD"     >> ${StageFile1}
			#if [[ "$FEED_TYPE" = "calc_ban" ]]; then
			#	echo "CALC_BAN"     >> ${StageFile1}
			#fi
		fi
		echo "CLEANUP"     >> ${StageFile1}
	fi
	export JOB_INFO="${ALLARGS}"
	JobStage ${LSTAGE}
	echo "****************RUN PLAN*************" | tee -a ${HznLOG}
	cat ${StageFile1} | tee -a ${HznLOG}
	echo "**************end RUN PLAN***********" | tee -a ${HznLOG}
fi

export ENDTIME=`dtx`
JobStage "COMPLETE"

##########################################################################
##########################################################################
#-------------------------------------------------
#	Now run the stages
#------------------------------------------------
Run_Script
#------------------------------------------------
echo "End of  ${0} ..." | tee -a ${HznLOG}

CheckOracle
Clean_Exit 0
