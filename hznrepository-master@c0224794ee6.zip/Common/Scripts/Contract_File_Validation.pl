#!/usr/bin/perl -w
################################################################################
#
# This script was created to validate the Contract files, which are being
# loaded into the  Repository
#
# File layout will contain one header records, any number of data records, plus
# a trailer record...
# ~ Header Record : Record Type|File Date|File Name 
# ~ Header Example: HDR|01-Feb-19|Contract20190201_daily.dat
# ~ Trailer Record : Record Type|Record Count
# ~ Trailer Example: TRL|23334
# ~ Initial creation
#a  02-19-2019 -- Baktha Venkadachalam
################################################################################

use strict ;
use File::Basename ;

################################################################################
# Usage
################################################################################

sub fUsage_Help ()
{
    my $scriptName = basename($0) ;

    print STDERR <<"END_OF_USAGE";

    Usage:  $scriptName  <Input Date File>  <Output Data File>

END_OF_USAGE
}

#=======================================
# Validate input parameters
#=======================================
if ( scalar( @ARGV ) != 2 )
{
    fUsage_Help();
    exit 1;
}

################################################################################

my $DateStamp = `date "+%Y-%m-%d %H:%M:%S"` ;
chomp( $DateStamp ) ;
print "\n### Program starting at: $DateStamp\n\n" ;

my $inFile = $ARGV[0] ;
my $outFile = $ARGV[1] ;

my $inFile_basename = basename($inFile) ;

my $cntDataRecs  = 0 ;
my $cntInputRecs  = 0 ;
my $recIn ;
my $header_FileName ;
my $header_ProcessDate ;
my $trailer_DataRecCnt ;
my $lineLgth ;
my $holdRec ;

print "Reading input from:  $inFile\n\n" ;
open(DATA_IN,"$inFile")   ||  die ("The Input Data File could not be opened.\n");

print "Writing to: $outFile\n\n" ;
open(DATA_OUT,">$outFile")   ||  die ("The Output Data File could not be opened.\n");


# Read the 1st header record - File Name
if ( defined( $recIn = <DATA_IN> ) )
{
    $cntInputRecs += 1 ;

    chomp( $recIn ) ;

    print "Input File baseName: $inFile_basename\n" ;

	my @header = split(/\|/,$recIn,-1);
	print "Header Record Type: $header[0]\n";
	print "Header File Date: $header[1]\n";
	print "Header File Name: $header[2]\n";

	chop($header[2]);

	if ( $header[0] ne "HDR" ) 
	{
	    print "\n### ERROR: Not correct file header found!\n\n" ;
        exit 3 ;
	}

    if ( $inFile_basename =~ $header[2])
    {
        print "Matched date on file names!\n\n" ;
    }
    else
    {
        print "ERROR: Mismatched date on File Names!  Header rec# 1: $recIn\n\n" ;
        exit 5 ;
    }
}
else
{
    print "\n### ERROR: No file header found!\n\n" ;
    exit 3 ;
}



# Read the next input record - 1st data record or trailer record...
if ( defined( $recIn = <DATA_IN> ) )
{
    $cntInputRecs += 1 ;

    # don't know what this record is, yet...
    # it could be the first data record, or it could be the trailer record
    $holdRec = $recIn ;
}
else
{
    print "\n### ERROR: missing Trailer record!\n\n" ;
    exit 9 ;
}


# Read the remainder of the records from the file...
while( defined( $recIn = <DATA_IN> ) )
{
    $cntInputRecs += 1 ;
    $cntDataRecs += 1 ;

    # $holdRec must be a data record... so write it out.
    print DATA_OUT $holdRec ;

    # hold the latest input record...
    $holdRec = $recIn ;
}

close DATA_IN ;
close DATA_OUT ;

# If I got here... then I must have run out of input records...
# ... and the trailer record must be in $holdRec...

# clean up the trailer record...
chomp( $holdRec ) ;

my @trailer = split(/\|/,$holdRec,-1);
print "Trailer Record Type: $trailer[0]\n";
print "Trailer Record Count: $trailer[1]\n";

# Validate record type

if ($trailer[0] ne "TRL") 
{
	print "\n### ERROR: not correct Trailer record!\n\n" ;
    exit 9 ;
}

# Validate record counts...
if ( $cntDataRecs != $trailer[1] )
{
    print "Accumulated data record count: $cntDataRecs\n" ;
    print "Count from trailer record:     $holdRec\n" ;

    print "\n### ERROR: record counts do not match!\n\n" ;
    exit 11 ;
}
else
{
    print "Record counts match!\n" ;
}

print "\nTotal input records read:   $cntInputRecs \n" ;

print "\nTotal data records read:    $cntDataRecs \n" ;

$DateStamp = `date "+%Y-%m-%d %H:%M:%S"` ;
chomp( $DateStamp ) ;
print "\n### Program finished at: $DateStamp\n\n" ;

exit 0 ;

