#!/bin/ksh
#send_cross_upg.sh 
#######################################################################
#This section is for declaring the global variables.
STAGES="EXTRACT DISTRIBUTE CONFIRM_SUCCESS CLEANUP";
BASESCRIPT=`basename $0`
SCRIPTNAME=`echo ${BASESCRIPT} | cut -f 1 -d . `
FEED_TYPE="csi_crossupg"
#-------------------include section-----------------------
. ${HORIZON_BIN}/HznRep_common.inc
. ${HORIZON_BIN}/file_transfer.inc
#-------------------end include section-----------------------

###########################################################################

function USAGE
{
#---------------------------------------------------------
#		Set up USAGE statement
#---------------------------------------------------------
        echo "------------------------------Usage----------------------------------"
	echo "${BASESCRIPT}: -e<Env> [-r<YYYYMMDD>]  [-S<Stage> / -s<Stage>] [-M] "|tee -a ${HznLOG}
	echo "-e<env>   (Run in the specified environment - dev |sys |qc " |tee -a ${HznLOG}
	echo "    		|uat | tst | prod )" |tee -a ${HznLOG}
	echo "---Optional--------" |tee -a ${HznLOG}
	echo "-S<stage> (Process only this stage: $STAGES) " |tee -a ${HznLOG}
	echo "-s<stage> (Start from this stage: $STAGES)" |tee -a ${HznLOG}
	echo "-M<Market> (Distribute ONLY to this market. Default is ALL mkts)  " |tee -a ${HznLOG}
	echo "-r<YYYYMMDD> *Only for resend -(ReExtract - previously extracted data. Record MUST exist!)  " |tee -a ${HznLOG}
        echo "	-------------------------------------------------"
	echo "e.g."
        echo "	-------------------------------------------------"
        echo "		Examples for daily "
        echo "	-------------------------------------------------"
	echo "--daily--		${BASESCRIPT} -edev "
	echo "--Only--		${BASESCRIPT} -edev -SEXTRACT "
        echo "***Note date is NOT needed."
        echo "	-------------------------------------------------"
        echo "		Examples for ReSend "
        echo "	-------------------------------------------------"
	echo "--reExtract YYYYMMDD & send to ALL mkts--"
	echo "--resend ALL--		${BASESCRIPT} -edev -r20130430 "
	echo "--reExtract YYYYMMDD & resend only to ALH--"
	echo "--resend ALH--	${BASESCRIPT} -edev -r20130430 -MALH "
	echo "--resend existing csiCrossUpgrade20130430_daily.dat only to ALH--"
	echo "--resend ALH--	${BASESCRIPT} -edev -r20130430 -MALH -SDISTRIBUTE"
        echo "----------------------------end Usage-------------------------------"
        exit 97
}	#end setupUsage

###########################################################################

function setup_select
{
	WriteLn "$(dtx) Starting setup_select------------------------" 
#---------------------------------------------------------
#		Set up SELECT from the table
#---------------------------------------------------------
	WriteLn "-----------------Before chknbr-----------------"
	chknbr "LAST_REC" ${LAST_REC} 
	WriteLn "-----------------After chknbr-----------------"
	WriteLn "RESEND: ${RESEND}"
	WriteLn "START_SEQ: ${START_SEQ}"
	WriteLn "END_SEQ: ${END_SEQ}"
	WriteLn "LAST_REC: ${LAST_REC}"
#------------------
	if [[ -z ${LAST_REC} ]]; then
		WriteLn "LAST_REC now set to 0."
		LAST_REC=0
	fi
	if [[ -z ${START_SEQ} ]]; then
		WriteLn "START_SEQ now set to 0."
		START_SEQ=0
	fi
	if [[ -z ${END_SEQ} ]]; then
		WriteLn "END_SEQ now set to 0."
		END_SEQ=0
	fi
#------------------
	export SPOOLFILE=${HZN_DATA}/${OFILE}
	WriteLn "$(dtx) SPOOLFILE=${SPOOLFILE} " 
	echo "spool ${SPOOLFILE} ; " >${SQLCMD}
	echo "set termout off ; " >>${SQLCMD}
	echo "set echo off ; " >>${SQLCMD}
	echo "set heading off ; " >>${SQLCMD}
	echo "set pagesize 0  ; " >>${SQLCMD}
	echo "set trimspool on ; " >>${SQLCMD}
	echo "set feedback on ; " >>${SQLCMD}
	echo "set linesize ${REC_LEN}  ; " >>${SQLCMD}
#----------------------------------------------------
	echo "SELECT csi_cross_upg_data_key||'|'|| trim(effective_date)||'|'||  " >>${SQLCMD}
#-----------Add SKU as NULL after upgrade_ban (***look for '||' )
#---------------------------------------------------------------------------------------------------:
	echo "trim(upgrade_mobile)||'|'|| trim(upgrade_ban)||trim(billing_market_code)||'||'|| trim(imei)||'|'||  " >>${SQLCMD}
#-----------Add model_desc as NULL after model (***look for '||' )
#----------------------------:
	echo "trim(model)||'||'|| trim(contract_term)||'|'|| trim(device_mobile)||'|'||  " >>${SQLCMD}
	echo "trim(device_ban)||trim(billing_market_code)||'|'|| trim(dealer_code)||'|'|| trim(serial_type)||'|'||  " >>${SQLCMD}
	echo "trim(product_type) " >>${SQLCMD}
	echo "FROM csi_cross_upg_data " >>${SQLCMD}
	if [[ ${RESEND} == YES && ${START_SEQ} -gt 0 ]]; then
		WriteLn "-----------------Before chknbr-----------------"
		chknbr "START_SEQ" ${START_SEQ} 
		WriteLn "-----------------After chknbr-----------------"
		WriteLn "-----------------Before chknbr-----------------"
		chknbr "END_SEQ" ${END_SEQ} 
		WriteLn "-----------------After chknbr-----------------"
		echo "WHERE csi_cross_upg_data_key between ${START_SEQ} and  ${END_SEQ} " >>${SQLCMD}
	else
		echo "WHERE csi_cross_upg_data_key > ${LAST_REC} " >>${SQLCMD}
	fi
#----------------------------------------------------
#	echo ${WhereClause} >>${SQLCMD}
#	echo ${EndWhereClause} >>${SQLCMD}
#----------------------------------------------------
	echo "Order by csi_cross_upg_data_key; " >>${SQLCMD}
	echo "spool off;" >>${SQLCMD}
	echo "exit ; " >>${SQLCMD}
	WriteLn "$(dtx) end setup_select------------------------" 
}	#end setup_select

###########################################################################

function chknbr
{
	typeset -i NBR
	VNBR="$1"
	NBR=$2
	if [[ -z ${NBR} ]]
	then
		WriteLn "***Error***chknbr - NBR is empt >${NBR}< VNBR >${VNBR}<" 
		exit 27
	fi
	if [[ "${NBR}" = ?([+-])+([0-9]) ]]
	then
		WriteLn "${VNBR} is a number ${NBR}" 
	else
		WriteLn "***Error*** ${VNBR} is NOT a number [${NBR}]  !" |
		Error_Exit 97
	fi
}	#end chknbr

###########################################################################

function get_max
{
	WriteLn " Entered get_max--------------------------------------" 
	WriteLn "--------------------------------------------------------------" 
	WriteLn "SQLLOG: ${SQLLOG} " 
	WriteLn "SQLCMD: ${SQLCMD} " 
	WriteLn "SQLINFO: ${SQLINFO} " 
	WriteLn "--------------------------------------------------------------" 
	echo "spool ${SQLINFO} ; " >${SQLCMD}
	echo "set termout off ; " >>${SQLCMD}
	echo "set echo off ; " >>${SQLCMD}
	echo "set heading off ; " >>${SQLCMD}
	echo "set pagesize 0  ; " >>${SQLCMD}
	echo "set trimspool on ; " >>${SQLCMD}
#----------------------------------------------------
	echo "SELECT max(end_index) from data_track " >> ${SQLCMD} 
	echo "WHERE extract_type = 'HznCSI';" >> ${SQLCMD} 
	echo "exit;" >> ${SQLCMD}
	WriteLn " ---------------------SQLCMD---------------------" 
	cat ${SQLCMD} >> ${HznLOG}
	WriteLn " ---------------------end SQLCMD---------------------" 
#----------------------------------------------------
	${SQLSTART} @${SQLCMD} > ${SQLLOG}

	WriteLn " -------Before CheckOracle-----------" 
	cat_log ${SQLLOG} 
	CheckOracle ${SQLLOG}
	WriteLn " -------After CheckOracle-----------" 
	
	NoRowsSelected="no rows selected"

	rowcount=0
	while read THEKEY 
	do
		WriteLn "Row: ${rowcount} ) ${THEKEY}"
		((rowcount=rowcount+1))
		if [[ -z ${THEKEY} ]]
		then
			WriteLn "Empty String Continue Row: ${rowcount} ) -->${THEKEY}<--"
			continue
		else
			export LAST_REC=${THEKEY}
			if [ "${LAST_REC}" =  "${NoRowsSelected}" ]; then
				WriteLn "***get_max - Invalid end_index <${LAST_REC}>  !" 
                                START_SEQ=0
                                END_SEQ=0
                                LAST_REC=0
			else
				export LAST_REC=${THEKEY}
				WriteLn "LAST_REC: ${LAST_REC}"
			fi
		fi
	done < ${SQLINFO}
	WriteLn " --------------------------------------End of get_max"
	WriteLn "-----------------Before chknbr-----------------"
	chknbr "LAST_REC" ${LAST_REC} 
	WriteLn "-----------------After chknbr-----------------"
#--------------------------------------
	rm -f ${SQLINFO}
	rm -f ${SQLCMD}
	rm -f ${SQLLOG}
}	#end get_max

###########################################################################

function get_index
{
	WriteLn " Entered get_index--------------------------------------" 
	DT=$1
	if [[ -z ${DT} ]]; then
		echo "DT: $DT"
		exit 7
	fi
	SQLINFO1=${HZN_DATA}/${SCRIPTNAME}_$$.sqlnfo1
	WriteLn "--------------------------------------------------------------" 
	WriteLn "SQLLOG: ${SQLLOG} " 
	WriteLn "SQLINFO1: ${SQLINFO1} " 
	WriteLn "SQLCMD: ${SQLCMD} " 
	WriteLn "--------------------------------------------------------------" 
	echo "spool ${SQLINFO1} ; " >${SQLCMD}
	echo "set termout off ; " >>${SQLCMD}
	echo "set echo off ; " >>${SQLCMD}
	echo "set heading off ; " >>${SQLCMD}
	echo "set pagesize 0  ; " >>${SQLCMD}
	echo "set trimspool on ; " >>${SQLCMD}
#--------------------------------------------------------------------------------------

	echo "SELECT start_index, end_index, data_track_key, re_send " >> ${SQLCMD} 
	echo "from data_track " >> ${SQLCMD} 
	echo "WHERE extract_type = 'HznCSI' " >> ${SQLCMD} 
	echo "and extract_date = '${YYYYMMDD}' " >> ${SQLCMD} 
	echo "and re_send = (select max(re_send) " >> ${SQLCMD} 
	echo "	from data_track " >> ${SQLCMD} 
	echo "	where extract_date = '${YYYYMMDD}' " >> ${SQLCMD} 
	echo "	and extract_type = 'HznCSI'); " >> ${SQLCMD} 
#---------------------------------------------------------------------------------
#	echo "SELECT start_index, end_index " >> ${SQLCMD} 
#	echo "from data_track " >> ${SQLCMD} 
#	echo "WHERE extract_type = 'HznCSI'" >> ${SQLCMD} 
#	echo "and extract_date = '${YYYYMMDD}';" >> ${SQLCMD}
#---------------------------------------------------------------------------------
	echo "spool off ; " >>${SQLCMD}
	echo "exit;" >> ${SQLCMD}
#	WriteLn "------------------------------SQLSTART-----------------------------" 
#	WriteLn "SQLSTART: ${SQLSTART}"
#	WriteLn "------------------------------end SQLSTART-----------------------------" 
	WriteLn "------------------------------SQLCMD-----------------------------" 
	cat ${SQLCMD} |tee -a ${HznLOG}
	WriteLn "----------------------------end SQLCMD----------------------------" 
	${SQLSTART} @${SQLCMD} > ${SQLLOG}
#--------------------------------------------------------------------------------------
	ls -l ${SQLLOG} |tee -a ${HznLOG}
	ls -l ${SQLINFO1} |tee -a ${HznLOG}
	WriteLn "-------Before CheckOracle	SQLINFO1-----------" 
	cat_log "${SQLINFO1}"
	CheckOracle "${SQLINFO1}"
	WriteLn "-------After CheckOracle	SQLINFO1-----------" 
#--------------------------------------------------------------------------------------
	NoRowsSelected="no rows selected"
#--------------------------------------------------------------------------------------
	rowcount=0
	while read THEKEY 
	do
		((rowcount=rowcount+1))
		WriteLn "Row: ${rowcount} ) ${THEKEY}"
		if [[ -z ${THEKEY} ]]
		then
			WriteLn "Empty String Continue Row: ${rowcount} ) -->${THEKEY}<--"
			continue
		else
			WriteLn "***THEKEY: ${THEKEY}	compare with: ${NoRowsSelected}"
			if [ "${THEKEY}" ==  "${NoRowsSelected}" ]; then
				WriteLn "***No rows ! ****"
				WriteLn "***extract_date: <${YYYYMMDD}> not found !" 
                                START_SEQ=0
                                END_SEQ=0
                                LAST_REC=0
				WriteLn "Getting MAX sequence number sent!"
				if [[ ${RESEND} == YES ]]; then
					WriteLn "***Cannot resend as no record available!"
					Error_Exit 97
				else
					get_max
				fi
			else
				WriteLn "***This MUST have values ****"
				if [[ ${RESEND} == NO ]]; then
					WriteLn "***BUT This is a RESEND****"
					export START_SEQ=`echo ${THEKEY} | cut -f1 -d" " -s`
					export END_SEQ=`echo ${THEKEY} | cut -f2 -d" " -s`
					export LAST_REC=${END_SEQ}
					export DATA_KEY=`echo ${THEKEY} | cut -f3 -d" " -s`
					export RESEND_COUNT=`echo ${THEKEY} | cut -f4 -d" " -s`
					#---------------------------------------------------------------------------------
					WriteLn "START_SEQ: ${START_SEQ}"
					WriteLn "END_SEQ: ${END_SEQ}"
					WriteLn "LAST_REC: ${LAST_REC}"
					WriteLn "DATA_KEY: ${DATA_KEY}"
					WriteLn "RESEND_COUNT: ${RESEND_COUNT}"
					WriteLn "***RESEND permitted****"
					WriteLn "***Changing RERSEND to YES****"
					RESEND="YES"
				else
					export START_SEQ=`echo ${THEKEY} | cut -f1 -d" " -s`
					export END_SEQ=`echo ${THEKEY} | cut -f2 -d" " -s`
					export LAST_REC=${END_SEQ}
					export DATA_KEY=`echo ${THEKEY} | cut -f3 -d" " -s`
					export RESEND_COUNT=`echo ${THEKEY} | cut -f4 -d" " -s`
				fi
			fi
		fi
	done < ${SQLINFO1}
	WriteLn "START_SEQ: ${START_SEQ}"
	WriteLn "END_SEQ: ${END_SEQ}"
	WriteLn "LAST_REC: ${LAST_REC}"
	WriteLn "DATA_KEY: ${DATA_KEY}"
	WriteLn "RESEND_COUNT: ${RESEND_COUNT}"
	WriteLn "-----------------Before chknbr-----------------"
	chknbr "START_SEQ" ${START_SEQ} 
	chknbr "END_SEQ" ${END_SEQ} 
	chknbr "LAST_REC" ${LAST_REC} 
	WriteLn "-----------------After chknbr-----------------"
	WriteLn " --------------------------------------End of get_index"
#--------------------------------------
	rm -f ${SQLINFO1}	#spool file
	rm -f ${SQLCMD}
	rm -f ${SQLLOG}
#WriteLn "**********FORCED EXIT***********"
#exit 21
}	#end get_index

#######################################################################

function EXTRACT
{
	WriteLn "-------------------EXTRACT ------------------"
	#------------------------------------------------------------------------
	export JOB_INFO="EXTRACT - ${RESEND_DATE} [${YYYYMMDD}]"
	export STARTTIME=$(dtx)
	export ENDTIME=
	JobStage "STARTING"
	#------------------------------------------------------------
	get_index "${YYYYMMDD}"
	#------------------------------------------------------------
	#		Set up Select
	#--------------------------------------------------------
	setup_select
	#--------------------------------------------------------------
	WriteLn "$(dtx) SPOOLFILE:	$SPOOLFILE"
	#
	WriteLn "$(dtx) ------------------SQLCMD------------------"
	WriteLn "`cat ${SQLCMD}`"
	WriteLn "$(dtx) ------------------------------------------"
	WriteLn "$(dtx) ---------Starting above cmd---------"
	#---------------------------------------------------------
	#	Now Run the SQLCMD & Spool
	#---------------------------------------------------------
	WriteLn "$(dtx) ----------------Starting Extract --------------------------"
	${SQLSTART} @${SQLCMD}
	WriteLn "$(dtx) ----------------Ended  Extract --------------------------"
#--------------------------------------
#	4863 rows selected.
#--------------------------------------
	typeset -i ActualNbrOfRec
	ROW=`tail -4 ${SPOOLFILE}|grep "row.*selected"`
	export ActualNbrOfRec=`echo $ROW| cut -f1 -d" " -s`
	a=`wc -l ${SPOOLFILE} `
	NbrOfRec=`echo $a |cut -f1 -d"/" `
	TotalNbrOfRec=$NbrOfRec
	TotalRecLoaded=$ActualNbrOfRec
#	ActualNbrOfRec=$NbrOfRec-3
	WriteLn "***===========================================***"
	WriteLn "***Total number of lines: $TotalNbrOfRec "
	WriteLn "***Actual number of records: $ActualNbrOfRec "
	head -${ActualNbrOfRec} ${SPOOLFILE} >${OUTFILE}
	WriteLn "SPOOLFILE: ${SPOOLFILE}"
	WriteLn "***Total number of records: $TotalRecLoaded "
#---------------------------------------------------
	getSTART
#---------------------------------------------------
	WriteLn "***=================OUTFILE===================***"
	ls -l ${OUTFILE} | tee -a ${HznLOG}
	WriteLn "***=================endOUTFILE====================***"
        rm -f ${SPOOLFILE}
        rm -f ${SQLCMD}
	#---------------------------------------------------------
	export JOB_INFO="EXTRACT SUCCESSFULLY COMPLETED [ ${TotalRecLoaded} records ] - process id# ${PROCESSID}"
        WriteLn "${JOB_INFO}"
        export ENDTIME=$(dtx)
        JobStage "COMPLETE"
	#---------------------------------------------------------
	WriteLn "$(dtx) ------------------------------------"
	WriteLn "-------------end EXTRACT ------------------"
}	#end EXTRACT

#######################################################################

function DISTRIBUTE 
{
	WriteLn "-------------DISTRIBUTE------------------"
	
	TRANSFERCFG=$HORIZON_BIN/file_transfer.cfg
	REMOTEAPP="TELEGENCE"
	WriteLn "TRANSFERCFG: ${TRANSFERCFG}" 
	#------------------------------------------------------------------------
	export JOB_INFO="DISTRIBUTE - mkts: $MKT"
	export STARTTIME=$(dtx)
	export ENDTIME=
	JobStage "STARTING"
	#------------------------------------------------------------------------
	ERR_MKTS=""
	DONE_MKTS=""
	MKT_COUNT=0
	if [[ -z ${RUN_MKTS} ]]
	then
		cat ${TRANSFERCFG} |grep "${REMOTEAPP}" | while read aLine
		do 
			((MKT_COUNT+=1))
			Mkt=$(echo ${aLine} | cut -f1 -d, -s)
			RUN_MKTS="${RUN_MKTS} ${Mkt}"
		done
		WriteLn "*********Sending to ALL MKTs: "
		WriteLn "${RUN_MKTS}"
	else
		MKT_COUNT=1
		WriteLn "*********Only Sending to MKT: ${RUN_MKTS} "
	fi 
#--------------------------------------------------
	WriteLn "DISTRIBUTE file to mkts [${MKT_COUNT}]:"
	WriteLn "${RUN_MKTS}"
#--------------------------------------------------
	WriteLn "OUTFILE: ${OUTFILE}" 
	WriteLn "DATFILE: ${DATFILE} "
	WriteLn "REMOTEAPP: ${REMOTEAPP} "
	WriteLn "RUN_MKTS: ${RUN_MKTS}"
#--------------------------------------------------
	WriteLn "***=================OUTFILE===================***"
	ls -l ${OUTFILE} | tee -a ${HznLOG}
	WriteLn "***=================endOUTFILE====================***"
#--------------------------------------------------
	ErrCount=0
	for Mkt in ${RUN_MKTS}
	do 
		WriteLn "----------------------Sending Mkt: ${Mkt} ------------------------------"
		WriteLn "send_file_transfer {OUTFILE} {DATFILE} {REMOTEAPP} {Mkt}"
		send_file_transfer ${OUTFILE} ${DATFILE} ${REMOTEAPP} ${Mkt}
		RET=$?
		EndTime=$(dtx)
		WriteLn "Return Status from send_file_transfer is: ${RET} - EndTime: ${EndTime}"
		if [[ ${RET} != 0 ]]
		then
			WriteLn "Error ${RET} returned from send_file_transfer (${Mkt}), see log file ${HznLOG}" 
			echo "send_cross_upg.sh -r${YYYYMMDD} -M${Mkt} -SDISTRIBUTE " >>${SEND_REST}
			((ErrCount+=1))
			WriteLn "ErrCount: ${ErrCount} ${Mkt}"
			export ERR_MKTS="${ERR_MKTS} ${Mkt}"
		else
			WriteLn "send_file_transfer ended with return code: ${RET} & ErrCount: $ErrCount!" 
			export DONE_MKTS="${DONE_MKTS} ${Mkt}"
		fi
		CheckRunLog
		WriteLn "-----------------------Done! ------------------------------"
	done
	#---------------------------------------------------------
	#---------------------------------------------------------
	
	if [[ ${ErrCount} != 0 ]]
	then
		export JOB_INFO="DISTRIBUTE COMPLETED - process id# ${PROCESSID} ErrCount: ${ErrCount} ERR_MKTS: ${ERR_MKTS}"
		LN=$(echo $JOB_INFO |wc -c)
		if [[ $LN -gt 80 ]]; then
			JBINFO=$(echo $JOB_INFO |cut -c1-80)
			WriteLn "*JOB_INFO *warning* length greater than 80!!!"
			WriteLn "*JOB_INFO: ${JOB_INFO}"
			export JOB_INFO=$JBINFO
			WriteLn "*Now trimmed to: ${JOB_INFO}"
		fi
	else
#		export JOB_INFO="DISTRIBUTE SUCCESSFULLY COMPLETED - process id# ${PROCESSID} Mkts: ${DONE_MKTS}"
		if [[ -z ${MKT} ]]; then
			export JOB_INFO="DISTRIBUTE SUCCESSFULLY COMPLETED - process id# ${PROCESSID} ALL (${MKT_COUNT}) market(s)! "
		else
			export JOB_INFO="DISTRIBUTE SUCCESSFULLY COMPLETED - process id# ${PROCESSID} ${MKT} (${MKT_COUNT}) market! "
		fi
	fi
	WriteLn "${JOB_INFO}"
	export ENDTIME=$(dtx)
	JobStage "COMPLETE"
	#---------------------------------------------------------
	export MKT_COUNT=${MKT_COUNT}
	WriteLn "-------------end DISTRIBUTE (MKT_COUNT: ${MKT_COUNT})------------------"
}	#end DISTRIBUTE

###########################################################################

function CONFIRM_SUCCESS
{
	WriteLn " Entered CONFIRM_SUCCESS--------------------------------------" 
	#------------------------------------------------------------------------
	export JOB_INFO="CONFIRM_SUCCESS - Mkts: ${DONE_MKTS}"
	if [[ -z ${MKT} ]]; then
		export JOB_INFO="CONFIRM_SUCCESS -  ALL (${MKT_COUNT}) market(s)! "
	else
		export JOB_INFO="CONFIRM_SUCCESS -  ${MKT} (${MKT_COUNT}) market! "
	fi
	export STARTTIME=$(dtx)
	export ENDTIME=
	JobStage "STARTING"
	#------------------------------------------------------------------------
	chkSTART
	#------------------------------------------------------------
	chknbr "START_SEQ" ${START_SEQ} 
	chknbr "END_SEQ" ${END_SEQ} 
	#------------------------------------------------------------------------
	DataTrack
	#------------------------------------------------------------------------
	WriteLn "${JOB_INFO}"
	export ENDTIME=$(dtx)
	JobStage "COMPLETE"
	#---------------------------------------------------------
	WriteLn " end CONFIRM_SUCCESS--------------------------------------" 
}	#end CONFIRM_SUCCESS

###########################################################################

function DataTrack
{
#---------------------------
#---------------------------
	WriteLn "Logging Status: ${1}" 
	WriteLn "	DataTrack - RESEND_COUNT: ${RESEND_COUNT}"
	WriteLn "	DataTrack - START_SEQ: ${START_SEQ}"
	WriteLn "	DataTrack - END_SEQ: ${END_SEQ}"
	((SendCount=${RESEND_COUNT}+1))
	WriteLn "	DataTrack - SendCount: ${SendCount}"
#-----------------------------------------------------------
	if [[ ${START_SEQ} -lt 1 || ${END_SEQ} -lt ${START_SEQ} ]]; then
		chkSTART
	fi
	if [[ ${START_SEQ} -lt 1 || ${END_SEQ} -lt ${START_SEQ} ]]; then
		WriteLn "****WARNING*** Invalid sequence numbers"
		WriteLn "	START_SEQ: ${START_SEQ}"
		WriteLn "	END_SEQ: ${END_SEQ}"
		WriteLn "Perhaps file is already backed up, please restore:"
		WriteLn "	${HZN_DATA}/${DATFILE}"
		WriteLn "and try again."
		WriteLn "OR perhaps No records today!"
		WriteLn "Please check."
	fi
		
	#---------------------------------------------------------------
	# Create sql to insert into table
	#---------------------------------------------------------------
	echo "insert INTO data_track (" > ${SQLCMD}
	echo "extract_type, extract_date, re_send, start_index, " >> ${SQLCMD}
	echo "end_index, mod_user, mod_date) " >> ${SQLCMD}
	echo "VALUES" >> ${SQLCMD}
	echo "( 'HznCSI', '${YYYYMMDD}', ${SendCount}, ${START_SEQ}," >> ${SQLCMD}
	echo "'${END_SEQ}', '${BaseScriptname}', sysdate);" >> ${SQLCMD}
#------------------------------------
	echo "exit;" >> ${SQLCMD}			
	WriteLn "---------------SQLCMD---------------"
	cat ${SQLCMD} | tee -a ${HznLOG}
	WriteLn "---------------end SQLCMD---------------" 
	${SQLSTART} @${SQLCMD} > $SQLLOG
#------------------------------------

	WriteLn " -------Before CheckOracle-----------" 
	cat_log ${SQLLOG} 
	CheckOracle ${SQLLOG}
	WriteLn " -------After CheckOracle-----------" 
	
	rm -f ${SQLINFO}
	rm -f ${SQLCMD}
	rm -f ${SQLLOG}
}	#end DataTrack

###########################################################################

function CLEANUP
{
	WriteLn "$(dtx)	Starting CLEANUP stage-----${FEED_TYPE}-------------------" 
	WriteLn "The CLEANUP section" 
	export JOB_INFO="CLEANUP - ${FEED_TYPE}"
	export TotalRecLoaded=0
	export STARTTIME=`dtx`
	export ENDTIME=
	JobStage "STARTING"

	rm -rf ${HZN_DATA}/*$$.sql
	
	if [ -f ${HZN_DATA}/${DATFILE} ]; then
		WriteLn "Backing up OLD DATA file (${DATFILE}):" 
		mv ${HZN_DATA}/${DATFILE} ${HZN_DATA}/backup
		gzip -f ${HZN_DATA}/backup/${DATFILE}
		ls -l ${HZN_DATA}/backup/${DATFILE}* |tee -a $HznLOG
	fi


	OldLogFiles=${HZN_LOG}/${SCRIPTNAME}Temp_*.log
	LogCount=`ls -1 ${OldLogFiles} | grep "^/" | /usr/bin/wc -l`

	if [[ ${LogCount} -gt 0 ]]; then
		WriteLn "Removing Temp files (${OldLogFiles})"
		rm -f ${OldLogFiles}
	fi


	export ENDTIME=`dtx`
	JobStage "COMPLETE"
}	#end CLEANUP

###############################################################################

function getSTART
{
		WriteLn "getSTART - OUTFILE: ${OUTFILE}"
		a=`wc -l ${OUTFILE} `
		NbrOfRec=`echo $a |cut -f1 -d"/" `
		export TotalRecLoaded=${NbrOfRec}
		WriteLn "getSTART - NbrOfRec: $NbrOfRec  	TotalRecLoaded: $TotalRecLoaded"
		if [[ -s ${OUTFILE} ]]; then
			START_SEQ=`head -1 ${OUTFILE} |cut -f1 -d"|" -s`
			END_SEQ=`tail -1 ${OUTFILE} |cut -f1 -d"|" -s`
		else
			START_SEQ=${LAST_REC}
			END_SEQ=${LAST_REC}
			WriteLn "Size of file: ${OUTFILE}"
			WriteLn "Setting START_SEQ & END_SEQ to LAST_REC:[${LAST_REC}."
		fi
		WriteLn "getSTART - START_SEQ: ${START_SEQ}"
		WriteLn "getSTART - END_SEQ: ${END_SEQ}"
}

###############################################################################

function chkSTART
{
	WriteLn "Enetered chkSTART--------------------------------------------"
	start=0
	end=0
	if [[ -f ${HZN_DATA}/${DATFILE} ]]
	then
		start=`head -1 ${HZN_DATA}/${DATFILE} |cut -f1 -d"|" -s`
		end=`tail -1 ${HZN_DATA}/${DATFILE} |cut -f1 -d"|" -s`
		a=`wc -l ${HZN_DATA}/${DATFILE} `
		NbrOfRec=`echo $a |cut -f1 -d"/" `
		export TotalRecLoaded=${NbrOfRec}
		WriteLn "chkSTART - NbrOfRec: $NbrOfRec  	TotalRecLoaded: $TotalRecLoaded"
	else
		WriteLn "File does not exist: (${DATFILE})"
		if [[ ${START_SEQ} -gt 0 && ${END_SEQ} -ge ${START_SEQ} ]]; then
			WriteLn "-----------Good----------------"
			WriteLn "START_SEQ: ${START_SEQ}"
			WriteLn "END_SEQ: ${END_SEQ}"
			WriteLn "LAST_REC: ${LAST_REC}"
			WriteLn "-----------end Good----------------"
		else
			WriteLn "-----------Not Good----------------"
			WriteLn "START_SEQ: ${START_SEQ}"
			WriteLn "END_SEQ: ${END_SEQ}"
			WriteLn "LAST_REC: ${LAST_REC}"
			WriteLn "-----------end Not Good----------------"
		fi
		return
	fi
	WriteLn "START_SEQ: ${START_SEQ}	start: ${start}"
	WriteLn "END_SEQ: ${END_SEQ}	end: ${end}"
	WriteLn "LAST_REC: ${LAST_REC}	end: ${end}"
	if [[ ${START_SEQ} -lt ${start} ]]
	then
		export START_SEQ=${start}
		WriteLn "from file - START_SEQ: ${START_SEQ}"
	fi
	if [[ ${END_SEQ} -lt ${end} ]]
	then
		export END_SEQ=${end}
		WriteLn "from file - END_SEQ: ${END_SEQ}"
	fi
	if [[ ${LAST_REC} -lt ${end} ]]
	then
		export LAST_REC=${end}
		WriteLn "from file - LAST_REC: ${LAST_REC}"
	fi
	WriteLn "final START_SEQ: ${START_SEQ}	start: ${start}"
	WriteLn "final END_SEQ: ${END_SEQ}	end: ${end}"
	WriteLn "final LAST_REC: ${LAST_REC}	end: ${end}"
	WriteLn "final TotalRecLoaded: ${TotalRecLoaded}	"
	WriteLn "--------------------end chkSTART"
}

###########################################################################

#----------------------------------------
#		Check input parameters
#----------------------------------------
function chkParm
{
	WriteLn "$(dtx) Starting $0 (chkParm)------------------------" 

	export START_SEQ=0
	export END_SEQ=0
	export LAST_REC=0
#----------------------------------------------------------
	#[hltd094:na8166]/opt/app/users/na8166/HznRepository/Common/data/csi_crossupg>
	#TZ=GMT+24 date +%Y%m%d
	#20140131
	#YESTERDAY=`TZ=GMT+24 date +%Y%m%d`
#------------
	#[hltd094:na8166]/opt/app/users/na8166/HznRepository/Common/data/csi_crossupg>
	#export YESTERDAY=`perl -e '@T=localtime(time-86400);printf("%02d%02d%02d",($T[5]+1900),$T[4]+1,$T[3])'`; echo $YESTERDAY;
	#20140130
#----------------------------------------------------------
	YESTERDAY=`perl -e '@T=localtime(time-86400);printf("%02d%02d%02d",($T[5]+1900),$T[4]+1,$T[3])'`
	YYYYMMDD=${YESTERDAY}
	WriteLn "YESTERDAY: ${YESTERDAY}"
	WriteLn "YYYYMMDD: ${YYYYMMDD}"

	if [ -z $RUNENV ]; then
		WriteLn "***Error*** Missing Environment! " 
		USAGE 
	fi
#-----------------------------
#-----------------------------
	if [ -z ${RESEND_DATE} ]; then
		RESEND="NO"
		WriteLn "***Normal run NO resend DATE! " 
	else
		RESEND="YES"
		WriteLn "***ReSend run for ${RESEND_DATE}! " 
	fi
#----------------------------
	RUN_MKTS=""
	if [[ -z ${MKT} ]]
	then
		RUN_MKTS=""
	else
		RUN_MKTS="${MKT}"
	fi
	WriteLn "$(dtx) ------Command line-------------- " 
	WriteLn "$(dtx) ${BASESCRIPT} ${ALLARGS}" 
	WriteLn "$(dtx) -------------------End of Command line" 
	#------------------
	WriteLn "$(dtx) ------------------Parameters----------------------"
	WriteLn "$(dtx) RUNENV:	$RUNENV"
	WriteLn "$(dtx) ---------------------------------"
	WriteLn "$(dtx) HORIZON_BIN:	$HORIZON_BIN"
	WriteLn "$(dtx) RESEND_DATE:	$RESEND_DATE"
	WriteLn "$(dtx) MKT:	$MKT"
	WriteLn "$(dtx) RUN_MKTS:	$RUN_MKTS"
	WriteLn "$(dtx) ---------------------------------"
	WriteLn "$(dtx) HznLOG:	$HznLOG"
	WriteLn "$(dtx) ---------------------------------"
#*************************************
#-----------------------------------------------------------------------	
#	get_max
#-----------------------------------------------------------------------	
	tYYYYMMDD=`date +%Y%m%d`
	if [[ ! -z ${RESEND_DATE} ]]; then
		WriteLn "Input value YYYYMMDD: ${YYYYMMDD} must be a valid resend!"
		YYYYMMDD=${RESEND_DATE}
	else
		WriteLn "Using YESTERDAY value YYYYMMDD: ${YYYYMMDD}"
	fi
	#------------------------------------------------------------
	export PROCESSYEAR=`echo $YYYYMMDD | cut -c1-4`
	export PROCESSMONTH=`echo $YYYYMMDD | cut -c5-6`
	WriteLn "PROCESSYEAR: ${PROCESSYEAR}"
	WriteLn "PROCESSMONTH: ${PROCESSMONTH}"
	#------------------------------------------------------------
#	get_index "${YYYYMMDD}"
	#------------------------------------------------------------
	export DATFILE="csiCrossUpgrade${YYYYMMDD}_daily.dat"
	export OFILE=CSI_DATA.lst
	export OUTFILE=${HZN_DATA}/${DATFILE} 
	#------------------------------------------------------------
	#		Set up Final Log
	#------------------------------------------------------------
	LogFile=${HZN_LOG}/${SCRIPTNAME}_${YYYYMMDD}.log
	OldLogFiles=${SCRIPTNAME}_*.log
	LogCount=`ls -1 ${HZN_LOG}/${OldLogFiles} | grep "^/" | /usr/bin/wc -l`

	if [[ ${LogCount} -gt 0 ]]; then
		mv ${HZN_LOG}/${OldLogFiles} ${HZN_LOG}/backup
		gzip -f ${HZN_LOG}/backup/${OldLogFiles}
		WriteLn "****Backed up ${LogCount} log files!"
	else
		WriteLn "---------No logs to backup [${OldLogFiles}]"
	fi
	#------------------------------------------------------------
	WriteLn "HznLOG:	$HznLOG"
	WriteLn "LogFile:	$LogFile"
	WriteLn "OldLogFiles:	$OldLogFiles"
	WriteLn "-------------------------------------------------------"
	mv $HznLOG $LogFile
	export HznLOG=$LogFile
	WriteLn "-------------------------------------------------------"
	WriteLn "---------Log file moved! ----------------------------------------------"
	WriteLn "----------------------------------Info---------------------"
	WriteLn "DATFILE:	$DATFILE"
	WriteLn "OFILE:	$OFILE"
	WriteLn "-------------------------------------------------------"
	#------------------------------------------------------------
}	#end chkParm

###########################################################################

#######################################################################
#*****************************************************************************
#		M A I N
#*****************************************************************************
#---------------------------------------------------------
if [ -z $1 ]; then
	USAGE
fi
#----------------------------------------------------------------
export TABLENAME="csi_cross_upg_data"
export CURRENT_STAGE=Init
#----------------------------------------
export zMSG=ErrorMsgEmailList
export cMSG=
export DELETE_CLAUSE=
export DELETE_TRAN=
export NbrOfRecsDeleted=0
export TotalRecLoaded=0
export ErrorData=0
export ErrorWhen=0
export ErrorNull=0
export DO_ANALYZE="N"
#----------------------------------------------------------------
export HZN_LOG="${HORIZON_LOG}/${FEED_TYPE}"
export HZN_DATA="${HORIZON_DATA}/${FEED_TYPE}"
export HZN_CTL="${HORIZON_HOME}/ctl"
export HZN_BIN="${HORIZON_BIN}"
export CTLDIR="${HZN_CTL}"
export DATADIR="${HZN_DATA}"
export LOGDIR="${HZN_LOG}"
#--------------------------------------------------------------
export REC_LEN=760
#--------------------------------------------------------------
#--------------------------------------------------------
#		Make directories as needed
#--------------------------------------------------------
if [[ ! -d ${HZN_DATA}/backup ]]; then
	mkdir -p ${HZN_DATA}/backup
fi
if [[ ! -d ${HZN_LOG}/backup ]]; then
	mkdir -p ${HZN_LOG}/backup
fi
#--------------------------------------------------------------
export SQLCMD=${HZN_DATA}/${SCRIPTNAME}_cmd_$$.sql
export SQLLOG=${HZN_DATA}/${SCRIPTNAME}_$$.sqllog
export SQLINFO=${HZN_DATA}/${SCRIPTNAME}_$$.sqlnfo
export HznLOG=${HZN_LOG}/${SCRIPTNAME}Temp_$$.log
export templog=$HznLOG
export SEND_REST="${HZN_LOG}/send_rest_xupg.sh"
export START_SEQ=0
export END_SEQ=0
export LAST_REC=0
#--------------------------------------------------------------
export TimeStart=`dtx`
#--------------------------------------------------------------
umask 002
export LOCALBOX="`uname -n`"
export PROCESSID="$$-${LOCALBOX}"
export PROCESSID=$$
export ENDTIME=
export STARTTIME=`dtx`
export SERVER="${HOSTNAME}"
export LOADENV="${RUNENV}"
export NO_JOB_INFO="DEFINED"
#----------------------------------------------------------------
#------------------------CLEAR--------------------------------
#	Normally NO to allow existing stage files control
#	When CLEAR=YES - ReMOVE all stage file
#------------------------end CLEAR--------------------------------
export CLEAR="NO"
#--------------------------------------------------------
#		Get Input parameters
#--------------------------------------------------------
while getopts e:r:M:s:CS:v: OPT; 
do
	case $OPT in
		C) export CLEAR="YES" ;;
		e) export RUNENV=`echo $OPTARG | tr '[A-Z]' '[a-z]'`;;
		M) export MKT=`echo $OPTARG | tr '[a-z]' '[A-Z]'`;;
		r) export RESEND_DATE=`echo $OPTARG`;;
		S) export DOSTAGE=`echo ${OPTARG} | tr '[a-z]' '[A-Z]'`;;
		s) export STARTSTAGE=`echo ${OPTARG} | tr '[a-z]' '[A-Z]'`;;
		v) export VERBOSE=${OPTARG};;
		*)	USAGE
			;;
	esac
done

########################################
#echo "-e<env> (Run in the specified environment - dev |sys |qc " |tee -a ${HznLOG}
#echo "    		|uat | tst | prod )" |tee -a ${HznLOG}
########################################
echo "`dtx`---Starting ${BaseScriptname} ----------------------------------"|tee ${HznLOG}
echo "BaseScriptname: ${BaseScriptname}" |tee -a ${HznLOG}
echo "SCRIPTNAME: ${SCRIPTNAME}" |tee -a ${HznLOG}
#--------------------------------------------------------------
echo "	$0 " |tee -a ${HznLOG}
echo "`dtx`-----------------------------------------------------"|tee -a ${HznLOG}
echo "	templog: ${templog} " |tee -a ${HznLOG}
echo "	HznLOG: ${HznLOG} " |tee -a ${HznLOG}
echo "`dtx`-----------------------------------------------------"|tee -a ${HznLOG}
echo "	HZN_BIN=${HZN_BIN}" |tee -a ${HznLOG}
echo "	HZN_LOG=${HZN_LOG}" |tee -a ${HznLOG}
echo "	HZN_DATA=${HZN_DATA}" |tee -a ${HznLOG}
echo "	HZN_CTL=${HZN_CTL}" |tee -a ${HznLOG}
echo "`dtx`-----------------------------------------------------"|tee -a ${HznLOG}
echo "	CTLDIR=${CTLDIR}" |tee -a ${HznLOG}
echo "	DATADIR=${DATADIR}" |tee -a ${HznLOG}
echo "	LOGDIR=${LOGDIR}" |tee -a ${HznLOG}
echo "	BACKDIR=${BACKDIR}" |tee -a ${HznLOG}
echo "	ALLARGS=${ALLARGS}" |tee -a ${HznLOG}
echo "`dtx`-----------------------------------------------------"|tee -a ${HznLOG}
echo "	BaseScriptname: ${BaseScriptname}" |tee -a ${HznLOG}
echo "	SCRIPTNAME: ${SCRIPTNAME}" |tee -a ${HznLOG}
echo "	NO_JOB_INFO: ${NO_JOB_INFO}" |tee -a ${HznLOG}
echo "	HznLOG: ${HznLOG}" |tee -a ${HznLOG}
echo "`dtx`-----------------------------------------------------"|tee -a ${HznLOG}
chmod 755 ${HznLOG}
############################################
#	Login to the database
############################################
#--------------------------------------------------------------
WriteLn "$(date)------------Starting ${BASESCRIPT} ------------------------------------------"
ValidateDBEnv ;
#--------------------------------------------------------------
sleep 2
WriteLn "$(dtx) After ValidateDBEnv " 
WriteLn "$(dtx) COMM_DBUSER:	$COMM_DBUSER"
WriteLn "$(dtx) COMM_DBASE:	$COMM_DBASE"
WriteLn "$(dtx) COMM_SERVER:	$COMM_SERVER"
export SQLSTART="sqlplus -s "${COMM_DBUSER}"/"${COMM_DBPASS}"@"${COMM_SERVER}

#--------------------------------------------------------------
	chkParm
#--------------------------------------------------------------

#=======================================================
export StageFile1=${HZN_DATA}/run_${FEED_TYPE}_${MKT}${YYYYMMDD}.currstage
export TempStageFile1=${HZN_DATA}/run_${FEED_TYPE}_${MKT}${YYYYMMDD}.tempstage
export StageFile2=${HZN_DATA}/run_${FEED_TYPE}_${MKT}_${YYYYMMDD}.readstage
export DONE_MKTS=""

echo "-----------------Stage Files----------------------------"|tee -a ${HznLOG}
echo "StageFile1: ${StageFile1}"|tee -a ${HznLOG}
echo "StageFile2: ${StageFile2}"|tee -a ${HznLOG}
echo "TempStageFile1: ${TempStageFile1}"|tee -a ${HznLOG}
echo "------------------------------------------------------------------"|tee -a ${HznLOG}
export ENDTIME=""
export JOB_INFO="Starting ${BASESCRIPT} ${ALLARGS}"
LSTAGE="STARTING"
if [[ ${CLEAR} == YES ]]
then
	WriteLn "------------------CLEAR is ${CLEAR}--------------------"
	WriteLn " -------Removing stage files------------------"
	rm -f ${StageFile1}
	rm -f ${StageFile2}
	rm -f ${TempStageFile1}
fi
if [ -s ${StageFile1} ]
then
	WriteLn "*****WARNING****WARNING***WARNING***"
	echo "WARNING, the stage file ${StageFile1} exists!" | tee -a ${HznLOG}
	echo "Thus, starting at section indicated by this file!" | tee -a ${HznLOG}
	CURRENT_STAGE=`head -1 ${StageFile1}`
	export JOB_INFO="ReRUNNING: ${ALLARGS}"
	LSTAGE="ReRUNNING"
	JobStage "${LSTAGE}"
	echo "**********Continue Existing RUN PLAN*********" | tee -a ${HznLOG}
	cat ${StageFile1} | tee -a ${HznLOG}
	echo "**************end Existing RUN PLAN***********" | tee -a ${HznLOG}
else
	export STARTTIME=`dtx`
	LSTAGE="STARTING"
	if [ ${DOSTAGE} ] || [ $STARTSTAGE ]
	then
		if [ ${DOSTAGE} ]
		then
			 echo "You have requested to perform stage: ${DOSTAGE} ..." | tee -a ${HznLOG}
			 case ${DOSTAGE} in
				EXTRACT)                           # EXTRACT STAGE
				   echo "EXTRACT"     > ${StageFile1} ;;
				DISTRIBUTE)                               # DISTRIBUTE STAGE
				   echo "DISTRIBUTE"       > ${StageFile1} ;;
				CONFIRM_SUCCESS)                               # CONFIRM_SUCCESS STAGE
				   echo "CONFIRM_SUCCESS"       > ${StageFile1} ;;
				CLEANUP)                               # CLEANUP STAGE
				   echo "CLEANUP"       > ${StageFile1} ;;
				*) echo "Invalid Start Stage! Valid stages are:${STAGES}."  | tee -a ${HznLOG}
					USAGE
					;;
			 esac
		else
			 echo "You have requested to begin at stage: ${STARTSTAGE} ..." | tee -a ${HznLOG}
			 case ${STARTSTAGE} in
				EXTRACT)                           # EXTRACT STAGE
					echo "EXTRACT"      > ${StageFile1}
					echo "DISTRIBUTE"     >> ${StageFile1}
					echo "CONFIRM_SUCCESS "  >> ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				DISTRIBUTE)                           # DISTRIBUTE STAGE
					echo "DISTRIBUTE"     > ${StageFile1}
					echo "CONFIRM_SUCCESS "  >> ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				CONFIRM_SUCCESS)                           # FILTER STAGE
					echo "CONFIRM_SUCCESS "  > ${StageFile1}
					echo "CLEANUP"  >> ${StageFile1}
					;;
				CLEANUP)                           # FILTER STAGE
					echo "CLEANUP"  > ${StageFile1}
					;;
				*) echo "Invalid Start Stage! Valid stages are:${STAGES}."  | tee -a ${HznLOG}
					USAGE
					;;
			esac
		fi
	else
		echo "EXTRACT"      > ${StageFile1}
		echo "DISTRIBUTE"     >> ${StageFile1}
		echo "CONFIRM_SUCCESS "  >> ${StageFile1}
		echo "CLEANUP"  >> ${StageFile1}
	fi
#	CURRENT_STAGE=`head -1 ${StageFile1}`
	JobStage "${LSTAGE}"
	echo "****************RUN PLAN*************" | tee -a ${HznLOG}
	cat ${StageFile1} | tee -a ${HznLOG}
	echo "**************end RUN PLAN***********" | tee -a ${HznLOG}
fi
#--------------------------------------------------
export ENDTIME=`dtx`
JobStage "COMPLETE"

#-------------------------------------------------
#	Now run the stages
#------------------------------------------------
Run_Script
#------------------------------------------------

CheckOracle
Clean_Exit 0

rm -f ${SQLCMD}
WriteLn "Your data output is in ${OUTFILE}"
WriteLn "Your log output is in ${HznLOG}"
WriteLn "End of  ${0} ..." 
