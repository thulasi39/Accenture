#!/bin/bash
if [ -f /opt/app/retailcommon/DataRouter/bin/env ]
then
. /opt/app/retailcommon/DataRouter/bin/env
fi
DATAPUBSUB_DIR=$DATAROUTER_HOME/src/pubsub
cp $DATAPUBSUB_DIR/product/ssasubscribe.jar $DATAPUBSUB_DIR/src/ssasubscribe/jars/*.jar $DATAROUTER_HOME/bin
cp $SUBKEYSTORE $DATAROUTER_HOME/bin/subscriber.jks
if [ "$SUBKEYSTOREPASS" != changeit ]
then
	keytool -storepasswd -new changeit -keystore $DATAROUTER_HOME/bin/subscriber.jks -storepass "$SUBKEYSTOREPASS" || exit 1
fi
if [ "$SUBKEYPASS" != changeit ]
then
	ALIAS=`keytool -list -keystore $DATAROUTER_HOME/bin/subscriber.jks -storepass changeit | grep ', PrivateKeyEntry, $' | sed 's/,.*//'`
	keytool -keypasswd -alias "$ALIAS" -keypass "$SUBKEYPASS" -new changeit -keystore $DATAROUTER_HOME/bin/subscriber.jks -storepass changeit || exit 1
fi
cat <<'!eof' >$DATAROUTER_HOME/bin/log4j.properties
log4j.debug=FALSE
log4j.rootLogger=INFO,Root

log4j.appender.Root=org.apache.log4j.DailyRollingFileAppender
log4j.appender.Root.file=/opt/app/retailcommon/DataRouter/logs/subscriber.log
log4j.appender.Root.datePattern='.'yyyyMMdd
log4j.appender.Root.append=true
log4j.appender.Root.layout=org.apache.log4j.PatternLayout
log4j.appender.Root.layout.ConversionPattern=%d %p %t %m%n
!eof
cd $DATAROUTER_HOME/bin
CLASSPATH=$(echo . *.jar | tr ' ' ':') java com.att.datarouter.pubsub.ssasubscribe.SSASubscriber
