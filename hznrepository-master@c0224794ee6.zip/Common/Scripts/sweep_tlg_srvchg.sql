set serveroutput on 

DECLARE

BEGIN
SP_SWEEP_TLG_SRVCHG_TRANS ( &&1, &&2, &&3 );
COMMIT;
END;
/
quit;
