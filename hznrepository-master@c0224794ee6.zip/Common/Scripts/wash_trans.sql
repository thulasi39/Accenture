set serveroutput on

DECLARE
ERRMSG VARCHAR2(1000);

BEGIN
SP_WASH_TRANS ( &&1, &&2,&&3, ERRMSG );
COMMIT;
END;
/
quit;
