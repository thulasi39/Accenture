#!/bin/ksh
# setupenv.sh
#################################################################################
#                                                                               #
#     NOTICE:                                                                   #
#       THIS MATERIAL CONTAINS TRADE SECRETS THAT BELONG TO                     #
#       BSCC INFORMATION SYSTEMS, INC., AND IS                                  #
#       LICENSED BY AN AGREEMENT.  ANY UNAUTHORIZED ACCESS, USE,                #
#       DUPLICATION, OR DISCLOSURE IS UNLAWFUL.                                 #
#                                                                               #
#                           COPYRIGHT (C) l997,                                 #
#                                   BY                                          #
#                       BSCC INFORMATION SYSTEMS, INC.                          #
#                         500 NORTHPARK TOWN CENTER                             #
#                       1100 ABERNATHY ROAD, SUITE 500                          #
#                         ATLANTA, GEORGIA 30328                                #
#                        TELEPHONE:(770) 555-5555                               #
#                        FAX:      (770) 444-4444                               #
#                          ALL RIGHTS RESERVED                                  #
#                                                                               #
#################################################################################
#                                                                               #
#  JOB ID:   setupenv.sh                                                        #
#  JOB NAME: Set up the apporpriate Environment                                 #
#                                                                               #
#  Abstract:                                                                    #
#                                                                               #
#  RETURN VALUES                                                                #
#                                                                               #
#  0     Success                                                                #
#  99    Error                                                                  #
#                                                                               #
#  Modification History                                                         #
#                                                                               #
#  01/09/2002  Greg Visser    	  Initial Version                               # 
#                                                                               #
#################################################################################
# RCS Information:
#	$Revision: 1.16 $
#	$Date: 2003/08/21 21:24:41 $
#	$Author: doming $
#	
#	$Log: setupenv.sh,v $
#	Revision 1.16  2003/08/21 21:24:41  doming
#	Added new pac split markets.
#
#################################################################################

SETUPUSAGE="\nsetupenv.sh -e<environment>"

export USER=$ME #it used to be horizon in the past, horizon is no longer a vaild user.
 
export DATADIR=$HORIZON_DATA
export BACKDIR=$DATADIR/backup
export LOGDIR=$HORIZON_LOG

while getopts m:e:E: OPT ; do
  case $OPT in
    e|E) export RUNENV=`echo $OPTARG | tr '[A-Z]' '[a-z]'`;;
      *) echo -e $SETUPUSAGE
         exit 99;;
  esac
done

export INFDIR=$HORIZON_BIN

export BOXNAME=`uname -n` 
case $RUNENV in
	dev ) echo -e "\nSetting $RUNENV environment"
	export CURENV=DEV ;;
#	export SERVERPREFIX=Q1;;
   
	sys) echo -e "\nSetting System Test environment"
	export CURENV=SYS ;;
#	export SERVERPREFIX=U0;;

	qc) echo -e "\nSetting QC environment"
	export CURENV="QC" ;;
#	export SERVERPREFIX=C0;;
   
	tst) echo -e "\nSetting TST environment"
	export CURENV="TST"	;;
#	export SERVERPREFIX=C0;;

	uat) echo -e "\nSetting UAT environment"
	export CURENV=UAT ;;
#      export SERVERPREFIX=Q0;;


	prod) echo -e "\nSetting PROD environment"
	if [[ "$IS_PRODUCTION_HOST" = "N" ]]; then
		echo -e "Cannot run $RUNENV from a non-production box!\n\n"
		exit;
	fi
	export CURENV="" ;;
#	export SERVERPREFIX=P0;;
   mycomp) echo -e "\nSetting MYCOMP environment"
	if [[ "$IS_PRODUCTION_HOST" = "N" ]]; then
		echo -e "Cannot run $RUNENV from a non-production box!\n\n"
		exit;
	fi
	export CURENV="" ;;
#	export SERVERPREFIX=P0;;
	

   *) echo -e "\nERROR Setting environment"
	echo
	echo -e "Must choose from these environments:"
	echo -e "dev |sys |qc |uat | tst | prod " ;

	exit 99;;
esac

DECRYPT=$HORIZON_BIN/Decrypt

if [ ! -f $DECRYPT ]
then
    echo -e "*Error* $DECRYPT does not exist"
    exit
fi

if [ ! -x $DECRYPT ]
then
    echo -e "*Error* user do not execute permission on $DECRYPT"
    exit
fi

export COMM_ACCESSLIB=liboci16312d.so
export COMM_DBASE=$($DECRYPT -e$RUNENV -d)
export COMM_SERVER=$COMM_DBASE
export COMM_DBUSER=$($DECRYPT  -e$RUNENV -u)
export COMM_DBPASS=$($DECRYPT  -e$RUNENV -p)

if [ -z $COMM_DBUSER ]
then
    echo -e "*Error* COMM_DBUSER not defined! !!"
	exit
fi
if [ -z $COMM_SERVER ]
then
    echo -e "*Error* COMM_SERVER not defined! !!"
	exit
fi
if [ -z $COMM_DBASE ]
then
    echo -e "*Error* COMM_DBASE not defined! !!"
	exit
fi
if [ -z $COMM_DBPASS ]
then
    echo -e "*Error* COMM_DBPASS not defined! !!"
	exit
fi

echo -e "Connecting to DATABASE $COMM_DBASE AT $COMM_SERVER"
