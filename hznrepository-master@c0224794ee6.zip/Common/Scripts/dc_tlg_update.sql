set serveroutput on 
-- &&1 is month
-- &&2 is day
-- &&3 is year

DECLARE
ERRMSG VARCHAR2(1000);

BEGIN
SP_DC_TLG_UPDATE ( &&1, &&2, &&3, ERRMSG );
COMMIT;
END;
/
quit;

