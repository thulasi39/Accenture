set serveroutput on

DECLARE
ERRORMSG VARCHAR2(1000);
--*     1-        p_month IN integer,
--*     2-        p_day IN integer,
--*     3-        p_year IN integer,
--*     4-        p_errormessage out varchar2

BEGIN
SP_TLG_DAILY_DEVICE_ID_UPD ( &&1, &&2, &&3, ERRORMSG );
COMMIT;
END;
/
quit;
