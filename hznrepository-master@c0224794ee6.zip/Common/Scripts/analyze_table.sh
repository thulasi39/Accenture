#!/bin/ksh

USAGE="Usage: $(basename $0) -t<TABLE> -e<env>"
while getopts m:y:t:e: OPT ; do
    case $OPT in
    m) export MONTH=$OPTARG;;
    y) export YEAR=$OPTARG;;
    t) export TABLE=$OPTARG;;
    e) typeset -lx RUNENV=$OPTARG;;
    *) echo $USAGE; exit 99;;
    esac
done

if [[ -z $TABLE ]] ; then
    echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide a table!"
    echo $USAGE
    exit 99
fi
if [[ -z $RUNENV ]] ; then
    echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide an environment!"
    echo $USAGE
    exit 99
fi

typeset -ix TMPMONTH=$MONTH
typeset -ix TMPYEAR=$YEAR
if [[ $TMPMONTH -ne 0 && $TMPYEAR -ne 0 ]] ; then
    export PARTITION="P${TMPYEAR}_${TMPMONTH}"
fi

echo -e "`date '+%m/%d/%Y %H:%M:%S'` Will setup the $RUNENV environment..."
. $HORIZON_BIN/setupenv.sh -e$RUNENV
echo -e "`date '+%m/%d/%Y %H:%M:%S'` ***** $(date) Starting $(basename $0) $*"

YMD=$(date '+%Y%m%d')
LOG=$HORIZON_LOG/analyze_${TABLE}_${YMD}.log

SQLPLUS="sqlplus -S "$COMM_DBUSER"/"$COMM_DBPASS"@"$COMM_SERVER

# Strip the hznrep if using developers id - gv8534[hznrep]
checkStr=\[
[[ $COMM_DBUSER == *"$checkStr"* ]] && export COMM_DBUSER=`echo $COMM_DBUSER | grep -Po '(?<=(\[)).*(?=\])'`

if [[ -z "$PARTITION" ]] ; then
    SQL="spool ${LOG}
    set timing on
    exec DBMS_STATS.GATHER_TABLE_STATS(ownname=>'${COMM_DBUSER}',tabname=>'${TABLE}',estimate_percent=>10,degree=>SYS.DBMS_STATS.DEFAULT_DEGREE,cascade=>TRUE,no_invalidate=>FALSE)
    exit;"
else
    SQL="spool ${LOG}
    set timing on
    exec DBMS_STATS.GATHER_TABLE_STATS(ownname=>'${COMM_DBUSER}',tabname=>'${TABLE}',partname=>'${PARTITION}',estimate_percent=>10,degree=>SYS.DBMS_STATS.DEFAULT_DEGREE,cascade=>TRUE,no_invalidate=>FALSE)
    exit;"
fi

echo -e "`date '+%m/%d/%Y %H:%M:%S'` $SQL"
echo -e "$SQL" | $SQLPLUS

echo -e "`date '+%m/%d/%Y %H:%M:%S'` ***** $(date) Finished $(basename $0) $*"
