set termout off ;
set echo off ;
set heading off ;
set pagesize 0  ;
set trimspool on ;
set feedback 1 ;
set colsep '|';
set linesize 760 ;

select distinct substr(a.attrib_value,1,9), 'C'
from CPC_PRODUCT_CATLG a
where a.prod_type = 'generic feature'
  and a.attrib_name = 'productCode'
  and not exists (
      select *
      from CPC_PRODUCT_CATLG b
      where b.prod_id = a.prod_id
        and b.attrib_name = 'dataGroupInd'
        and to_date('--EFFDATE','yyyymmdd') between b.EFF_DATE and b.EXP_DATE
      )
  and exists (
      select *
      from CPC_PRODUCT_CATLG c
      where c.prod_id = a.prod_id
        and c.attrib_name = 'connectedCarInd'
        and c.attrib_value = 'Y'
        and to_date('--EFFDATE','yyyymmdd') between c.EFF_DATE and c.EXP_DATE
      )
  and exists (
      select *
      from CPC_PRODUCT_CATLG d
      where d.prod_id = a.prod_id
        and d.attrib_name = 'commissionable'
        and d.attrib_value = 1
        and to_date('--EFFDATE','yyyymmdd') between d.EFF_DATE and d.EXP_DATE
      )
UNION ALL
select distinct substr(a.attrib_value,1,9), 'U'
from CPC_PRODUCT_CATLG a
where a.prod_type = 'generic feature'
  and a.attrib_name = 'productCode'
  and exists (
      select *
      from CPC_PRODUCT_CATLG b
      where b.prod_id = a.prod_id
        and b.attrib_name = 'equipmentUpgradeSOC'
        and b.attrib_value = 1
        and to_date('--EFFDATE','yyyymmdd') between b.EFF_DATE and b.EXP_DATE
      ) 
UNION ALL
select distinct substr(a.attrib_value,1,9), 'E'
from CPC_PRODUCT_CATLG a
where a.prod_type in ('generic feature','generic rate plan')
  and a.attrib_name = 'productCode'
  and exists (
      select *
      from CPC_PRODUCT_CATLG b
      where b.prod_id = a.prod_id
        and b.attrib_name = 'commissionable'
        and b.attrib_value = 1
        and to_date('--EFFDATE','yyyymmdd') between b.EFF_DATE and b.EXP_DATE
      );

spool off ;
exit ;
