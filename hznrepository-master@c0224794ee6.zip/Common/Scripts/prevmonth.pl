#!/usr/local/bin/perl -w
################################################################################
# prevmonth.pl
#
# Usage:
#       prevmonth.pl [ -o <offset> ] [ <MM> <YYYY> ]
#
# Output:
#       MM YYYY
#
# Description:
#       This script returns the MM YYYY of the previous month.
#       With the optional -o <offset> option, you can determine the MM YYYY
#       of the month <offset> months from today, with negative offsets returning
#       dates in the past, positive offsets returning future dates, and an
#       offset of 0 returning the current month.  The default offset is -1.
#       Optionally, you can also provide a <MM> <YYYY>, and the script will
#       calculate the offset from that date instead of today.
#
#       The perl function localtime() returns the following array:
#       ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)
#       - where $mday is the day of the month; $mon is the month itself,
#       in the range "0..11" with 0 indicating January and 11 indicating
#       December; and $year is the number of years since 1900.
#
# Examples:
#       => date            
#       Thu May 11 10:53:57 CDT 2006
#       => prevmonth.pl
#       04 2006
#       => prevmonth.pl -o -2
#       03 2006
#       => prevmonth.pl -o 3 
#       08 2006
#       => prevmonth.pl -o -1 04 2006
#       03 2006
#
# History:
#       05/11/2006 - Terri Matthews - Created.
################################################################################


use Getopt::Std;
use POSIX;

$usage = "Usage: $0 [ -o <offset> ] [ <MM> <YYYY> ]";
$offset = -1;

getopts('o:') || die "ERROR: Unknown options.\n$usage\n";
if (defined($opt_o)) {
        $offset = int($opt_o);
}

if (defined $ARGV[0]) {
        $mon = $ARGV[0];
        $mon -= 1;
        if (defined $ARGV[1]) {
                $year = $ARGV[1];
                $year -= 1900;
        } else {
                die "$usage\n";
        }
} else {
        ($mon,$year) = (localtime(time))[4,5];
}

printf("%02d %04d\n",
        (($mon + $offset) % 12) + 1,
        $year + (floor(($mon + $offset) / 12)) + 1900);
