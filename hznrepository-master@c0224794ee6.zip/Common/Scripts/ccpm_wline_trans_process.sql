set serveroutput on 

DECLARE
ERRMSG VARCHAR2(1000);
OUTREC VARCHAR2(1000);

BEGIN
SP_CCPM_WLINE_TRANS_MAIN ( p_year=>&&1, p_month=>&&2, p_result=>OUTREC, p_errormessage=>ERRMSG );
DBMS_OUTPUT.put_line(OUTREC);
DBMS_OUTPUT.put_line(ERRMSG);
COMMIT;
END;
/
quit;
