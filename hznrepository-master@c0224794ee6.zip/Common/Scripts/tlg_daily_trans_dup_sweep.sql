
-- #############################################################################
-- #
-- # This script will execute a stored procedure used to identify and mark
-- # duplicate transactions in the Horizon Repository table, TLG_DAILY_TRANS
-- #
-- # Parameters:
-- #     1 - Run Year
-- #     2 - Run Month
-- #
-- # Example:  @tlg_daily_trans_dup_sweep[.sql]  <Run_Year>  <Run_Month>
-- #
-- # Modifications
-- # ---------------------------------------------------------------------------
-- # 2017-02-27  JRL  Created script
-- #
-- #############################################################################

WHENEVER SQLERROR EXIT SQL.SQLCODE

SET ServerOutput ON

PROMPT TLG Daily Trans DUP Sweep: &&1..&&2

exec SP_TLG_DAILY_TRANS_DUP_SWEEP( &&1, &&2 ) ;

-- #****************************************************************************

EXIT
/
