#!/bin/ksh
#set_load_status.sh
#----------------------
USAGE="\n$(basename $0) [{-m<month> -d<day> -y<year>}] -e<env> -f<feedtype> -M<MKT>
       \n  -m<month>
       \n  -d<day>
       \n  -y<year>
       \n  -e<env> (Run in the specified environment - retail 
       \n  -e<feedtype> (bid_srvchg, oracle, global_tlg_daily, bid_wl) "

typeset -Z2 PROCESSDAY
typeset -Z2 PROCESSMONTH
typeset -Z4 PROCESSYEAR

while getopts d:e:y:m:f:M: OPT ; do
        case $OPT in
        M) export MKT=$OPTARG;;
        m) export PROCESSMONTH=$OPTARG;;
        d) export PROCESSDAY=$OPTARG;;
        y) export PROCESSYEAR=$OPTARG;;
        e) typeset -lx RUNENV=$OPTARG;;
        f) export FEEDTYPE=$OPTARG;;
        *) echo -e $USAGE; exit 99;;
        esac
done

if [[ -z $RUNENV ]] ; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide an environment!"
        echo -e $USAGE
        exit 99
fi
if [[ -z $PROCESSMONTH ]] ; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide a month!"
        echo -e $USAGE
        exit 99
fi
if [[ -z $PROCESSDAY ]] ; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` Day Column will be set to null for Monthly Feed!"
fi
if [[ -z $PROCESSYEAR ]] ; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide a year!"
        echo -e $USAGE
        exit 99
fi
echo -e "`date '+%m/%d/%Y %H:%M:%S'` Will setup the $RUNENV environment..."
. $HORIZON_BIN/setupenv.sh -e$RUNENV

export BaseScriptname=`basename $0`
export SQLSTART="sqlplus -S ${COMM_DBUSER}/${COMM_DBPASS}@${COMM_SERVER}"
export PROCESSID=$$

typeset SQLCMD
SQLCMD=$HORIZON_DATA/sqlcommand$(hostname)_$$.sql

if [[ -z $PROCESSDAY ]] ; then
echo -e "delete from load_status where feed_type='$FEEDTYPE' and month=$PROCESSMONTH and day is null and year=$PROCESSYEAR;" > $SQLCMD
echo -e "quit;" >> $SQLCMD
else
echo -e "delete from load_status where feed_type='$FEEDTYPE' and month=$PROCESSMONTH and day=$PROCESSDAY and year=$PROCESSYEAR;" > $SQLCMD
echo -e "quit;" >> $SQLCMD
fi
cat $SQLCMD 
$SQLSTART @$SQLCMD

rm -rf $SQLCMD

case $FEEDTYPE in
	bid_srvchg) export TABLENAME=bid_prod_family_svc_chgs;;
	bid_cf) export TABLENAME=bid_customer_feedback;;
	bid_wl) export TABLENAME=bid_wline_datapipe_trans;;
	calc_ban) export TABLENAME=ban_daily_trans;;
	cpc) export TABLENAME=cpc_product_catlg;;
	opus) export TABLENAME=opus_sales_trans;;
	oracle) export TABLENAME=ora_sales_orders;;
	tlg_daily) export TABLENAME=tlg_daily_trans;;
	tlg_true) export TABLENAME=tlg_true_up_trans;;
	tlg_dealer_chg) export TABLENAME=tlg_dealer_code_changes;;
	ban_daily_sum) export TABLENAME=ban_daily_sum;;
	ban_daily_trans) export TABLENAME=ban_daily_trans;;
	tlg_monthly_dealer) export TABLENAME=tlg_monthly_dealer;;
	bid_cancels) export TABLENAME=bid_cancellations;;
	edm_referral_chg) export TABLENAME=edm_referral_code_trans ;;
	ericsson) export TABLENAME=ericsson_balance_trans ;;
	ericsson_tlg_update) export TABLENAME=tlg_daily_trans ;;
	ericsson_ml) export TABLENAME=ericsson_ml_snapshot ;;
	inst_tlg_update) export TABLENAME=tlg_daily_trans ;;

	ccpm_wl) export TABLENAME=ccpm_wline_trans ;;
	biz_ipbb_flipping) export TABLENAME=biz_ipbb_flipping ;;
	crft_care) export TABLENAME=crft_care_surveys ;;
	crft_retail) export TABLENAME=crft_retail_surveys ;;
	tacrft_cust_survey) export TABLENAME=tacrft_cust_survey ;;
	dc_tlg_update) export TABLENAME=tlg_daily_trans ;;
	rc_tlg_update) export TABLENAME=tlg_daily_trans ;;
	cross_upgrade) export TABLENAME=tlg_daily_trans ;;
	product_upgrade) export TABLENAME=tlg_daily_trans ;;
	pos_tlg_update) export TABLENAME=tlg_daily_trans ;;
	sweep_tlg_update) export TABLENAME=tlg_daily_trans ;;
	ccpm_inst_tlg_update) export TABLENAME=tlg_daily_trans ;;
	ccpm_inst) export TABLENAME=ccpm_enb_inst ;;
	ccpm_inst_hist) export TABLENAME=ccpm_enb_inst_hist ;;
	tlg_mult_imei) export TABLENAME=tlg_mult_imei ;;
	tlg_ccnmcn_chg) export TABLENAME=tlg_ccnmcn_chg ;;
	tlg_srvarea_mob) export TABLENAME=tlg_srvarea_mob ;;
	tlg_srvarea) export TABLENAME=tlg_srvarea ;;
	tlg_imei_catchup) export TABLENAME=tlg_imei_catchup ;;
	tlg_tablet) export TABLENAME=tlg_tablet ;;
	tlg_smf_allmobs_agt) export TABLENAME=tlg_smf_allmobs ;;
	tlg_smf_allmobs_nat) export TABLENAME=tlg_smf_allmobs ;;
	tlg_smf_billhistory_agt) export TABLENAME=tlg_smf_billhistory ;;
	tlg_smf_billhistory_nat) export TABLENAME=tlg_smf_billhistory ;;
	tlg_smf_customer_agt) export TABLENAME=tlg_smf_customer ;;
	tlg_smf_customer_nat) export TABLENAME=tlg_smf_customer ;;
	dc_bid_update) export TABLENAME=bid_prod_family_svc_chgs ;;
	nci) export TABLENAME=nci_activity_base ;;
	csi_crossupg) export TABLENAME=csi_cross_upg_data ;;
	tlg_ip_definition) export TABLENAME=ip_definition ;;
	srs_call_summ) export TABLENAME=srs_call_summary ;;
	tlg_inst_info) export TABLENAME=tlg_inst_info_catchup ;;
	hznrep_ccpm_wireless) export TABLENAME=hznrep_ccpm_wireless_trans ;;
	ccpm_contract_trans) export TABLENAME=ccpm_contract_trans ;;
	ccpm_contract_ref_trans) export TABLENAME=ccpm_contract_ref_trans ;;
	ccpm_wline_trans_process) export TABLENAME=ccpm_wline_trans ;;
	*) export TABLENAME=$FEEDTYPE;;
esac
	

if [[ -z $MKT ]]; then
	MKTCOLSTR=""
	MKTSTR=""
else
	MKTCOLSTR=", BILL_MKT_CODE"
	MKTSTR=", '$MKT'"
fi

if [[ -z $PROCESSDAY ]] ; then
# Set status for feedtype complete in LOAD_STATUS
echo -e "insert into load_status (LOAD_STATUS_KEY, YEAR, MONTH, DAY, PROCESS_ID, SCRIPT, FEED_TYPE $MKTCOLSTR, TABLE_NAME, DATA_FILE, LOAD_COMPLETED, MOD_USER, MOD_DATE) VALUES (seq_load_status.nextval, $PROCESSYEAR, $PROCESSMONTH,NULL,$PROCESSID,'$BaseScriptname','$FEEDTYPE' $MKTSTR,'$TABLENAME',' ', sysdate,'set_load_status.sh',sysdate);" > $SQLCMD
echo -e "exit" >> $SQLCMD
else
# Set status for feedtype complete in LOAD_STATUS
echo -e "insert into load_status (LOAD_STATUS_KEY, YEAR, MONTH, DAY, PROCESS_ID, SCRIPT, FEED_TYPE $MKTCOLSTR, TABLE_NAME, DATA_FILE, LOAD_COMPLETED, MOD_USER, MOD_DATE) VALUES (seq_load_status.nextval, $PROCESSYEAR, $PROCESSMONTH,$PROCESSDAY,$PROCESSID,'$BaseScriptname','$FEEDTYPE' $MKTSTR,'$TABLENAME',' ', sysdate,'set_load_status.sh',sysdate);" > $SQLCMD
echo -e "exit" >> $SQLCMD

fi

cat $SQLCMD 
$SQLSTART @$SQLCMD

rm -rf $SQLCMD
exit 0
