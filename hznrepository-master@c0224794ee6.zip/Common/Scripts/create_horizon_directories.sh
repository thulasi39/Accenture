#!/bin/ksh
# NAME:     create_horizon_directories.sh
# PURPOSE:  Script to make sure all the data and log subdirectories
#           exist for all feed_type values with the correct permissions.

# Check to make sure HORIZON variables are set, exit if not.
: ${HORIZON_DATA:?}
: ${HORIZON_LOG:?}

set -A FEED_TYPE_LIST \
        bid_cancels \
        bid_cf \
        bid_srvchg \
        bid_wl \
        calc_ban \
        ccpm_inst \
        ccpm_inst_hist \
        ccpm_inst_tlg_catchup \
        ccpm_inst_tlg_update \
        ccpm_wl \
        biz_ipbb_flipping \
        cpc \
        cpc_to_tlg \
        crft_care \
        crft_retail \
        tacrft_cust_survey \
        ccpm_contract_trans \
        ccpm_contract_ref_trans \
        cross_upgrade \
        csi_crossupg \
        dc_bid_update \
        dc_next \
        dc_tlg_update \
        edm_referral_chg \
        ericsson \
        ericsson_ml \
        ericsson_tlg_update \
        inst_tlg_update \
        nci \
        hznrep_daily_upd\
        hznrep_ccpm_wireless\
        oracle \
        pos_tlg_update \
        product_upgrade \
        rc_tlg_update \
        srs_call_summ \
        sweep_tlg_srvchg \
        tlg_daily \
        tlg_daily_device_id_upd \
        ccpm_wline_trans_process \
        tlg_dealer_chg \
        tlg_ffsc \
        tlg_inst_info \
        tlg_ip_definition \
        tlg_mult_imei \
        tlg_srvchg \
        tlg_ccnmcn_chg \
        tlg_srvarea \
        tlg_srvarea_mob \
        tlg_imei_catchup \
        tlg_tablet \
        tlg_smf_allmobs_agt \
        tlg_smf_allmobs_nat \
        tlg_smf_billhistory_agt \
        tlg_smf_billhistory_nat \
        tlg_smf_customer_agt \
        tlg_smf_customer_nat \
        tlg_true

for hzn_root_dir in $HORIZON_DATA $HORIZON_LOG; do
        [[ -d $hzn_root_dir ]] || mkdir $hzn_root_dir
        [[ -d $hzn_root_dir/backup ]] || mkdir $hzn_root_dir/backup
        chmod 755 $hzn_root_dir $hzn_root_dir/backup
        ls -ld $hzn_root_dir $hzn_root_dir/backup

        for feed_type in ${FEED_TYPE_LIST[*]}; do
                [[ -d $hzn_root_dir/$feed_type ]] || mkdir $hzn_root_dir/$feed_type
                [[ -d $hzn_root_dir/$feed_type/backup ]] || mkdir $hzn_root_dir/$feed_type/backup
                chmod 755 $hzn_root_dir/$feed_type $hzn_root_dir/$feed_type/backup
                ls -ld $hzn_root_dir/$feed_type $hzn_root_dir/$feed_type/backup
        done
done

exit
