set serveroutput on

DECLARE
ERRMSG VARCHAR2(1000);

BEGIN
SP_CROSSUPG ( &&1, &&2, &&3, ERRMSG );
COMMIT;
END;
/
quit;
