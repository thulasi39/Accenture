           
set serveroutput on
-- &&1 is year
-- &&2 is month

begin
  execute immediate 'drop table spi_custname_ora_sales_orders';
  exception when others then null;
end;
/

CREATE TABLE spi_custname_ora_sales_orders AS
  SELECT a.ora_sales_orders_key
    FROM ora_sales_orders a
    WHERE a.year = &&1
       AND a.month = &&2
       AND (   REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{3}-[0-9]{2}-[0-9]{4}([^0-9].*$|$)')
            OR REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{3} [0-9]{2} [0-9]{4}([^0-9].*$|$)')
            OR REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{3}[0-9]{2}[0-9]{4}([^0-9].*$|$)')
            OR REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{2}-[0-9]{7}([^0-9].*$|$)'));

DECLARE
  v_ora_sales_UpdInfo spi_custname_ora_sales_orders%ROWTYPE;
  v_ora_sales_cnt INTEGER;

CURSOR cur_spi_cust_ora_sales IS
  SELECT * FROM spi_custname_ora_sales_orders;

BEGIN
  v_ora_sales_cnt := 0;
  -- Loop through temporary spi_custname_ora_sales_orders table
  OPEN cur_spi_cust_ora_sales;
  LOOP
    FETCH cur_spi_cust_ora_sales INTO v_ora_sales_UpdInfo;
    EXIT WHEN cur_spi_cust_ora_sales%NOTFOUND;

    BEGIN
      BEGIN
        UPDATE ora_sales_orders
           SET CUSTOMER_NAME = REGEXP_REPLACE (CUSTOMER_NAME, '[0-9]', 'X'),
              mod_date = sysdate
        WHERE ora_sales_orders_key = v_ora_sales_UpdInfo.ora_sales_orders_key;
        v_ora_sales_cnt := v_ora_sales_cnt + 1;
        IF mod(v_ora_sales_cnt,10000) = 0 THEN
             --DBMS_OUTPUT.put_line ('spi_custname_ora_sales_orders  Committed on ' || v_ora_sales_cnt || ' records.');
           COMMIT;
        END IF;


      EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
      END;
    END;

  END LOOP;
  DBMS_OUTPUT.put_line ('Updated ' || v_ora_sales_cnt || ' ora_sales_orders records.');
  CLOSE cur_spi_cust_ora_sales;
  COMMIT;

END;
/
quit;

