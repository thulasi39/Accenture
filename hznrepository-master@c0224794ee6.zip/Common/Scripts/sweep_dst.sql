/****************************************************************************************

JOB ID:   sweep_dst.sql
JOB Description: advance the survey_complition_date by 1 hr if between 2-3 DST

input parameters
      1 month(1-12)
      2 year(4 digit, 2000-2050)

Modification History

03/31/2017  Greg Visser        Initial Version


/***************************************************************************************/

set head off
set pages 0
SET SERVEROUTPUT ON

declare p_month number(2);
p_year number(4);
p_moduser varchar2(20);  
p_sql varchar2(1000);
s_sql varchar2(1000);
p_tablename varchar2(80);
p_mktCode varchar2(80);
p_count number;
BEGIN
    p_month:=&1;
    p_year := &2;
    p_tablename := '&3';
    p_mktCode := '&4';
    p_moduser := 'sweep_dst';

    if(p_month not between 1 and 12 )
    then
               dbms_output.put_line('****ERROR****!!!Invalid value for month[' || p_month || ']' );
               dbms_output.put_line('The month can only be 1-12');
               return ;
    end if ;

    if(p_year not between 2000 and 2099 )
    then
               dbms_output.put_line('****ERROR****!!!Invalid value for year[' || p_year || ']' );
               dbms_output.put_line('The year can only be 2000-2099');
               return ;
    end if ;

    BEGIN

    p_sql := ' ';
    s_sql := ' ';
    dbms_output.put_line('Month :' ||p_month);
    dbms_output.put_line('Year :' ||p_year);

    if ( p_tablename = 'tlg_daily_trans' )
    then
    	p_sql := 'update tlg_daily_trans set timestamp=timestamp+1/24, mod_user=''sweep_dst'', mod_date=sysdate where month=' || p_month || ' and year=' || p_year || ' and bill_mkt_code='''||p_mktCode||''' and timestamp between NEXT_DAY(TO_DATE(to_char(timestamp,''YYYY'') || ''/03/01 02:00 AM'', ''YYYY/MM/DD HH:MI AM'') - 1, ''SUN'') + 7 and NEXT_DAY(TO_DATE(to_char(timestamp,''YYYY'') || ''/03/01 02:00 AM'', ''YYYY/MM/DD HH:MI AM'') - 1, ''SUN'') + 7 +1/24';
    end if;

    if ( p_tablename = 'crft_retail_surveys' )
    then
    	p_sql := 'update crft_retail_surveys set survey_completion_date=survey_completion_date+1/24, mod_user=''sweep_dst'', mod_date=sysdate where month=' || p_month || ' and year=' || p_year || ' and survey_completion_date between NEXT_DAY(TO_DATE(to_char(survey_completion_date,''YYYY'') || ''/03/01 02:00 AM'', ''YYYY/MM/DD HH:MI AM'') - 1, ''SUN'') + 7 and NEXT_DAY(TO_DATE(to_char(survey_completion_date,''YYYY'') || ''/03/01 02:00 AM'', ''YYYY/MM/DD HH:MI AM'') - 1, ''SUN'') + 7 +1/24';
    end if;

    if ( p_tablename = 'tacrft_cust_survey' )
    then
        p_sql := 'update tacrft_cust_survey set survey_completed_datetime=survey_completed_datetime+1/24, mod_user=''sweep_dst'', mod_date=sysdate where month=' || p_month || ' and year=' || p_year || ' and survey_completed_datetime between NEXT_DAY(TO_DATE(to_char(survey_completed_datetime,''YYYY'') || ''/03/01 02:00 AM'', ''YYYY/MM/DD HH:MI AM'') - 1, ''SUN'') + 7 and NEXT_DAY(TO_DATE(to_char(survey_completed_datetime,''YYYY'') || ''/03/01 02:00 AM'', ''YYYY/MM/DD HH:MI AM'') - 1, ''SUN'') + 7 +1/24';
    end if;


    if ( p_sql = ' ' )
    then
    	dbms_output.put_line('Tablename is not valid!');
    else
        BEGIN
    	dbms_output.put_line(p_sql);
    	execute immediate 'begin ' || p_sql || '; :x := sql%rowcount; end;' using OUT p_count;
    	commit;
    	exception
    	when others then
    	rollback;
    	dbms_output.put_line('SqlCode=' || SQLCODE || ' SqlErr=' || SQLERRM);
	END;
    end if;

    END;

    dbms_output.put_line('');
    dbms_output.put_line('');
    dbms_output.put_line('Completed the update of DST fields: '||to_char(p_count)||' records updated in table.');
               
  
END;
/

EXIT
