#!/bin/bash
if [ -f /opt/app/retailcommon/DataRouter/bin/env ]
then
. /opt/app/retailcommon/DataRouter/bin/env
fi
rm -rf tmp
mkdir tmp
cd src/ssasubscribe
CLASSPATH=$(echo jars/*.jar | tr ' ' ':') javac -d ../../tmp *.java || exit 1
cd ../../tmp
jar cf ../product/ssasubscribe.jar `find . -name '*.class'` || exit 1
cd ..
rm -rf tmp

