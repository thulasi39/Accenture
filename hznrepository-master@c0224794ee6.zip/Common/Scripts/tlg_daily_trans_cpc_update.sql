
-- #############################################################################
-- #
-- # This script will execute a stored procedure used to update the CPC  
-- # fields in the Horizon Repository table, TLG_DAILY_TRANS
-- #
-- # Parameters:
-- #     1 - Run Month
-- #     1 - Run Day
-- #     2 - Run Year
-- #
-- # Example:  @tlg_daily_trans_cpc_update[.sql] <Run_Month> <Run_Day> <Run_Year>
-- #
-- # Modifications
-- # ---------------------------------------------------------------------------
-- # 2017-10-03  JRL  Created script
-- #
-- #############################################################################

WHENEVER SQLERROR EXIT SQL.SQLCODE

SET ServerOutput ON

PROMPT TLG Daily Trans CPC Update Sweep: &&1..&&2..&&3

exec SP_TLG_DAILY_TRANS_CPC_UPDATE( &&1, &&2, &&3 ) ;

-- #****************************************************************************

EXIT
/
