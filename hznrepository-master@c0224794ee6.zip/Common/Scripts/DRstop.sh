#!/bin/ksh
PID=$(ps -fu hznprd | grep -v grep | grep "java com.att.datarouter.pubsub.ssasubscribe.SSASubscriber" | awk '{print $2}')
echo -e "Killing Data Router java process:"
ps -fp $PID
kill $PID
