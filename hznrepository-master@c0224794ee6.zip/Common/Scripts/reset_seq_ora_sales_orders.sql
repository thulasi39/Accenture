set termout off ;
set echo on ;
set heading off ;
set pagesize 0  ;
set trimspool on ;
set feedback 1 ;
set colsep '|';
set linesize 760 ;
set verify on ;

SELECT *
  FROM user_sequences
 WHERE sequence_name = 'SEQ_ORA_SALES_ORDERS';

DROP SEQUENCE SEQ_ORA_SALES_ORDERS;

CREATE SEQUENCE SEQ_ORA_SALES_ORDERS
   START WITH &&1
   MINVALUE &&1
   MAXVALUE 2147483647
   NOCYCLE
   CACHE 200
   NOORDER;

SELECT *
  FROM user_sequences
 WHERE sequence_name = 'SEQ_ORA_SALES_ORDERS';

exit;
