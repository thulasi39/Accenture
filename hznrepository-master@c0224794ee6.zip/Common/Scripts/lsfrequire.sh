#!/bin/bash
PARENT_JOB=$1
shift 1
if [ -z $LSB_JOBID ] ; then
    echo -e "`date '+%m/%d/%Y %H:%M:%S'` you can not run ${PARENT_JOB}. Please use lsfsubmit command to submit this job."
    echo -e "`date '+%m/%d/%Y %H:%M:%S'` For Example:"
    echo -e "`date '+%m/%d/%Y %H:%M:%S'` lsfsubmit ${PARENT_JOB} $*"
   exit
fi
