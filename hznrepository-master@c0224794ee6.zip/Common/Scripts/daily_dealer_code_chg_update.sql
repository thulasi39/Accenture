set serveroutput on 
-- &&1 is month
-- &&2 is day
-- &&3 is year

begin
  execute immediate 'drop table dc_tlg_daily';
  exception when others then null;
end;
/

CREATE TABLE dc_tlg_daily AS
  SELECT a.tlg_daily_trans_key, b.tlg_dealer_code_changes_key, a.seller_id, a.isd_mobile,
   b.rate_plan, b.old_seller_id, b.new_seller_id
    FROM tlg_daily_trans a, tlg_dealer_code_changes b
    WHERE a.bill_mkt_code = b.bill_mkt_code
      AND a.isd_mobile = b.isd_mobile
      AND a.ban = to_number(b.account_number)
      AND a.product_code = b.product_code
      AND a.seller_id = b.old_seller_id
      AND b.old_seller_id != b.new_seller_id
      AND a.action_date = b.action_date
      AND a.month = &&1 AND a.year = &&3
      AND a.month = b.month AND a.year = b.year AND b.day = &&2;

-- delete this day's data from the backup table in case of a rerun
DELETE FROM dc_tlg_daily_hist
  WHERE month = &&1 AND day = &&2 AND year = &&3;

-- create bid reps list table
begin
  execute immediate 'drop table dc_bid_srvchg';
  exception when others then null;
end;
/

CREATE TABLE dc_bid_srvchg AS
  SELECT a.bid_prod_family_key, b.tlg_dealer_code_changes_key, a.seller_id, a.isd_mobile,
   b.rate_plan, b.old_seller_id, b.new_seller_id
    FROM bid_prod_family_svc_chgs a, tlg_dealer_code_changes b
    WHERE a.bill_mkt_code = b.bill_mkt_code
      AND a.isd_mobile = b.isd_mobile
      AND a.account_number = to_number(b.account_number)
      AND a.product_code = b.product_code
      AND a.seller_id = b.old_seller_id
      AND b.old_seller_id != b.new_seller_id
      AND a.action_date = b.action_date
      AND a.month = &&1 AND a.year = &&3
      AND a.month = b.month AND a.year = b.year AND b.day = &&2;

-- delete this day's data from the backup table in case of a rerun
DELETE FROM dc_bid_srvchg_hist
  WHERE month = &&1 AND day = &&2 AND year = &&3;

DECLARE
  v_tlg_daily_UpdInfo dc_tlg_daily%ROWTYPE;
  v_bid_srvchg_UpdInfo dc_bid_srvchg%ROWTYPE;
  v_tlg_daily_cnt INTEGER;
  v_bid_srvchg_cnt INTEGER;

CURSOR cur_dc_tlg_daily IS
  SELECT * FROM dc_tlg_daily;

CURSOR cur_dc_bid_srvchg IS
  SELECT * FROM dc_bid_srvchg;
  
BEGIN
  v_tlg_daily_cnt := 0;
  v_bid_srvchg_cnt := 0;
  -- Loop through temporary DT DC true up table and update the DT base and repository tables
  OPEN cur_dc_tlg_daily;
  LOOP
    FETCH cur_dc_tlg_daily INTO v_tlg_daily_UpdInfo;
    EXIT WHEN cur_dc_tlg_daily%NOTFOUND;
    
    BEGIN
      BEGIN
        UPDATE tlg_daily_trans
          SET seller_id = v_tlg_daily_UpdInfo.new_seller_id,
              mod_date = sysdate,
              mod_user = 'Daily DC Update '
          WHERE month = &&1 AND year = &&3 AND tlg_daily_trans_key = v_tlg_daily_UpdInfo.tlg_daily_trans_key;
	v_tlg_daily_cnt := v_tlg_daily_cnt + 1;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
      END;
    END;

    -- save the temp table data to the backup table
    BEGIN
      INSERT INTO dc_tlg_daily_hist
        (tlg_daily_trans_key,
         tlg_dealer_code_changes_key,
         seller_id,
         isd_mobile,
         rate_plan,
         old_seller_id,
         new_seller_id,
         month,
         day,
         year)
      VALUES
        (v_tlg_daily_UpdInfo.tlg_daily_trans_key,
         v_tlg_daily_UpdInfo.tlg_dealer_code_changes_key,
         v_tlg_daily_UpdInfo.seller_id,
         v_tlg_daily_UpdInfo.isd_mobile,
         v_tlg_daily_UpdInfo.rate_plan,
         v_tlg_daily_UpdInfo.old_seller_id,
         v_tlg_daily_UpdInfo.new_seller_id,
         &&1,
         &&2,
         &&3
        );
        
      EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
  
  END LOOP;
  DBMS_OUTPUT.put_line ('Updated ' || v_tlg_daily_cnt || ' TLG_DAILY_TRANS records.');
  CLOSE cur_dc_tlg_daily;
  COMMIT;

  -- Loop through temporary BID DC true up table and update the BID base and repository tables
  OPEN cur_dc_bid_srvchg;
  LOOP
    FETCH cur_dc_bid_srvchg INTO v_bid_srvchg_UpdInfo;
    EXIT WHEN cur_dc_bid_srvchg%NOTFOUND;
    
    BEGIN
      BEGIN
        UPDATE bid_prod_family_svc_chgs
          SET seller_id = v_bid_srvchg_UpdInfo.new_seller_id, agent_code = v_bid_srvchg_UpdInfo.new_seller_id,
            mod_date = sysdate,
            mod_user = 'Daily DC Update'
          WHERE month = &&1 AND year = &&3 and bid_prod_family_key = v_bid_srvchg_UpdInfo.bid_prod_family_key;
	v_bid_srvchg_cnt := v_bid_srvchg_cnt + 1;
        
      EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
      END;

    END;
  
    -- save the temp table data to the backup table
    BEGIN
      INSERT INTO dc_bid_srvchg_hist
        (bid_prod_family_key,
         tlg_dealer_code_changes_key,
         seller_id,
         isd_mobile,
         rate_plan,
         old_seller_id,
         new_seller_id,
         month,
         day,
         year)
      VALUES
        (v_bid_srvchg_UpdInfo.bid_prod_family_key,
         v_bid_srvchg_UpdInfo.tlg_dealer_code_changes_key,
         v_bid_srvchg_UpdInfo.seller_id,
         v_bid_srvchg_UpdInfo.isd_mobile,
         v_bid_srvchg_UpdInfo.rate_plan,
         v_bid_srvchg_UpdInfo.old_seller_id,
         v_bid_srvchg_UpdInfo.new_seller_id,
         &&1,
         &&2,
         &&3
        );
        
      EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
  
  END LOOP;
  DBMS_OUTPUT.put_line ('Updated ' || v_bid_srvchg_cnt || ' BID_PROD_FAMILY_SVC_CHGS records.');
  CLOSE cur_dc_bid_srvchg;
  COMMIT;


  -- save the temp table data to the backup table
  BEGIN
    COMMIT;
  END;
  
END;
/
quit;
