set termout off ;
set echo off ;
set heading off ;
set pagesize 0  ;
set trimspool on ;
set feedback 1 ;
set colsep '|';
set linesize 760 ;

SELECT MAX(ora_sales_orders_key) + 1
FROM ora_sales_orders;

spool off ;
exit ;

