#!/bin/ksh

function SendEmail
{
SUBJ=$1
echo -e "JOB_STATUS Report:" > $eMSG
echo -e "================================================================================================" >> $eMSG

if [[ -z $PROCESSDAY ]]; then
	TMPDAY=""
else
	TMPDAY=" and DAY=$PROCESSDAY "
fi

echo -e "set head off linesize 250 " > $SQLCMD
echo -e "select to_char(start_time,'mm/dd/yyyy hh24:mi:ss')||' ' ||to_char(end_time,'mm/dd/yyyy hh24:mi:ss')||'  Mkt:' ||substr(BILL_MKT_CODE,1,3)|| '  Deleted:'||substr(REC_DELETED,1,10)||'  Loaded:'||substr(REC_LOADED,1,10)||'  JOB_INFO:'||substr(job_info,1,80) from JOB_STATUS a WHERE feed_type='$FEEDTYPE' and YEAR=$PROCESSYEAR and MONTH=$PROCESSMONTH $TMPDAY and (job_status_key IN (select max(job_status_key) from job_status b where  feed_type='$FEEDTYPE' and YEAR=$PROCESSYEAR and MONTH=$PROCESSMONTH $TMPDAY and b.BILL_MKT_CODE=a.BILL_MKT_CODE) or status='ERROR') order by YEAR, MONTH, DAY, FEED_TYPE, BILL_MKT_CODE;" >> $SQLCMD
echo -e "exit;" >> $SQLCMD

cat $SQLCMD

$SQLSTART @$SQLCMD >> $eMSG
echo -e "================================================================================================" >> $eMSG
#------------------Prepare message to send----------------
echo "Email message file is $eMSG"  
#------------------Send Email message---------------------
echo "Sending Email message to alias in .mailrc - '${HZN_ALIAS}' " 
cat $eMSG |mail -s "${SUBJ}" ${HZN_ALIAS}  >>/dev/null

rm -rf $eMSG
rm -rf $SQLCMD

}


USAGE="\n$(basename $0) [{-m<month> -y<year>}] -e<env> -S -a -f<feed type>
       \n  -m<month>
       \n  -y<year>
       \n  -e<env> (Run in the specified environment - retail 
       \n  -S Set the status only in LOAD_STATUS 
       \n  -a analyze table 
       \n  -f feed type (tlg_true, tlg_srvchg, tlg_daily, tlg_mult_imei, tlg_ccnmcn_chg, tlg_srvarea, tlg_srvarea_mob, tlg_tablet,tlg_smf_allmobs_agt, tlg_smf_allmobs_nat,tlg_smf_billhistory_agt, tlg_smf_billhistory_nat,tlg_smf_customer_agt,tlg_smf_customer_nat, tlg_dealer_chg, tlg_ffsc, tlg_inst_info, tlg_imei_catchup) "

typeset -Z2 PROCESSMONTH
typeset -Z2 PROCESSDAY
typeset -Z4 PROCESSYEAR
export DO_ANALYZE=N

while getopts e:d:y:m:f:SXaE OPT ; do
        case $OPT in
        m) export PROCESSMONTH=$OPTARG;;
        y) export PROCESSYEAR=$OPTARG;;
        d) export PROCESSDAY=$OPTARG;;
        f) export FEEDTYPE=$OPTARG;;
        E) export EMAIL_IGNORE=Y;;
        S) export SET_STATUS_ONLY=Y;;
	X) export SKIP_PREV_CHECK="-X";;
	a) export DO_ANALYZE="Y";;
        e) typeset -lx RUNENV=$OPTARG;;
        *) echo -e $USAGE; exit 99;;
        esac
done

if [[ -z $SET_STATUS_ONLY ]] ; then
	SET_STATUS_ONLY=N
fi

if [[ -z $RUNENV ]] ; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide an environment!"
        echo -e $USAGE
        exit 99
fi
if [[ -z $PROCESSMONTH ]] ; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide a month!"
        echo -e $USAGE
        exit 99
fi
if [[ -z $PROCESSYEAR ]] ; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` You must provide a year!"
        echo -e $USAGE
        exit 99
fi
if [[ -z $EMAIL_IGNORE ]] ; then
	EMAIL_IGNORE_STR=""
else
	EMAIL_IGNORE_STR="-E"
fi

if [[ -z $PROCESSDAY ]] ; then
	THEDAY=NULL
else
	THEDAY=$PROCESSDAY
	DAYSTR="-d$PROCESSDAY"
	DAYSTR2=" and day=$PROCESSDAY "
fi

case ${FEEDTYPE} in
	tlg_true)  TABLENAME="TLG_TRUE_UP_TRANS"
			DELSTR="-DM";;
	tlg_ffsc)  TABLENAME="TLG_FFSC_TRANS"
			DELSTR="-DD";;
	tlg_daily)  TABLENAME="TLG_DAILY_TRANS"
			DELSTR="-DD";;
	tlg_mult_imei)  TABLENAME="TLG_MULT_IMEI"
			DELSTR="-DD";;
	tlg_ccnmcn_chg)  TABLENAME="TLG_CCNMCN_CHG"
			DELSTR="-DD";;
	tlg_srvarea)  TABLENAME="TLG_SRVAREA"
			DELSTR="-DD";;
	tlg_srvarea_mob)  TABLENAME="TLG_SRVAREA_MOB"
			DELSTR="-DD";;
	tlg_tablet)  TABLENAME="TLG_TABLET"
			DELSTR="-DD";;
	tlg_smf_allmobs_agt)  TABLENAME="TLG_SMF_ALLMOBS"
			DELSTR="-DM";;
	tlg_smf_allmobs_nat)  TABLENAME="TLG_SMF_ALLMOBS"
			DELSTR="-DM";;
	tlg_smf_billhistory_agt)  TABLENAME="TLG_SMF_BILLHISTORY"
			DELSTR="-DM";;
	tlg_smf_billhistory_nat)  TABLENAME="TLG_SMF_BILLHISTORY"
			DELSTR="-DM";;
	tlg_smf_customer_agt)  TABLENAME="TLG_SMF_CUSTOMER"
			DELSTR="-DM";;
	tlg_smf_customer_nat)  TABLENAME="TLG_SMF_CUSTOMER"
			DELSTR="-DM";;
	tlg_dealer_chg)  TABLENAME="TLG_DEALER_CODE_CHANGES"
			DELSTR="-DD";;
	tlg_inst_info)  TABLENAME="TLG_INST_INFO_CATCHUP"
			DELSTR="-DM";;
	tlg_imei_catchup)  TABLENAME="TLG_IMEI_CATCHUP"
			DELSTR="-DD";;
	*) echo -e "`date '+%m/%d/%Y %H:%M:%S'` Incorrent feed type! Must be tlg_true, tlg_daily, tlg_mult_imei, tlg_srvarea, tlg_srvarea_mob, tlg_ccnmcn_feed, tlg_tablet,tlg_smf_allmobs_agt,tlg_smf_allmobs_nat,tlg_smf_billhistory_agt,tlg_smf_billhistory_nat,tlg_smf_customer_agt,tlg_smf_customer_nat, tlg_dealer_chg, tlg_srvchg, tlg_inst_info, tlg_imei_catchup\n\n"
		echo -e $USAGE
		exit 99;;
esac

echo -e "`date '+%m/%d/%Y %H:%M:%S'` Will setup the $RUNENV environment..."
. $HORIZON_BIN/setupenv.sh -e$RUNENV

export BaseScriptname=`basename $0`
export SQLSTART="sqlplus -s ${COMM_DBUSER}/${COMM_DBPASS}@${COMM_SERVER}"
export PROCESSID=$$

typeset SQLCMD
SQLCMD=$HORIZON_DATA/sqlcommand$(hostname)_$$.sql

echo -e "delete from load_status where feed_type='global_$FEEDTYPE' and month=$PROCESSMONTH $DAYSTR2 and year=$PROCESSYEAR;" > $SQLCMD
echo -e "exit" >> $SQLCMD
cat $SQLCMD 
$SQLSTART @$SQLCMD

rm -rf $SQLCMD

ALLMARKETS=`cat $HORIZON_BIN/global_tlg_mkts.dat`

if [[ "$SET_STATUS_ONLY" = "N" ]]; then
	for themkt in $ALLMARKETS
	do
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') LOAD $FEEDTYPE for MARKET -  $themkt"
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` lsfsubmit -J "$(hostname)_$$" -eo $HORIZON_LOG/$FEEDTYPE/lsf_loadhznrepos_${themkt}_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log -oo $HORIZON_LOG/$FEEDTYPE/lsf_loadhznrepos_${themkt}_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log $HORIZON_BIN/load_hznrepository.sh  -y$PROCESSYEAR  -m$PROCESSMONTH $DAYSTR -slook -e$RUNENV -M${themkt} -f$FEEDTYPE $DELSTR $SKIP_PREV_CHECK $EMAIL_IGNORE_STR"
	
		lsfsubmit -J "$(hostname)_$$" -eo $HORIZON_LOG/$FEEDTYPE/lsf_loadhznrepos_${themkt}_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log -oo $HORIZON_LOG/$FEEDTYPE/lsf_loadhznrepos_${themkt}_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log $HORIZON_BIN/load_hznrepository.sh  -y$PROCESSYEAR -m$PROCESSMONTH $DAYSTR -slook -e$RUNENV -M${themkt} -f$FEEDTYPE $DELSTR $SKIP_PREV_CHECK $EMAIL_IGNORE_STR

	done
	echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Waiting for all MKTS to complete...."
	lsfwait "$(hostname)_$$"

fi


# Check for JOB_STATUS ERROR
FOUND_ERROR=N

echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Checking for errors....."
export SENT_EMAIL=N

while (true)
do

export FOUND_ERROR=N
export eMSG=${HORIZON_LOG}/load_tlg_mkts_msg.$$

#SQLSTR="set heading off pagesize 0 verify off feedback off
#select count(*) from job_status where feed_type='$FEEDTYPE' and month=$PROCESSMONTH $DAYSTR2 and year=$PROCESSYEAR and status='ERROR';
#exit;"
#
#	if [[ INC_COUNT=$(echo -e "$SQLSTR" | $SQLSTART ) -gt 0 ]]; 
#	then
#		FOUND_ERROR=Y
#	fi

SQLSTR="set heading off pagesize 0 verify off feedback off
select count(*) from load_status where feed_type='$FEEDTYPE' and month=$PROCESSMONTH $DAYSTR2 and year=$PROCESSYEAR and re_process is null;
exit;"

	if [[ INC_COUNT=$(echo -e "$SQLSTR" | $SQLSTART ) -lt 33 ]]; 
	then
		FOUND_ERROR=Y
	fi

    if [[ "$TABLENAME" = "TLG_SRVAREA" || "$TABLENAME" = "TLG_SRVAREA_MOB" ]]; then
         if [[ "$DO_ANALYZE" = "Y" && "$FOUND_ERROR" = "N" ]]; then
        echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Anlalyzing $TABLENAME...."
        $HORIZON_BIN/analyze_table.sh -t$TABLENAME -e$RUNENV
        echo -e "date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Done anlalyzing $TABLENAME."
        export DO_ANALYZE="N"
        fi
    fi


if [[ "$FOUND_ERROR" = "N" ]]; then
	if [[ "$DO_ANALYZE" = "Y" ]]; then
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Anlalyzing $TABLENAME...."
		$HORIZON_BIN/analyze_table.sh -t$TABLENAME -m$PROCESSMONTH -y$PROCESSYEAR -e$RUNENV
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Done anlalyzing $TABLENAME."
	fi

	if [[ "$FEEDTYPE" = "tlg_daily" ]]; then
	# Update CPC fields in tlg_daily_trans 
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Starting CPC tlg_daily_trans update....."
		$SQLSTART @$HORIZON_BIN/tlg_daily_trans_cpc_update.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR > $HORIZON_LOG/tlg_daily/cpc_update_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log
		bcpcount=$(egrep -e "ORA-[0-9]" -e "Syntax error" $HORIZON_LOG/tlg_daily/cpc_update_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log | /usr/bin/wc -l )
		if [[ ${bcpcount} -ne 0 ]]; then
			echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Found ERROR(s) in CPC UPDATE logic, DO NOT set LOAD_STATUS!"
			if [[ "$SENT_EMAIL" = "N" ]]; then
				export HZN_ALIAS="HznRepErrorList"
        			SUBJ="${BaseScriptname} ERROR! CPC UPDATE $FEEDTYPE $PROCESSYEAR/$PROCESSMONTH/$PROCESSDAY"
        			#echo -e "Found ERROR(s)! in CPC UPDATE $FEEDTYPE processing!" > $eMSG
				SendEmail "$SUBJ"
				EXIT_CODE=99
				export SENT_EMAIL=Y
	         break
			fi
		fi

	# Mark DUPs
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Starting DUP SWEEP logic....."
		$SQLSTART @$HORIZON_BIN/tlg_daily_trans_dup_sweep.sql $PROCESSYEAR $PROCESSMONTH > $HORIZON_LOG/tlg_daily/dup_sweep_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log
		bcpcount=$(egrep -e "ORA-[0-9]" -e "Syntax error" $HORIZON_LOG/tlg_daily/dup_sweep_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log | /usr/bin/wc -l )
		if [[ ${bcpcount} -ne 0 ]]; then
			echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Found ERROR(s) in DUP SWEEP logic, DO NOT set LOAD_STATUS!"
			if [[ "$SENT_EMAIL" = "N" ]]; then
				export HZN_ALIAS="HznRepErrorList"
        			SUBJ="${BaseScriptname} ERROR! DUP SWEEP $FEEDTYPE $PROCESSYEAR/$PROCESSMONTH/$PROCESSDAY"
        			#echo -e "Found ERROR(s)! in DUP SWEEP $FEEDTYPE processing!" > $eMSG
				SendEmail "$SUBJ"
				EXIT_CODE=99
				export SENT_EMAIL=Y
	         break
			fi
		fi

	# Wash logic
		echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Starting WASH logic....."
		$SQLSTART @$HORIZON_BIN/wash_trans.sql $PROCESSMONTH $PROCESSDAY $PROCESSYEAR > $HORIZON_LOG/tlg_daily/wash_trans_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log
		bcpcount=$(egrep -e "ORA-[0-9]" -e "Syntax error" $HORIZON_LOG/tlg_daily/wash_trans_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log | /usr/bin/wc -l )
		if [[ ${bcpcount} -ne 0 ]]; then
			echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Found ERROR(s) in WASH logic, DO NOT set LOAD_STATUS!"
			if [[ "$SENT_EMAIL" = "N" ]]; then
				export HZN_ALIAS="HznRepErrorList"
        			SUBJ="${BaseScriptname} ERROR! WASH $FEEDTYPE $PROCESSYEAR/$PROCESSMONTH/$PROCESSDAY"
        			#echo -e "Found ERROR(s)! in WASH $FEEDTYPE processing!" > $eMSG
				SendEmail "$SUBJ"
				EXIT_CODE=99
				export SENT_EMAIL=Y
	         break
			fi
		fi

		echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Starting NAC EOD_PRODUCT_CODE UPDATE logic....."
		$SQLSTART @$HORIZON_BIN/update_eod_nac_product_codes.sql $PROCESSMONTH $PROCESSYEAR > $HORIZON_LOG/tlg_daily/update_eod_nac_product_codes_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log
		bcpcount=$(egrep -e "ORA-[0-9]" -e "Syntax error" $HORIZON_LOG/tlg_daily/update_eod_nac_product_codes_$PROCESSYEAR${PROCESSMONTH}${PROCESSDAY}_$$.log | /usr/bin/wc -l )
		if [[ ${bcpcount} -ne 0 ]]; then
			echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Found ERROR(s) in NAC EOD_PRODUCT_CODE UPDATE logic, DO NOT set LOAD_STATUS!"
			if [[ "$SENT_EMAIL" = "N" ]]; then
				export HZN_ALIAS="HznRepErrorList"
        			SUBJ="${BaseScriptname} ERROR! NAC EOD_PRODUCT_CODE UPDATE $FEEDTYPE $PROCESSYEAR/$PROCESSMONTH/$PROCESSDAY"
        			#echo -e "Found ERROR(s)! in NAC EOD_PRODUCT_CODE UPDATE $FEEDTYPE processing!" > $eMSG
				SendEmail "$SUBJ"
				EXIT_CODE=99
				export SENT_EMAIL=Y
	         break
			fi
		fi
	fi

	# Set status for all mkts complete in LOAD_STATUS
	echo -e "insert into load_status (LOAD_STATUS_KEY, YEAR, MONTH, DAY, PROCESS_ID, SCRIPT, FEED_TYPE, TABLE_NAME, DATA_FILE, LOAD_COMPLETED, MOD_USER, MOD_DATE) VALUES (seq_load_status.nextval, $PROCESSYEAR, $PROCESSMONTH,$THEDAY,$PROCESSID,'$BaseScriptname','global_$FEEDTYPE','$TABLENAME',' ', sysdate,'$ME',sysdate);" > $SQLCMD
	echo -e "exit" >> $SQLCMD
	cat $SQLCMD 
	$SQLSTART @$SQLCMD
	export HZN_ALIAS="HznRepCleanList"

	echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') All TLG Mkts for $FEEDTYPE processing COMPLETE!"
	SUBJ="${BaseScriptname} All TLG Mkts COMPLETE! ${FEEDTYPE} $PROCESSYEAR/$PROCESSMONTH/$PROCESSDAY"
	SendEmail "$SUBJ"
	#echo -e "No errors found for the $FEEDTYPE processing!" > $eMSG
	EXIT_CODE=0
	break

else

	echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') Found ERROR(s)/Missing complete LOAD_STATUS <33 in $FEEDTYPE processing, DO NOT set LOAD_STATUS! Sleeping....."
	if [[ "$SENT_EMAIL" = "N" ]]; then
		export HZN_ALIAS="HznRepErrorList"

        	SUBJ="${BaseScriptname} ERROR! ${FEEDTYPE} $PROCESSYEAR/$PROCESSMONTH/$PROCESSDAY"
        	#echo -e "Found ERROR(s)! in $FEEDTYPE processing!" > $eMSG
		SendEmail "$SUBJ"
		EXIT_CODE=99
		export SENT_EMAIL=Y
	fi
	sleep 180
fi

done

rm -rf $SQLCMD

echo -e "`date '+%m/%d/%Y %H:%M:%S'` $(date +'%D %X') EXIT_CODE: " $EXIT_CODE

exit $EXIT_CODE
