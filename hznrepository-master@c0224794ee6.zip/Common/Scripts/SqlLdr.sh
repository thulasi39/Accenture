#!/bin/ksh
#SqlLdr.sh
#----------------------
#######################################################################
#This section is for declaring the global variables.
BASESCRIPT=`basename ${0}`
SCRIPTNAME=`echo ${BASESCRIPT} | cut -f 1 -d . `
FEED_TYPE=csi_crossupg

#######################################################################
#This section is for including other scripts, mainly the commmon routine
#######################################################################
#-------------------include-----------------------
. ${HORIZON_BIN}/HznRep_common.inc

#######################################################################

function USAGE
{
	WriteLn "----------------------USAGE-----------------------------"
	WriteLn "This shell script loads given file into a given table. File must "
	WriteLn "exist in data dircetory (~/Common/data/csi_crossupg)."
	WriteLn "Feed_type hard coded as csi_crossupg for now"
	WriteLn "${BASESCRIPT}: -e<Env>  -i<INPUTFILE> -t<TableName>"
	WriteLn "	 -e<Env> Environment - dev |sys |qc  "
	WriteLn "    		|uat | tst | prod "
	WriteLn "	 -i<Your data Filename MUST be in data dir.> "
	WriteLn "	 -t<Tablename> (Table & control file MUST exist.) "
	WriteLn "	 Please note ALL parameters are needed -e, -i, -t "
	WriteLn "e.g."
	WriteLn "		${BASESCRIPT} -edev  -iAbc.dat -tcsi_cross_upg_data"
	WriteLn "------------------end USAGE-----------------------------"

	exit 97
}
###########################################################################

function LOAD_TABLE
{
	WriteLn " Entered LOAD_TABLE -----------------------------------------------------"
	DATA_FILE=${1}
	DatafileOnly=${2}
	Tablename=${3}
	CTLFILE=${4}
	WriteLn "DATA_FILE: ${DATA_FILE}"
	WriteLn "DatafileOnly: ${DatafileOnly}"
	WriteLn "Tablename: ${Tablename}"
	WriteLn "CTLFILE: ${CTLFILE}"
	WriteLn " -----------------end parm----------------------------------------------------"

	BAD_FILE=${HZN_DATA}/${DatafileOnly}.bad
	DISCARD_FILE=${HZN_DATA}/${DatafileOnly}.dis

	Bcplog="${HZN_LOG}/${DatafileOnly}_$$.log"
	WriteLn " * BadFile: ${BAD_FILE} "
	WriteLn " * DiscardFile: ${DISCARD_FILE} "

	WriteLn "$(dtx) LOAD_IN_PROGRESS ${Datafile} into ${COMM_DBASE}..${Tablename}"
	SQLLOADCMD="sqlldr userid=${COMM_DBUSER}"@"${COMM_SERVER}""/""${COMM_DBPASS} "
	SQLLOADCMD="${SQLLOADCMD} control=${CTLFILE} data=${DATA_FILE} "
	SQLLOADCMD="${SQLLOADCMD} log=${Bcplog} bad=${BAD_FILE} discard=${DISCARD_FILE}"
	WriteLn "==========sqlldr Command==========="
	WriteLn "${SQLLOADCMD}"
	WriteLn "==========end sqlldr Command==========="
	${SQLLOADCMD}
	CheckLog

	WriteLn " End LOAD_TABLE-----------------------------------------------------"
}

###########################################################################

function CheckLog
{
	echo "Entered CheckLog-----------------------------------------------------" | tee -a ${HznLOG}
	IN_LOG=$1
	if [[ "$IN_LOG" = "" ]]; then
		Check_LOG=$Bcplog
	else
		Check_LOG=$IN_LOG
	fi
	
	echo "Checking ${Check_LOG}" | tee -a ${HznLOG}
	echo "********** BCP SESSION MESSAGES WERE **********" | tee -a ${HznLOG}
	cat ${Check_LOG} | tee -a ${HznLOG}
	echo "********** END OF BCP SESSION MESSAGES **********" | tee -a ${HznLOG}

	# Look for fatal errors in bcp log           
	bcpcount=$(egrep "ORA-[0-9]"  ${Check_LOG} | /usr/bin/wc -l )
	#-------------------------------------------------------------------------
	echo -e "RecLoaded: $RecLoaded" | tee -a ${HznLOG}
	if [[ "$FEED_TYPE" != "calc_ban" ]]; then
		Loaded=$(egrep loaded ${Check_LOG} |grep "successfully")
		echo "Loaded: ${Loaded}"
		RecLoaded=`echo ${Loaded} |cut -f1 -d" "  -s`
		TotalRecLoaded=TotalRecLoaded+RecLoaded
	else
		TotalRecLoaded=RecLoaded
	fi
	DataError=$(egrep loaded ${Check_LOG} |grep "data errors")
	WhenError=$(egrep loaded ${Check_LOG} |grep "WHEN clauses")
	NullRec=$(egrep loaded ${Check_LOG} |grep "null")
	#------------------------
	echo "DataError: ${DataError}"
	echo "WhenError: ${WhenError}"
	echo "NullRec: ${NullRec}"
	#------------------------
	export ErrorData=`echo ${DataError} |cut -f1 -d" "  -s`
	export ErrorWhen=`echo ${WhenError} |cut -f1 -d" "  -s`
	export ErrorNull=`echo ${NullRec} |cut -f1 -d" "  -s`
	#----------------------------------
	#------------------------
	echo "TotalRecLoaded: ${TotalRecLoaded}"
	echo "ErrorData: ${ErrorData}"
	echo "ErrorWhen: ${ErrorWhen}"
	echo "ErrorNull: ${ErrorNull}"
	export COUNTS="**RecsLoaded: $TotalRecLoaded *DataError: $ErrorData *FailedWhen: $ErrorWhen *NullRecords: $ErrorNull"
	echo "COUNTS: $RECORD_COUNT" | tee -a ${HznLOG}

	#-------------------------------------------------------------------------
	# if fatal error encountered echo message and return condition 99 to calling pgm
	if [[ ${bcpcount} -ne 0 ]]; then
		echo "Problem during SQLLOAD" | tee -a ${HznLOG}
		echo "ERROR Loading ${TABLENAME} for F:${FEED_TYPE}, r:${YYYYMMDD}." |tee -a ${HznLOG}
		exit 97
	else
		echo "SQLLOAD successful for ${TABLENAME} (F:${FEED_TYPE}, r:${YYYYMMDD}, )" | tee -a ${HznLOG}
	fi
	rm -f $Bcplog
	echo " End CheckLog-----------------------------------------------------" | tee -a ${HznLOG}
}

############################################
#	MAIN 
############################################
#----------------------------------------------------------------
	export HZN_DATA="${HORIZON_DATA}/${FEED_TYPE}"
	export HZN_LOG="${HORIZON_LOG}/${FEED_TYPE}"
	export HZN_CTL="${HORIZON_CTL}"
	export HZN_BIN="${HORIZON_BIN}"
	export CTLDIR="${HZN_CTL}"
	export DATADIR="${HZN_DATA}"
	export LOGDIR="${HZN_LOG}"
#---------------------------------------------------------------
############################################
#	Get the Parameters 
############################################
typeset -Z2 MONTH
while getopts i:t:e:v:Dm: OPT; 
	do
	  case ${OPT} in
		e) export RUNENV=`echo ${OPTARG} | tr '[A-Z]' '[a-z]'`;;
		i) export INPUTFILE=`echo ${OPTARG}`;;
		t) export TABLENAME=`echo ${OPTARG} | tr '[A-Z]' '[a-z]'`;;
		m) export MONTH=`echo ${OPTARG}`;;
		*)	USAGE
			;;
	  esac
done

if [ -z ${ALLARGS} ]; then
	USAGE
fi
#--------------------------------------------------------
#		Make directories as needed
#--------------------------------------------------------
if [[ ! -d ${HZN_DATA}/backup ]]; then
	mkdir -p ${HZN_DATA}/backup
fi
if [[ ! -d ${HZN_LOG}/backup ]]; then
	mkdir -p ${HZN_LOG}/backup
fi
#--------------------------------------------------------------
export HznLOG="${HZN_LOG}/${SCRIPTNAME}Temp_${TABLENAME}_$$.log"
chmod 755 ${HznLOG}
WriteLn "$(dtx) Starting ${0} ------------------------"
#-----------------------------------------------------------------------#
#		Backup Old Log Files											#
#-----------------------------------------------------------------------#
if [[ -f ${HZN_LOG}/${SCRIPTNAME}_*.log ]]
then
	mv ${HZN_LOG}/${SCRIPTNAME}_*.log ${HZN_LOG}/backup
	gzip -f ${HZN_LOG}/backup/${SCRIPTNAME}_*.log
	WriteLn "***Old Logs backed up!"
else
	WriteLn "***No Old Logs to backup!"
fi
#-----------------------------------------------------------------------#

#---------------------------------------------------------------
	WriteLn "	HZN_DATA: ${HZN_DATA}" 
	WriteLn "	HZN_LOG: ${HZN_LOG}" 
	WriteLn "	HZN_CTL: ${HZN_CTL}" 
	WriteLn "	HZN_BIN: ${HZN_BIN}" 
	WriteLn "-------------------------------------------------" 
	WriteLn "	CTLDIR=${CTLDIR}" 
	WriteLn "	DATADIR=${DATADIR}" 
	WriteLn "	LOGDIR=${LOGDIR}" 
	WriteLn "-------------------------------------------------" 
#---------------------------------------------------------------
if [ -z ${RUNENV} ]; then
	WriteLn "***Error*** Missing Environment! " 
	USAGE
fi
if [ -z ${INPUTFILE} ]; then
	WriteLn "***Error*** Missing Input data filename! " 
	USAGE
else
	INP_FILE=`echo "${INPUTFILE}" | cut -f1 -d"." -s`
	WriteLn "***INP_FILE is Now ${INP_FILE} *** " 
fi
if [ -z ${TABLENAME} ]; then
	WriteLn "***Error*** Missing TABLENAME! " 
	USAGE
fi
export CTLFILE=${HZN_CTL}/${TABLENAME}.ctl
if [ -s ${CTLFILE} ]; then
	WriteLn "***File Exists: ${CTLFILE}! " 
else
	WriteLn "***File DOES NOT Exist!!!: ${CTLFILE}! " 
	USAGE
fi

export HznLOG2="${HZN_LOG}/${SCRIPTNAME}_${INP_FILE}_$$.log"
mv ${HznLOG} ${HznLOG2}
export HznLOG=${HznLOG2}

WriteLn "$(dtx) ------------------Parameters----------------------"
WriteLn "	RUNENV:	${RUNENV}"
WriteLn "	INPUTFILE:	${INPUTFILE}"
WriteLn "	INP_FILE:	${INP_FILE}"
WriteLn "	TABLENAME:	${TABLENAME}"
WriteLn "	TABLENAME:	${TABLENAME}"
WriteLn "	---------------------------------"
WriteLn "	HORIZON_DATA:	${HORIZON_DATA}"
WriteLn "	HORIZON_LOG:	${HORIZON_LOG}"
WriteLn "	---------------------------------"
WriteLn "	HZN_DATA:	${HZN_DATA}"
WriteLn "	HZN_LOG:	${HZN_LOG}"
WriteLn "	HZN_CTL:	${HZN_CTL}"
WriteLn "	---------------------------------"
WriteLn "	HznLOG:	${HznLOG}"
WriteLn "$(dtx) ---------------------------------"
#--------------------------------------------------------------------------
DATAFILE=${HZN_DATA}/${INPUTFILE}
if [[ ! -s ${DATAFILE} ]]
then
	WriteLn "Data file DOES NOT exists! (${DATAFILE})"
	USAGE
else
	WriteLn "Data file exists! (${DATAFILE})"
fi

############################################
#	setup login to the database
############################################
ValidateDBEnv

WriteLn "$(dtx) COMM_DBASE:	${COMM_DBASE}"
SQLSTART="sqlplus -s "${COMM_DBUSER}"/"${COMM_DBPASS}"@"${COMM_SERVER}

#---------------------------------------------------------
#	Build SQL command to Run the procedure Spool
#---------------------------------------------------------
WriteLn "SQLSTART is: ${SQLSTART}"
WriteLn "$(dtx) ----------------Before LOAD_TABLE--------------------------"
LOAD_TABLE ${DATAFILE} ${INP_FILE} ${TABLENAME}  ${CTLFILE}
WriteLn "$(dtx) ----------------After LOAD_TABLE--------------------------"


#-----------------------------------------------------------------------#
#		Backup Data Files											#
#-----------------------------------------------------------------------#
mv ${DATAFILE} ${HZN_DATA}/backup
gzip -f ${HZN_DATA}/backup/${INP_FILE}.dat
WriteLn "***Backup Data File: ${DATAFILE}!"

WriteLn "$(dtx) Exiting ${BaseScriptname} ${FEED_TYPE} Input file ${INPUTFILE} CLEANLY..." | tee -a ${HznLOG}
