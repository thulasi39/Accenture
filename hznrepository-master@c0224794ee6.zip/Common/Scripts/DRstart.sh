#!/bin/ksh
HOST=$(hostname)
DATE_TIME=$(date '+%Y%m%d_%H%M%S')
nohup /opt/app/retailcommon/DataRouter/bin/hznsubscriber.sh > /opt/app/retailcommon/DataRouter/logs/hznsub_${HOST}_${DATE_TIME}.log 2>&1 &
ps -fu $LOGNAME | grep -v grep | grep "hznsubscriber.sh"
