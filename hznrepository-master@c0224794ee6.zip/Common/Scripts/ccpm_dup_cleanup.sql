-- #############################################################################
-- #
-- # This script will execute a stored procedure used to identify and mark
-- # duplicate orders in the CCPM_WLINE_TRANS table.
-- #
-- # Parameters:
-- #     1 - Rpt Year
-- #     2 - Rpt Month
-- #
-- # Example:  @ccpm_dup_cleanup.sql  <Rpt Year>  <Rpt Month>
-- #
-- # Modifications
-- # ---------------------------------------------------------------------------
-- # 2016-11-15  JRL  Created script
-- #
-- #############################################################################

WHENEVER SQLERROR EXIT SQL.SQLCODE

SET ServerOutput ON

-- executing for Submitted Orders (Order_Status = 'S')
exec SP_CCPM_DUP_CLEANUP( &&1, &&2, 'S' ) ;

-- executing for Posted Orders (Order_Status = 'P')
exec SP_CCPM_DUP_CLEANUP( &&1, &&2, 'P' ) ;

EXIT
