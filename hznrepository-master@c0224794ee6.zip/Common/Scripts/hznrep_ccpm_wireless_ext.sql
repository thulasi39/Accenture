set termout off ;
set echo off ;
set heading off ;
set pagesize 0  ;
set trimspool on ;
set feedback 1 ;
set linesize 1000 ;

SELECT 'DTL' || '|' ||
       bill_market || '|' ||
       ctn_market || '|' ||
       dealer_code || '|' ||
       product_code || '|' ||
       product_desc || '|' ||
       product_type || '|' ||
       cust_name || '|' ||
       fan_id || '|' ||
       ctn || '|' ||
       isd_ctn || '|' ||
       ban || '|' ||
       isd_ban || '|' ||
       action_type || '|' ||
       to_char(action_date,'YYYYMMDD') || '|' ||
       mrc || '|' ||
       device_model || '|' ||
       imei || '|' ||
       customer_type || '|' ||
       to_char(contract_date,'YYYYMMDD') || '|' ||
       contract_term || '|' ||
       contract_type || '|' ||
       manufacturer || '|' ||
       segment || '|' ||
       device_class || '|' ||
       prev_product_code || '|' ||
       prev_mrc || '|' ||
       prev_contract_term || '|' ||
       prev_contract_type || '|' ||
       sku || '|' ||
       sku_desc || '|' ||
       sku_size || '|' ||
       sku_color || '|' ||
       addr1 || '|' ||
       addr2 || '|' ||
       city || '|' ||
       state || '|' ||
       zipcd || '|' ||
       comp_revenue || '|' ||
       prev_comp_revenue || '|' ||
       to_char(isd,'YYYYMMDD') || '|' ||
       mobile_type || '|' ||
       to_char(feature_isd,'YYYYMMDD') || '|' ||
       to_char(dcd,'YYYYMMDD')
FROM hznrep_ccpm_wireless_trans
WHERE year = --PROCESSYEAR
  and month = --PROCESSMONTH
  and day = --PROCESSDAY;

spool off ;
exit ;
