#!/usr/local/bin/perl -w
################################################################################
# preveom.pl
#
# Usage:
#	preveom.pl [ -o <offset> ] [ <MM> <YYYY> ]
#
# Output:
#	MM DD YYYY
#
# Description:
#	This script returns the MM DD YYYY of the last day of the previous
#	month.  With the optional -o <offset> option, you can determine the
#	MM DD YYYY of the last day of the month <offset> months from today,
#	with negative offsets returning dates in the past, positive offsets
#	returning future dates, and an offset of 0 returning the last day of
#	the current month.  The default offset is -1.
#	Optionally, you can also provide a <MM> <YYYY>, and the script will
#	calculate the offset from that date instead of today.
#
#	The perl function localtime() returns the following array:
#	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)
#	- where $mday is the day of the month; $mon is the month itself,
#	in the range "0..11" with 0 indicating January and 11 indicating
#	December; and $year is the number of years since 1900.
#
# Examples:
#	=> date
#	Thu May 11 10:54:54 CDT 2006
#	=> preveom.pl
#	04 30 2006
#	=> preveom.pl -o -2
#	03 31 2006
#	=> preveom.pl -o 3 
#	08 31 2006
#	=> preveom.pl -o -1 04 2006
#	03 31 2006
#
# History:
#	05/11/2006 - Terri Matthews - Created.
################################################################################


use Getopt::Std;
use POSIX;

$usage = "Usage: $0 [ -o <offset> ] [ <MM> <YYYY> ]";
$offset = -1;

getopts('o:') || die "ERROR: Unknown options.\n$usage\n";
if (defined($opt_o)) {
	$offset = int($opt_o);
}

if (defined $ARGV[0]) {
	$mon = $ARGV[0];
	$mon -= 1;
	if (defined $ARGV[1]) {
		$year = $ARGV[1];
		$year -= 1900;
	} else {
		die "$usage\n";
	}
} else {
	($mon,$year) = (localtime(time))[4,5];
}

@daysinmonth = (
	[ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ],
	[ 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ],
);

$mm = sprintf("%02d", (($mon + $offset) % 12) + 1);
$yyyy = sprintf("%04d", $year + (floor(($mon + $offset) / 12)) + 1900);

if ( $yyyy % 4) {
	$leap_flag = 0;
} elsif ($yyyy % 100) {
	$leap_flag = 1;
} elsif ($yyyy % 400) {
	$leap_flag = 0;
} else {
	$leap_flag = 1;
}
$last_day = $daysinmonth[$leap_flag][$mm - 1];

printf("%02d %02d %04d\n", $mm, $last_day, $yyyy);
