set serveroutput on
-- &&1 is year
-- &&2 is month

begin
  execute immediate 'drop table spi_custname_bid_prod_family';
  exception when others then null;
end;
/

CREATE TABLE spi_custname_bid_prod_family AS
  SELECT a.bid_prod_family_key
    FROM bid_prod_family_svc_chgs a
    WHERE a.year = &&1
       AND a.month = &&2
       AND a.day = &&3
       AND (   REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{3}-[0-9]{2}-[0-9]{4}([^0-9].*$|$)')
            OR REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{3} [0-9]{2} [0-9]{4}([^0-9].*$|$)')
            OR REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{3}[0-9]{2}[0-9]{4}([^0-9].*$|$)')
            OR REGEXP_LIKE (CUSTOMER_NAME, '(^|^.*[^0-9])[0-9]{2}-[0-9]{7}([^0-9].*$|$)'));

DECLARE
  v_bid_prod_UpdInfo spi_custname_bid_prod_family%ROWTYPE;
  v_bid_prod_cnt INTEGER;

CURSOR cur_spi_cust_bid_prod IS
  SELECT * FROM spi_custname_bid_prod_family;

BEGIN
  v_bid_prod_cnt := 0;
  -- Loop through temporary spi_custname_bid_prod_family table
  OPEN cur_spi_cust_bid_prod;
  LOOP
    FETCH cur_spi_cust_bid_prod INTO v_bid_prod_UpdInfo;
    EXIT WHEN cur_spi_cust_bid_prod%NOTFOUND;

    BEGIN
      BEGIN
        UPDATE bid_prod_family_svc_chgs
           SET CUSTOMER_NAME = REGEXP_REPLACE (CUSTOMER_NAME, '[0-9]', 'X'),
              mod_date = sysdate
        WHERE bid_prod_family_key = v_bid_prod_UpdInfo.bid_prod_family_key;
        v_bid_prod_cnt := v_bid_prod_cnt + 1;
        IF mod(v_bid_prod_cnt,10000) = 0 THEN
             --DBMS_OUTPUT.put_line ('bid_prod_family_svc_chgs  Committed on ' || v_bid_prod_cnt || ' records.');
           COMMIT;
        END IF;


      EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
      END;
    END;

  END LOOP;
  DBMS_OUTPUT.put_line ('Updated ' || v_bid_prod_cnt || ' bid_prod_family_svc_chgs.');
  CLOSE cur_spi_cust_bid_prod;
  COMMIT;

END;
/
quit;
