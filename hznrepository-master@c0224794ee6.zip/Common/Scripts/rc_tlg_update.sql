set serveroutput on 
-- &&1 is month
-- &&2 is day
-- &&3 is year

begin
  execute immediate 'drop table rc_tlg_daily';
  exception when others then null;
end;
/

CREATE TABLE rc_tlg_daily AS
  SELECT a.tlg_daily_trans_key, b.edm_referral_code_trans_key, b.referral_code, a.current_mobile,
	a.ban, a.action_date, b.activation_date, b.completion_date, a.seller_id, a.action_type
    FROM tlg_daily_trans a, edm_referral_code_trans b
    WHERE a.current_mobile = b.mobile
      AND a.ban = b.ban
      AND a.seller_id = 'Z0066'
	  AND a.action_type in ('NAC', 'C16')
      AND ((abs(a.action_date-b.activation_date) <= 5) or 
            (abs(a.action_date - b.completion_date) <= 5))
      AND a.month = &&1 AND a.year = &&3 AND b.day = &&2;

DECLARE
  v_tlg_daily_UpdInfo rc_tlg_daily%ROWTYPE;
  v_tlg_daily_cnt INTEGER;

CURSOR cur_rc_tlg_daily IS
  SELECT * FROM rc_tlg_daily;

BEGIN
  v_tlg_daily_cnt := 0;
  -- Loop through temporary DT RC true up table and update the DT base and repository tables
  OPEN cur_rc_tlg_daily;
  LOOP
    FETCH cur_rc_tlg_daily INTO v_tlg_daily_UpdInfo;
    EXIT WHEN cur_rc_tlg_daily%NOTFOUND;
    
    BEGIN
      BEGIN
        UPDATE tlg_daily_trans
          SET p_seller_id = v_tlg_daily_UpdInfo.referral_code,
              mod_date = sysdate,
              mod_user = 'Daily RC Update'
          WHERE month = &&1 AND year = &&3 AND tlg_daily_trans_key = v_tlg_daily_UpdInfo.tlg_daily_trans_key;
		v_tlg_daily_cnt := v_tlg_daily_cnt + 1;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
      END;
    END;
  
  END LOOP;
  DBMS_OUTPUT.put_line ('Updated ' || v_tlg_daily_cnt || ' TLG_DAILY_TRANS records.');
  CLOSE cur_rc_tlg_daily;
  COMMIT;
  
END;
/
quit;
